================================================================================
SCHOOL-BASED EXAM CONTROL SYSTEM (SECS)
OFFICIAL LIVE EXAMINATION DATA SYNCHRONIZATION FOLDER
================================================================================

ATTENTION: ALL EXAM MARKERS, KEY PERSONNEL (KP) MODERATORS & HOD

When prompted in your web browser (Google Chrome or Microsoft Edge) to:
"📁 Link School Shared Folder" / "Select Department Shared Folder"

--> PLEASE SELECT THIS EXACT FOLDER:
    "EXAM DATA FOLDER (LINK TO THIS FOLDER)"

--------------------------------------------------------------------------------
HOW IT WORKS:
1. Each exam marker automatically saves their marks into their own isolated file
   inside the "secs_sync" subfolder (e.g., marker_M01.json, marker_M02.json).
2. Multiple markers can mark concurrently at the same time with ZERO collisions.
3. Key Personnel (KP) moderators save moderation audits into partitioned files
   (e.g., moderation_M01.json, moderation_HOD.json).
4. The HOD can view real-time live progress and manage paper classlists.
5. Markers have an automatic 10-minute amendment grace window after submitting each
   script. After 10 minutes, the script permanently locks for moderation.

DO NOT DELETE OR MOVE THIS FOLDER DURING THE ACTIVE MARKING EXERCISE.
================================================================================
