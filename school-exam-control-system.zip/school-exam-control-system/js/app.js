/**
 * SECS - Main Application Orchestrator & View Controller
 * Integrates Multi-Exam workflows, KP Moderation, and HOD Exit Guards.
 */

class AppController {
  constructor() {
    this.currentView = 'AUTH'; // 'AUTH' | 'MARKER' | 'HOD'
  }

  init() {
    this.bindGlobalEvents();
    if (auth.session && auth.session.isAuthenticated) {
      if (auth.session.examId) {
        db.switchExam(auth.session.examId);
      }
      const savedView = sessionStorage.getItem('SECS_CURRENT_VIEW');
      if (auth.isHOD()) {
        if (savedView === 'MARKER') {
          this.openMarkerPortal();
        } else {
          this.openHodHub();
        }
      } else if (auth.isMarker()) {
        this.openMarkerPortal();
      } else {
        this.showAuthModal();
      }
    } else {
      this.showAuthModal();
    }
  }

  bindGlobalEvents() {
    // Passcode Verification Form
    const authForm = document.getElementById('passcodeForm');
    if (authForm) {
      authForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handlePasscodeSubmit();
      });
    }

    // Role Selection Buttons
    const hodRoleBtn = document.getElementById('btnSelectHodRole');
    const markerRoleBtn = document.getElementById('btnSelectMarkerRole');
    if (hodRoleBtn) hodRoleBtn.addEventListener('click', () => this.selectHodRole());
    if (markerRoleBtn) markerRoleBtn.addEventListener('click', () => this.selectMarkerRole());

    // Switch Role / Logout
    const logoutBtn = document.getElementById('globalLogoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        if (this.currentView === 'HOD' && typeof hodApp !== 'undefined') {
          hodApp.openLogoutConfirmModal();
        } else {
          this.logout();
        }
      });
    }

    // Switch to Marker Portal from HOD
    const switchToMarkerBtn = document.getElementById('btnSwitchToMarker');
    if (switchToMarkerBtn) switchToMarkerBtn.addEventListener('click', () => this.openMarkerPortal());

    // Switch to HOD Hub from Marker (Guarded by confidential HOD Passcode)
    const switchToHodBtn = document.getElementById('btnSwitchToHod');
    if (switchToHodBtn) {
      switchToHodBtn.addEventListener('click', () => {
        if (auth.isHOD()) {
          this.openHodHub();
        } else {
          this.openElevateHodModal();
        }
      });
    }

    // Export Buttons
    const btnExcel = document.getElementById('btnExportExcel');
    const btnWord = document.getElementById('btnExportWord');
    const btnPdf = document.getElementById('btnPrintPdf');
    const btnEmail = document.getElementById('btnShareEmail');
    const btnBackupJson = document.getElementById('btnBackupJson');
    const btnRestoreJson = document.getElementById('btnRestoreJsonFile');

    if (btnExcel) btnExcel.addEventListener('click', () => {
      hodApp.triggerExportExcel();
    });

    if (btnWord) btnWord.addEventListener('click', () => {
      hodApp.triggerExportWord();
    });

    if (btnPdf) btnPdf.addEventListener('click', () => {
      hodApp.triggerPrintPdf();
    });

    if (btnEmail) btnEmail.addEventListener('click', () => {
      hodApp.triggerShareEmail();
    });

    if (btnBackupJson) btnBackupJson.addEventListener('click', () => {
      exporter.downloadDatabaseJSON();
    });

    if (btnRestoreJson) btnRestoreJson.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const res = db.importJSON(evt.target.result);
        if (res.success) {
          alert('Database restored successfully!');
          location.reload();
        } else {
          alert('Restore failed: ' + res.error);
        }
      };
      reader.readAsText(file);
    });

    // Auto-save notification listener
    db.onAutoSaved((ts) => {
      const date = ts ? new Date(ts) : new Date();
      const timeStr = date.toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const beacon = document.getElementById('globalAutoSaveBeacon');
      if (beacon) {
        beacon.innerHTML = `
          <span class="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span class="font-medium">Auto-saved ${timeStr}</span>
        `;
      }
    });

    // Shared Sync update listener for landing modal dropdown
    window.addEventListener('secs:sync:updated', () => {
      const roleModal = document.getElementById('roleSelectionModal');
      if (roleModal && !roleModal.classList.contains('hidden')) {
        this.refreshModalExamDropdown();
      }
      this.renderLandingSyncUI();
      this.renderGlobalExamSelector();
    });
  }

  showAuthModal() {
    this.currentView = 'AUTH';
    const authModal = document.getElementById('authModal');
    const roleModal = document.getElementById('roleSelectionModal');
    const mainApp = document.getElementById('mainAppContainer');

    if (authModal) authModal.classList.remove('hidden');
    if (roleModal) roleModal.classList.add('hidden');
    if (mainApp) mainApp.classList.add('hidden');

    this.renderLandingSyncUI();

    const passInput = document.getElementById('passcodeInput');
    if (passInput) {
      passInput.value = '';
      setTimeout(() => passInput.focus(), 100);
    }
    const errorEl = document.getElementById('authError');
    if (errorEl) errorEl.classList.add('hidden');
  }

  handlePasscodeSubmit() {
    const input = document.getElementById('passcodeInput');
    const errorEl = document.getElementById('authError');
    const val = input ? input.value : '';

    const res = auth.verifyPasscode(val);
    if (res.success) {
      if (errorEl) errorEl.classList.add('hidden');
      document.getElementById('authModal').classList.add('hidden');

      if (res.role === 'hod') {
        auth.loginAsHOD();
        this.openHodHub();
      } else {
        this.showMarkerSelectorModal();
      }
    } else {
      if (errorEl) {
        errorEl.textContent = res.error;
        errorEl.classList.remove('hidden');
      }
      if (input) {
        input.select();
        input.focus();
      }
    }
  }

  showMarkerSelectorModal() {
    const roleModal = document.getElementById('roleSelectionModal');
    if (!roleModal) return;

    const examSelect = document.getElementById('modalExamSelect');
    const exams = db.getExamsList();
    const activeExams = exams.filter(e => !e.isArchived);
    const displayExams = activeExams;
    const activeExam = db.getActiveExam();

    if (examSelect) {
      if (displayExams.length === 0) {
        examSelect.innerHTML = '<option value="">(No active papers - all archived)</option>';
      } else {
        examSelect.innerHTML = displayExams.map(e => `
          <option value="${e.id}" ${activeExam && e.id === activeExam.id ? 'selected' : ''}>
            ${e.title} (${e.totalStudents} pupils, ${e.markedCount} marked)
          </option>
        `).join('');
      }

      examSelect.onchange = (e) => {
        this.updateMarkerCodeDropdown(e.target.value);
      };
    }

    const currentExamId = examSelect ? examSelect.value : activeExam.id;
    this.updateMarkerCodeDropdown(currentExamId);

    // When logging in with marker passcode, hide the HOD card from the modal
    const hodCard = document.getElementById('modalHodCard');
    const modalTitle = document.getElementById('roleModalTitle');
    const modalDesc = document.getElementById('roleModalDesc');

    if (hodCard) hodCard.classList.add('hidden');
    if (modalTitle) modalTitle.textContent = 'Marker Identification & Paper Selection';
    if (modalDesc) modalDesc.textContent = 'Passcode verified. Please select the Examination Paper and your Marker Code.';

    this.renderLandingSyncUI();
    roleModal.classList.remove('hidden');
  }

  updateMarkerCodeDropdown(examId) {
    const root = db.getRootState();
    const exam = examId ? (root.exams.find(e => e.id === examId) || db.getActiveExam()) : db.getActiveExam();
    const select = document.getElementById('modalMarkerCodeSelect');
    if (select && exam && Array.isArray(exam.markers)) {
      select.innerHTML = exam.markers.map(m => `
        <option value="${m.code}">${m.code} - ${m.name}${m.isKP ? ' [KP Moderator]' : ''}</option>
      `).join('');
    }
  }

  renderLandingSyncUI(info) {
    const isConn = (typeof syncService !== 'undefined') && syncService.isConnected();
    const folderName = (typeof syncService !== 'undefined' && syncService.folderName) || 'Shared Folder';
    const examsCount = db.getExamsList().filter(e => !e.isArchived).length;

    // 1. Update landing page modal bar on roleSelectionModal
    const bar = document.getElementById('modalLandingSyncBar');
    const icon = document.getElementById('modalLandingSyncIcon');
    const title = document.getElementById('modalLandingSyncTitle');
    const sub = document.getElementById('modalLandingSyncSub');
    const btn = document.getElementById('btnModalLandingLinkSync');

    if (bar && title && sub && btn) {
      if (isConn) {
        bar.className = 'mb-4 p-3 rounded-xl border flex items-center justify-between text-xs transition-all bg-emerald-50/80 border-emerald-200 text-emerald-900 shadow-2xs';
        if (icon) icon.textContent = '🟢';
        title.innerHTML = `Linked to Shared Folder: <strong class="font-bold text-emerald-950">${folderName}</strong>`;
        sub.textContent = `${examsCount} active paper${examsCount === 1 ? '' : 's'} synced & ready for marking`;
        btn.textContent = '🔄 Sync Papers';
        btn.className = 'px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs shadow-2xs cursor-pointer transition-colors shrink-0';
        btn.onclick = async () => {
          if (typeof syncService !== 'undefined') await syncService.pollOnce(true);
          this.refreshModalExamDropdown();
        };
      } else {
        bar.className = 'mb-4 p-3 rounded-xl border flex items-center justify-between text-xs transition-all bg-amber-50/80 border-amber-200 text-amber-900 shadow-2xs';
        if (icon) icon.textContent = '📁';
        title.textContent = 'Shared Folder: Not Linked (Local Only)';
        sub.textContent = 'Link the school shared folder to load all department papers';
        btn.textContent = 'Link Folder';
        btn.className = 'px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs shadow-2xs cursor-pointer transition-colors shrink-0';
        btn.onclick = async () => {
          if (typeof syncService !== 'undefined') {
            const ok = await syncService.connectSharedFolder();
            if (ok) {
              await syncService.pollOnce(true);
              this.refreshModalExamDropdown();
            }
          }
        };
      }
    }

    // 2. Update passcode auth modal pill
    const authPill = document.getElementById('authSyncStatusPill');
    const authIcon = document.getElementById('authSyncIcon');
    const authText = document.getElementById('authSyncText');
    if (authPill && authIcon && authText) {
      if (isConn) {
        authIcon.textContent = '🟢';
        authText.textContent = `Linked: ${folderName} (${examsCount} paper${examsCount === 1 ? '' : 's'})`;
      } else {
        authIcon.textContent = '📁';
        authText.textContent = 'Link School Shared Folder';
      }
    }
  }

  refreshModalExamDropdown() {
    const examSelect = document.getElementById('modalExamSelect');
    if (!examSelect) return;

    const currentVal = examSelect.value;
    const exams = db.getExamsList();
    const activeExams = exams.filter(e => !e.isArchived);
    const displayExams = activeExams;
    const activeExam = db.getActiveExam();

    if (displayExams.length === 0) {
      examSelect.innerHTML = '<option value="">(No active papers - all archived)</option>';
      this.renderLandingSyncUI();
      return;
    }

    const targetVal = displayExams.some(e => e.id === currentVal) ? currentVal : (activeExam && !activeExam.isArchived ? activeExam.id : displayExams[0].id);

    examSelect.innerHTML = displayExams.map(e => `
      <option value="${e.id}" ${e.id === targetVal ? 'selected' : ''}>
        ${e.title} (${e.totalStudents} pupils, ${e.markedCount} marked)
      </option>
    `).join('');

    if (targetVal) {
      this.updateMarkerCodeDropdown(targetVal);
    }
    this.renderLandingSyncUI();
  }

  showRoleSelectionModal() {
    this.showMarkerSelectorModal();
  }

  selectHodRole() {
    auth.loginAsHOD();
    document.getElementById('roleSelectionModal').classList.add('hidden');
    this.openHodHub();
  }

  selectMarkerRole() {
    const examSelect = document.getElementById('modalExamSelect');
    const examId = examSelect ? examSelect.value : null;
    if (examId) {
      db.switchExam(examId);
    }
    const select = document.getElementById('modalMarkerCodeSelect');
    const markerCode = select ? select.value : 'M01';
    const state = db.getActiveExam();
    const markerObj = (state.markers || []).find(m => m.code === markerCode);
    const markerName = markerObj ? markerObj.name : `Marker ${markerCode}`;

    // If marker is assigned as a KP Moderator, require confidential 2-step PIN verification
    if (markerObj && markerObj.isKP) {
      this.openKpModeratorAuthModal(markerCode, markerName, examId);
      return;
    }

    // Standard Marker: log in directly without extra prompt
    auth.loginAsMarker(markerCode, markerName, examId, false);
    document.getElementById('roleSelectionModal').classList.add('hidden');
    this.openMarkerPortal();
  }

  openKpModeratorAuthModal(markerCode, markerName, examId) {
    this.pendingKpLogin = { markerCode, markerName, examId };
    const exam = examId ? (db.getRootState()?.exams?.find(e => e.id === examId) || db.getActiveExam()) : db.getActiveExam();

    const titleEl = document.getElementById('kpAuthModalPaperTitle');
    const codeEl = document.getElementById('kpAuthModalMarkerCode');
    const pinInput = document.getElementById('kpAuthPinInput');
    const errorEl = document.getElementById('kpAuthError');

    if (titleEl) titleEl.textContent = exam.title;
    if (codeEl) codeEl.textContent = `${markerCode} - ${markerName} [KP Moderator]`;
    if (pinInput) pinInput.value = '';
    if (errorEl) errorEl.classList.add('hidden');

    const roleModal = document.getElementById('roleSelectionModal');
    const kpModal = document.getElementById('kpModeratorAuthModal');
    if (roleModal) roleModal.classList.add('hidden');
    if (kpModal) kpModal.classList.remove('hidden');

    if (pinInput) setTimeout(() => pinInput.focus(), 120);
  }

  submitKpModeratorAuth() {
    if (!this.pendingKpLogin) return;
    const pinInput = document.getElementById('kpAuthPinInput');
    const errorEl = document.getElementById('kpAuthError');
    const pinVal = pinInput ? pinInput.value.trim() : '';
    const { markerCode, markerName, examId } = this.pendingKpLogin;

    const ok = auth.verifyModeratorPin(examId, pinVal);
    if (ok) {
      auth.loginAsMarker(markerCode, markerName, examId, true);
      const kpModal = document.getElementById('kpModeratorAuthModal');
      if (kpModal) kpModal.classList.add('hidden');
      this.pendingKpLogin = null;
      this.openMarkerPortal();
      if (typeof markerApp !== 'undefined') {
        markerApp.switchMarkerTab('kpModeration');
        markerApp.showToast(`🛡️ Key Personnel Moderator session unlocked for ${markerCode}!`, 'success');
      }
    } else {
      if (errorEl) {
        errorEl.textContent = 'Incorrect KP Moderator PIN for this paper. Please enter the exact PIN configured by HOD.';
        errorEl.classList.remove('hidden');
      }
      if (pinInput) {
        pinInput.select();
        pinInput.focus();
      }
    }
  }

  cancelKpModeratorAuth() {
    const kpModal = document.getElementById('kpModeratorAuthModal');
    const roleModal = document.getElementById('roleSelectionModal');
    if (kpModal) kpModal.classList.add('hidden');
    if (this.currentView === 'MARKER') {
      if (typeof markerApp !== 'undefined') markerApp.switchMarkerTab('marking');
    } else {
      if (roleModal) roleModal.classList.remove('hidden');
    }
    this.pendingKpLogin = null;
  }

  toggleKpPinVisibility() {
    const pinInput = document.getElementById('kpAuthPinInput');
    if (pinInput) {
      pinInput.type = pinInput.type === 'password' ? 'text' : 'password';
    }
  }

  openMarkerPortal() {
    this.currentView = 'MARKER';
    try { sessionStorage.setItem('SECS_CURRENT_VIEW', 'MARKER'); } catch (e) {}
    const authModal = document.getElementById('authModal');
    if (authModal) authModal.classList.add('hidden');
    const roleModal = document.getElementById('roleSelectionModal');
    if (roleModal) roleModal.classList.add('hidden');
    const kpModal = document.getElementById('kpModeratorAuthModal');
    if (kpModal) kpModal.classList.add('hidden');

    const mainApp = document.getElementById('mainAppContainer');
    const markerView = document.getElementById('markerViewContainer');
    const hodView = document.getElementById('hodViewContainer');
    const hodLockControls = document.getElementById('hodLockControls');

    if (mainApp) mainApp.classList.remove('hidden');
    if (markerView) markerView.classList.remove('hidden');
    if (hodView) hodView.classList.add('hidden');
    if (hodLockControls) hodLockControls.classList.add('hidden');

    // Strict Gold Standard: Hide administrative Papers Hub button from markers
    const btnManageExams = document.getElementById('btnOpenManageExams');
    if (btnManageExams) btnManageExams.classList.add('hidden');

    // Navigation clean-up: Hide redundant Switch to Marker, show Switch to HOD Hub
    const btnSwitchMarker = document.getElementById('btnSwitchToMarker');
    const btnSwitchHod = document.getElementById('btnSwitchToHod');
    if (btnSwitchMarker) btnSwitchMarker.classList.add('hidden');
    if (btnSwitchHod) btnSwitchHod.classList.remove('hidden');

    const roleBadge = document.getElementById('globalCurrentRoleBadge');
    if (roleBadge) {
      const isVerifiedKP = auth.canModerate();
      const kpBadge = isVerifiedKP ? ' [KP Moderator]' : '';
      roleBadge.textContent = `${auth.session.markerCode} (${auth.session.markerName})${kpBadge}`;
      roleBadge.className = isVerifiedKP
        ? 'px-2.5 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800 border border-purple-300 shrink-0 whitespace-nowrap'
        : 'px-2.5 py-1 text-xs font-semibold rounded-full bg-sky-100 text-sky-800 border border-sky-300 shrink-0 whitespace-nowrap';
    }

    const state = db.getState();
    const examHeader = document.getElementById('globalExamTitleHeader');
    if (examHeader) examHeader.textContent = state.config.examTitle || state.title || 'Paper 1 (Writing) Exam';

    // Populate and sync the global exam selector dropdown for markers
    this.renderGlobalExamSelector();

    markerApp.init();
  }

  openHodHub() {
    this.currentView = 'HOD';
    try { sessionStorage.setItem('SECS_CURRENT_VIEW', 'HOD'); } catch (e) {}
    const authModal = document.getElementById('authModal');
    if (authModal) authModal.classList.add('hidden');
    const roleModal = document.getElementById('roleSelectionModal');
    if (roleModal) roleModal.classList.add('hidden');
    const kpModal = document.getElementById('kpModeratorAuthModal');
    if (kpModal) kpModal.classList.add('hidden');

    const mainApp = document.getElementById('mainAppContainer');
    const markerView = document.getElementById('markerViewContainer');
    const hodView = document.getElementById('hodViewContainer');
    const hodLockControls = document.getElementById('hodLockControls');

    if (mainApp) mainApp.classList.remove('hidden');
    if (markerView) markerView.classList.add('hidden');
    if (hodView) hodView.classList.remove('hidden');
    if (hodLockControls) hodLockControls.classList.remove('hidden');

    // Show administrative Papers Hub button for HOD
    const btnManageExams = document.getElementById('btnOpenManageExams');
    if (btnManageExams) btnManageExams.classList.remove('hidden');

    // Navigation clean-up: Show Switch to Marker, hide Switch to HOD Hub
    const btnSwitchMarker = document.getElementById('btnSwitchToMarker');
    const btnSwitchHod = document.getElementById('btnSwitchToHod');
    if (btnSwitchMarker) btnSwitchMarker.classList.remove('hidden');
    if (btnSwitchHod) btnSwitchHod.classList.add('hidden');

    const roleBadge = document.getElementById('globalCurrentRoleBadge');
    if (roleBadge) {
      roleBadge.textContent = 'HOD Admin & Moderation Hub';
      roleBadge.className = 'px-2.5 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800 border border-purple-300 shrink-0 whitespace-nowrap';
    }

    const state = db.getState();
    const examHeader = document.getElementById('globalExamTitleHeader');
    if (examHeader) examHeader.textContent = state.config.examTitle || state.title || 'Exam Control Portal';

    // Populate global exam selector dropdown for HOD
    this.renderGlobalExamSelector();

    hodApp.init();
  }

  renderGlobalExamSelector() {
    const selector = document.getElementById('globalExamSelect');
    if (!selector) return;

    const exams = db.getExamsList();
    const activeExams = exams.filter(e => !e.isArchived);
    const displayExams = activeExams;
    const active = db.getActiveExam();

    if (displayExams.length === 0) {
      selector.innerHTML = '<option value="">(All Papers Archived - Restore in Papers Hub)</option>';
      return;
    }

    selector.innerHTML = displayExams.map(e => `
      <option value="${e.id}" ${active && !active.isArchived && e.id === active.id ? 'selected' : ''}>
        📄 ${e.level || 'P4'} ${e.subject || 'MT'}: ${e.title} (${e.totalStudents} pupils, ${e.markedCount} marked)
      </option>
    `).join('');
  }

  handleGlobalExamSwitch(examId) {
    if (!examId) return;
    db.switchExam(examId);

    if (auth && auth.session) {
      auth.session.examId = examId;
      if (auth.isMarker()) {
        const newExam = db.getActiveExam();
        const marker = (newExam && Array.isArray(newExam.markers))
          ? newExam.markers.find(m => m.code === auth.session.markerCode)
          : null;
        auth.session.isKP = marker ? !!marker.isKP : false;
        auth.session.kpVerified = false; // Strictly reset verified status so each paper enforces its own HOD-set PIN!
      }
      auth.saveSession();
    }

    const exam = db.getActiveExam();
    const examHeader = document.getElementById('globalExamTitleHeader');
    if (examHeader && exam) {
      examHeader.textContent = exam.config.examTitle || exam.title || 'Exam Control Portal';
    }

    this.renderGlobalExamSelector();

    if (this.currentView === 'MARKER') {
      markerApp.init();
      this.showToast(`Switched active paper to: ${exam.title}`, 'info');
    } else if (this.currentView === 'HOD') {
      hodApp.handleExamSwitch(examId);
    }
  }

  openUserManualModal() {
    const modal = document.getElementById('userManualModal');
    if (modal) modal.classList.remove('hidden');
  }

  closeUserManualModal() {
    const modal = document.getElementById('userManualModal');
    if (modal) modal.classList.add('hidden');
  }

  openElevateHodModal() {
    const modal = document.getElementById('elevateToHodModal');
    const input = document.getElementById('elevateHodPassInput');
    const err = document.getElementById('elevateHodError');
    if (err) err.classList.add('hidden');
    if (input) input.value = '';
    if (modal) {
      modal.classList.remove('hidden');
      setTimeout(() => input && input.focus(), 60);
    }
  }

  closeElevateHodModal() {
    const modal = document.getElementById('elevateToHodModal');
    if (modal) modal.classList.add('hidden');
  }

  submitElevateHod() {
    const input = document.getElementById('elevateHodPassInput');
    const err = document.getElementById('elevateHodError');
    const val = input ? input.value.trim() : '';
    if (!val) {
      if (err) {
        err.textContent = 'Please enter the HOD passcode.';
        err.classList.remove('hidden');
      }
      return;
    }
    if (auth.verifyHODPasscode(val)) {
      auth.loginAsHOD();
      this.closeElevateHodModal();
      this.openHodHub();
    } else {
      if (err) {
        err.textContent = 'Access Denied: Incorrect HOD passcode.';
        err.classList.remove('hidden');
      }
      if (input) {
        input.value = '';
        input.focus();
      }
    }
  }

  logout() {
    auth.logout();
    try {
      sessionStorage.removeItem('SECS_CURRENT_VIEW');
      sessionStorage.removeItem('SECS_HOD_ACTIVE_TAB');
      sessionStorage.removeItem('SECS_MARKER_STUDENT_ID');
      sessionStorage.removeItem('SECS_MARKER_CLASS_FILTER');
    } catch (e) {}
    this.showAuthModal();
  }

  openSharedSyncModal() {
    const modal = document.getElementById('sharedSyncModal');
    if (!modal) return;
    this.renderSharedSyncModalContent();
    modal.classList.remove('hidden');
  }

  closeSharedSyncModal() {
    const modal = document.getElementById('sharedSyncModal');
    if (modal) modal.classList.add('hidden');
  }

  renderSharedSyncModalContent() {
    if (typeof syncService === 'undefined') return;

    const statusText = document.getElementById('syncModalStatusText');
    const folderText = document.getElementById('syncModalFolderName');
    const activeMarkersEl = document.getElementById('syncModalActiveMarkers');
    const lastSyncEl = document.getElementById('syncModalLastSync');
    const btnConnect = document.getElementById('btnSyncModalConnect');
    const btnDisconnect = document.getElementById('btnSyncModalDisconnect');
    const btnPublish = document.getElementById('btnSyncModalPublish');
    const btnForce = document.getElementById('btnSyncModalForceSync');

    const isConnected = syncService.isConnected();
    if (statusText) {
      statusText.textContent = isConnected ? 'CONNECTED' : (syncService.status === 'CONNECTING' ? 'CONNECTING...' : 'DISCONNECTED (Local Only)');
      statusText.className = isConnected 
        ? 'font-bold px-2.5 py-0.5 rounded-full text-[11px] bg-emerald-100 text-emerald-800'
        : 'font-bold px-2.5 py-0.5 rounded-full text-[11px] bg-slate-200 text-slate-700';
    }
    if (folderText) folderText.textContent = syncService.folderName || 'None linked yet';
    if (activeMarkersEl) activeMarkersEl.textContent = Object.keys(syncService.activeMarkers || {}).length;
    if (lastSyncEl) lastSyncEl.textContent = syncService.lastSyncTime ? syncService.lastSyncTime.toLocaleTimeString('en-SG') : 'Never';

    if (btnConnect) {
      if (isConnected) btnConnect.classList.add('hidden');
      else btnConnect.classList.remove('hidden');
    }
    if (btnDisconnect) {
      if (isConnected) btnDisconnect.classList.remove('hidden');
      else btnDisconnect.classList.add('hidden');
    }
    if (btnPublish) {
      if (isConnected && typeof auth !== 'undefined' && auth.isHOD()) btnPublish.classList.remove('hidden');
      else btnPublish.classList.add('hidden');
    }
    if (btnForce) {
      if (isConnected) btnForce.classList.remove('hidden');
      else btnForce.classList.add('hidden');
    }
  }

  showToast(message, type = 'info') {
    const toast = document.getElementById('systemToast');
    if (!toast) return;
    toast.textContent = message;
    toast.className = `fixed bottom-6 right-6 z-50 text-white text-xs font-medium px-4 py-2.5 rounded-xl shadow-xl transition-all duration-300 transform translate-y-0 opacity-100 flex items-center gap-2 border pointer-events-auto ${
      type === 'success' ? 'bg-emerald-900 border-emerald-600' :
      type === 'error' ? 'bg-rose-900 border-rose-600' : 'bg-slate-900 border-slate-700'
    }`;
    setTimeout(() => {
      toast.classList.add('translate-y-24', 'opacity-0');
      toast.classList.remove('translate-y-0', 'opacity-100');
    }, 3200);
  }
}

const app = new AppController();
window.app = app;
document.addEventListener('DOMContentLoaded', () => {
  app.init();
});
