/**
 * SECS - Authentication & Role Access Controller
 * Enforces role-based passcode gate and segregates Marker vs HOD roles.
 * Supports Multi-Exam sessions and Key Personnel (KP) 2-step Moderator authorization.
 */

class AuthService {
  constructor() {
    this.session = {
      isAuthenticated: false,
      role: null, // 'hod' | 'marker'
      markerCode: null,
      markerName: null,
      examId: null,
      isKP: false,
      kpVerified: false
    };
    this.restoreSession();
  }

  saveSession() {
    try {
      if (this.session && this.session.isAuthenticated) {
        sessionStorage.setItem('SECS_AUTH_SESSION', JSON.stringify(this.session));
      } else {
        sessionStorage.removeItem('SECS_AUTH_SESSION');
      }
    } catch (e) {
      console.warn('[AuthService] Could not save session to sessionStorage:', e);
    }
  }

  restoreSession() {
    try {
      const saved = sessionStorage.getItem('SECS_AUTH_SESSION');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.isAuthenticated) {
          this.session = parsed;
          return true;
        }
      }
    } catch (e) {
      console.warn('[AuthService] Could not restore session from sessionStorage:', e);
    }
    return false;
  }

  verifyPasscode(inputCode, examId = null) {
    const trimmed = (inputCode || '').trim();
    if (!trimmed) {
      return { success: false, error: 'Please enter your passcode.' };
    }

    // 1. HOD Master Passcode check
    if (trimmed.toUpperCase() === SECS_CONFIG.HOD_PASSCODE.toUpperCase()) {
      this.session.isAuthenticated = true;
      this.session.role = 'hod';
      this.session.markerCode = 'HOD';
      this.session.markerName = 'Head of Department / Lead';
      this.session.isKP = true;
      this.session.kpVerified = true;
      this.saveSession();
      return { success: true, role: 'hod' };
    }

    // 2. Paper-specific Marker Passcode check
    if (typeof db !== 'undefined') {
      const activeExam = examId ? (db.getRootState()?.exams?.find(e => e.id === examId) || db.getActiveExam()) : db.getActiveExam();
      if (activeExam && db.verifyPaperMarkerPasscode(activeExam.id, trimmed)) {
        this.session.isAuthenticated = true;
        this.session.role = 'marker';
        this.saveSession();
        return { success: true, role: 'marker' };
      }

      // Check across any registered exam papers if examId was not explicitly set
      const root = db.getRootState();
      if (root && Array.isArray(root.exams)) {
        const match = root.exams.find(e => db.verifyPaperMarkerPasscode(e.id, trimmed));
        if (match) {
          this.session.isAuthenticated = true;
          this.session.role = 'marker';
          this.saveSession();
          return { success: true, role: 'marker' };
        }
      }
    }

    // 3. Fallback to default marker passcode only if database has no registered exams
    const rootState = (typeof db !== 'undefined') ? db.getRootState() : null;
    const hasExams = rootState && Array.isArray(rootState.exams) && rootState.exams.length > 0;
    if (!hasExams && (trimmed === SECS_CONFIG.MARKER_PASSCODE || trimmed === '1132')) {
      this.session.isAuthenticated = true;
      this.session.role = 'marker';
      this.saveSession();
      return { success: true, role: 'marker' };
    }

    return { success: false, error: 'Incorrect passcode. Please verify with your Exam Lead or HOD.' };
  }

  verifyHODPasscode(inputCode) {
    const trimmed = (inputCode || '').trim();
    return trimmed.toUpperCase() === SECS_CONFIG.HOD_PASSCODE.toUpperCase();
  }

  verifyModeratorPin(examId, inputPin) {
    if (typeof db === 'undefined') return false;
    const ok = db.verifyPaperModeratorPin(examId, inputPin);
    if (ok) {
      this.session.isKP = true;
      this.session.kpVerified = true;
      this.saveSession();
      return true;
    }
    return false;
  }

  loginAsHOD(examId) {
    if (!this.session.isAuthenticated) return false;
    if (examId && typeof db !== 'undefined') db.switchExam(examId);
    const activeExam = typeof db !== 'undefined' ? db.getActiveExam() : null;
    this.session.role = 'hod';
    this.session.markerCode = 'HOD';
    this.session.markerName = 'Head of Department / Lead';
    this.session.examId = activeExam ? activeExam.id : null;
    this.session.isKP = true;
    this.session.kpVerified = true;
    this.saveSession();
    return true;
  }

  loginAsMarker(markerCode, markerName, examId, isKpVerified = false) {
    if (!this.session.isAuthenticated) return false;
    if (examId && typeof db !== 'undefined') db.switchExam(examId);
    const activeExam = typeof db !== 'undefined' ? db.getActiveExam() : null;
    const marker = (activeExam && Array.isArray(activeExam.markers)) 
      ? activeExam.markers.find(m => m.code === markerCode) 
      : null;
    const isKP = marker ? !!marker.isKP : false;

    this.session.role = 'marker';
    this.session.markerCode = markerCode;
    this.session.markerName = markerName || (marker ? marker.name : `Marker ${markerCode}`);
    this.session.examId = activeExam ? activeExam.id : null;
    this.session.isKP = isKP;
    this.session.kpVerified = isKP ? !!isKpVerified : false;
    this.saveSession();
    return true;
  }

  elevateToVerifiedKP() {
    this.session.isKP = true;
    this.session.kpVerified = true;
    this.saveSession();
  }

  logout() {
    this.session = {
      isAuthenticated: false,
      role: null,
      markerCode: null,
      markerName: null,
      examId: null,
      isKP: false,
      kpVerified: false
    };
    this.saveSession();
  }

  isHOD() {
    return this.session.isAuthenticated && this.session.role === 'hod';
  }

  isMarker() {
    return this.session.isAuthenticated && this.session.role === 'marker';
  }

  canModerate() {
    return this.session.isAuthenticated && (this.session.role === 'hod' || (this.session.isKP === true && this.session.kpVerified === true));
  }
}

const auth = new AuthService();
window.auth = auth;
