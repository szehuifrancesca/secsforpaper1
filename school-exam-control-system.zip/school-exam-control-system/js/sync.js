/**
 * SECS - Shared Folder Live-Sync Engine (js/sync.js)
 * Enables multi-marker concurrent grading and HOD real-time live monitoring
 * via school shared network folders (e.g. S:\...) without servers or collisions.
 */

class SyncService {
  constructor() {
    this.status = 'DISCONNECTED'; // 'DISCONNECTED' | 'CONNECTING' | 'CONNECTED' | 'SYNCING' | 'ERROR'
    this.folderHandle = null;
    this.syncDirHandle = null;
    this.folderName = '';
    this.lastSyncTime = null;
    this.pollIntervalMs = 2000; // 2-second high-responsiveness polling
    this.pollTimer = null;
    this.isPolling = false;
    this.fileTimestamps = {};
    this.activityFeed = []; // Array of { id, time, markerCode, scriptId, text, type }
    this.activeMarkers = {}; // markerCode -> { lastSeen, count }
    this.statusListeners = [];
    this.dbName = 'SECS_SHARED_SYNC_DB';
    this.storeName = 'handles';

    // Zero-latency cross-tab & cross-browser focus listener
    if (typeof window !== 'undefined') {
      window.addEventListener('focus', () => {
        if (this.isConnected()) this.pollOnce(true);
      });
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && this.isConnected()) {
          this.pollOnce(true);
        }
      });
    }

    // Auto-initialize connection from saved IndexedDB handle if available
    this.initSavedConnection();
  }

  // =========================================================================
  // 1. INDEXEDDB DIRECTORY HANDLE PERSISTENCE
  // =========================================================================

  openIdb() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        return resolve(null);
      }
      const req = indexedDB.open(this.dbName, 1);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    });
  }

  async saveHandleToIdb(handle) {
    try {
      const db = await this.openIdb();
      if (!db) return;
      const tx = db.transaction(this.storeName, 'readwrite');
      tx.objectStore(this.storeName).put(handle, 'sharedFolderHandle');
    } catch (e) {
      console.warn('[SyncService] Could not save handle to IDB:', e);
    }
  }

  async getHandleFromIdb() {
    try {
      const db = await this.openIdb();
      if (!db) return null;
      return new Promise((resolve) => {
        const tx = db.transaction(this.storeName, 'readonly');
        const req = tx.objectStore(this.storeName).get('sharedFolderHandle');
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => resolve(null);
      });
    } catch (e) {
      return null;
    }
  }

  async clearHandleFromIdb() {
    try {
      const db = await this.openIdb();
      if (!db) return;
      const tx = db.transaction(this.storeName, 'readwrite');
      tx.objectStore(this.storeName).delete('sharedFolderHandle');
    } catch (e) {}
  }

  async initSavedConnection() {
    try {
      const savedHandle = await this.getHandleFromIdb();
      if (savedHandle && typeof savedHandle.queryPermission === 'function') {
        const perm = await savedHandle.queryPermission({ mode: 'readwrite' });
        if (perm === 'granted') {
          await this.attachFolderHandle(savedHandle);
        }
      }
    } catch (e) {
      console.log('[SyncService] No auto-granted folder handle available yet.');
    }
  }

  // =========================================================================
  // 2. FOLDER ATTACHMENT & DISCONNECTION
  // =========================================================================

  async connectSharedFolder() {
    if (!('showDirectoryPicker' in window)) {
      alert('The Shared Folder Live-Sync Engine requires Microsoft Edge or Google Chrome with File System Access enabled.');
      return false;
    }

    try {
      this.setStatus('CONNECTING');
      const dirHandle = await window.showDirectoryPicker({
        mode: 'readwrite',
        startIn: 'documents'
      });

      if (!dirHandle) {
        this.setStatus('DISCONNECTED');
        return false;
      }

      await this.saveHandleToIdb(dirHandle);
      const ok = await this.attachFolderHandle(dirHandle);
      if (ok) {
        this.showToast(`Connected to shared folder: "${dirHandle.name}"`, 'success');
        // If HOD, offer to publish initial roster if not yet created
        this.checkAndPublishMasterIfNeeded();
        return true;
      }
      return false;
    } catch (err) {
      if (err.name === 'AbortError') {
        this.setStatus('DISCONNECTED');
        return false;
      }
      console.error('[SyncService] Folder selection error:', err);
      this.setStatus('ERROR');
      alert(`Could not connect to shared folder: ${err.message}`);
      return false;
    }
  }

  async attachFolderHandle(dirHandle) {
    try {
      let targetDir = dirHandle;
      // Smart resolution: if the user selected the parent workspace containing the dedicated folder, resolve into it
      if (dirHandle.name !== 'EXAM DATA FOLDER (LINK TO THIS FOLDER)') {
        try {
          const dedicatedSub = await dirHandle.getDirectoryHandle('EXAM DATA FOLDER (LINK TO THIS FOLDER)', { create: false });
          if (dedicatedSub) {
            targetDir = dedicatedSub;
          }
        } catch (e) {
          // Folder not present at sub-level, use selected directory directly
        }
      }

      this.folderHandle = targetDir;
      this.folderName = targetDir.name;

      // Access or create 'secs_sync' subfolder inside the selected shared folder
      this.syncDirHandle = await targetDir.getDirectoryHandle('secs_sync', { create: true });

      this.setStatus('CONNECTED');
      this.startPolling();

      // Perform immediate sync pull
      await this.pollOnce();

      return true;
    } catch (err) {
      console.error('[SyncService] Failed attaching sync subfolder:', err);
      this.setStatus('ERROR');
      return false;
    }
  }

  async disconnect() {
    this.stopPolling();
    this.folderHandle = null;
    this.syncDirHandle = null;
    this.folderName = '';
    await this.clearHandleFromIdb();
    this.setStatus('DISCONNECTED');
    this.showToast('Disconnected from shared folder. Now running in Local-Only mode.', 'info');
  }

  isConnected() {
    return this.status === 'CONNECTED' && !!this.syncDirHandle;
  }

  // =========================================================================
  // 3. ATOMIC FILE READ & WRITE OPERATIONS
  // =========================================================================

  async writeJsonFile(fileName, data) {
    if (!this.isConnected()) return false;
    const content = JSON.stringify(data, null, 2);
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const fileHandle = await this.syncDirHandle.getFileHandle(fileName, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(content);
        await writable.close();
        try {
          const file = await fileHandle.getFile();
          this.fileTimestamps[fileName] = `${file.lastModified}_${file.size}`;
        } catch (e) {
          this.fileTimestamps[fileName] = `${Date.now()}_${content.length}`;
        }
        return true;
      } catch (err) {
        if (attempt < 3) {
          await new Promise(r => setTimeout(r, 60 * attempt));
        } else {
          console.error(`[SyncService] Error writing ${fileName} after 3 attempts:`, err);
          return false;
        }
      }
    }
    return false;
  }

  async readJsonFile(fileName) {
    if (!this.isConnected()) return null;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const fileHandle = await this.syncDirHandle.getFileHandle(fileName, { create: false });
        const file = await fileHandle.getFile();
        const text = await file.text();
        if (!text || text.trim() === '') return null;
        return JSON.parse(text);
      } catch (err) {
        if (err.name === 'NotFoundError') return null;
        if (attempt < 2) {
          await new Promise(r => setTimeout(r, 50));
        } else {
          return null;
        }
      }
    }
    return null;
  }

  // =========================================================================
  // 4. MARKER PROGRESS PUSH (Decoupled per marker)
  // =========================================================================

  async pushMarkerMark(student, markerCode) {
    if (!this.isConnected()) return false;
    const mCode = markerCode || (student && student.markerCode) || (auth && auth.session && auth.session.markerCode);
    if (!mCode || !student) return false;

    try {
      const fileName = `marker_${mCode}.json`;
      let currentData = await this.readJsonFile(fileName);
      if (!currentData || !currentData.marks) {
        currentData = {
          markerCode: markerCode,
          markerName: (auth && auth.session && auth.session.markerName) || `Marker ${markerCode}`,
          lastUpdated: new Date().toISOString(),
          marks: {}
        };
      }

      const activeExam = typeof db !== 'undefined' ? db.getActiveExam() : null;
      const currentExamId = activeExam ? activeExam.id : (auth && auth.session && auth.session.examId);

      currentData.marks[student.id] = {
        examId: currentExamId,
        studentId: student.id,
        scriptId: student.scriptId,
        regNo: student.regNo,
        formClass: student.formClass,
        mtClass: student.mtClass,
        score: student.score ? { ...student.score } : null,
        initialScore: student.initialScore ? { ...student.initialScore } : null,
        tags: Array.isArray(student.tags) ? [...student.tags] : [],
        remark: student.remark || '',
        markedAt: student.markedAt || new Date().toISOString()
      };
      currentData.seq = (currentData.seq || 0) + 1;
      currentData.lastUpdated = new Date().toISOString();

      await this.writeJsonFile(fileName, currentData);

      // Record activity locally
      this.addActivityItem({
        id: `act_${Date.now()}_${student.scriptId}`,
        time: new Date().toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        markerCode: markerCode,
        scriptId: student.scriptId,
        text: `${markerCode} marked ${student.scriptId} (${student.formClass}) - ${student.score ? student.score.total : 0} marks`,
        type: 'mark'
      });

      return true;
    } catch (err) {
      console.error('[SyncService] Failed to push marker mark:', err);
      return false;
    }
  }

  // =========================================================================
  // 5. MODERATION PUSH
  // =========================================================================

  async pushModeration(student) {
    if (!this.isConnected() || !student || !student.moderation) return false;

    try {
      const activeExam = typeof db !== 'undefined' ? db.getActiveExam() : null;
      const currentExamId = activeExam ? activeExam.id : (auth && auth.session && auth.session.examId);
      const modBy = student.moderation.moderatorCode || (auth && auth.session && auth.session.markerCode) || 'HOD';

      // 1. Partitioned moderator file: moderation_${modBy}.json (zero file locking contention)
      const perModFile = `moderation_${modBy}.json`;
      let perModData = await this.readJsonFile(perModFile);
      if (!perModData || !perModData.moderations) {
        perModData = {
          moderatorCode: modBy,
          moderatorName: student.moderation.moderatedBy || (auth && auth.session && auth.session.markerName) || `Moderator ${modBy}`,
          lastUpdated: new Date().toISOString(),
          seq: 0,
          moderations: {}
        };
      }

      perModData.moderations[student.id] = {
        examId: currentExamId,
        studentId: student.id,
        scriptId: student.scriptId,
        moderation: { ...student.moderation },
        score: student.score ? { ...student.score } : null,
        status: student.status
      };
      perModData.seq = (perModData.seq || 0) + 1;
      perModData.lastUpdated = new Date().toISOString();
      await this.writeJsonFile(perModFile, perModData);

      // 2. Legacy aggregation file for backwards compatibility
      try {
        const legacyFile = 'moderation.json';
        let currentData = await this.readJsonFile(legacyFile);
        if (!currentData || !currentData.moderations) {
          currentData = {
            lastUpdated: new Date().toISOString(),
            moderations: {}
          };
        }
        currentData.moderations[student.id] = {
          examId: currentExamId,
          studentId: student.id,
          scriptId: student.scriptId,
          moderation: { ...student.moderation },
          score: student.score ? { ...student.score } : null,
          status: student.status
        };
        currentData.lastUpdated = new Date().toISOString();
        await this.writeJsonFile(legacyFile, currentData);
      } catch (legacyErr) {
        console.warn('[SyncService] Legacy moderation.json write skipped:', legacyErr);
      }

      this.addActivityItem({
        id: `act_${Date.now()}_mod_${student.scriptId}`,
        time: new Date().toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        markerCode: modBy,
        scriptId: student.scriptId,
        text: `${modBy} moderated ${student.scriptId}: ${student.moderation.delta > 0 ? '+' : ''}${student.moderation.delta} mark(s)`,
        type: 'moderation'
      });

      return true;
    } catch (err) {
      console.error('[SyncService] Failed to push moderation:', err);
      return false;
    }
  }

  // =========================================================================
  // 6. MASTER EXAM SETUP PUBLISHING (HOD Workflow)
  // =========================================================================

  async publishAllExams() {
    if (!this.isConnected()) {
      const connected = await this.connectSharedFolder();
      if (!connected) return { success: false, error: 'Not connected to shared folder.' };
    }
    try {
      const root = db.getRootState();
      const exams = (root && Array.isArray(root.exams)) ? root.exams : [];
      if (exams.length === 0) return { success: false, error: 'No active exams to publish.' };

      const manifest = [];
      const nowStr = new Date().toISOString();

      for (const exam of exams) {
        if (exam.isArchived) continue;
        exam.lastPublishedAt = nowStr;
        const masterPayload = {
          examId: exam.id,
          title: exam.title,
          level: exam.level || 'Primary 4',
          subject: exam.subject || 'Mother Tongue',
          paper: exam.paper || 'Paper 1 (Writing)',
          academicYear: exam.academicYear || '2026',
          config: exam.config,
          markers: exam.markers || [],
          feedbackTags: exam.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS,
          studentRoster: (exam.students || []).map(s => ({
            id: s.id,
            scriptId: s.scriptId,
            name: s.name,
            chineseName: s.chineseName || '',
            formClass: s.formClass,
            mtClass: s.mtClass,
            regNo: s.regNo
          })),
          publishedAt: nowStr,
          publishedBy: 'HOD'
        };

        await this.writeJsonFile(`exam_master_${exam.id}.json`, masterPayload);
        manifest.push({
          id: exam.id,
          title: exam.title,
          level: exam.level || 'Primary 4',
          subject: exam.subject || 'Mother Tongue',
          paper: exam.paper || 'Paper 1 (Writing)',
          totalStudents: (exam.students || []).length,
          publishedAt: nowStr
        });
      }

      db.save();

      // Also publish active exam as exam_master_config.json
      const activeExam = db.getActiveExam();
      if (activeExam) {
        const activePayload = {
          examId: activeExam.id,
          title: activeExam.title,
          level: activeExam.level || 'Primary 4',
          subject: activeExam.subject || 'Mother Tongue',
          paper: activeExam.paper || 'Paper 1 (Writing)',
          academicYear: activeExam.academicYear || '2026',
          config: activeExam.config,
          markers: activeExam.markers || [],
          feedbackTags: activeExam.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS,
          studentRoster: (activeExam.students || []).map(s => ({
            id: s.id,
            scriptId: s.scriptId,
            name: s.name,
            chineseName: s.chineseName || '',
            formClass: s.formClass,
            mtClass: s.mtClass,
            regNo: s.regNo
          })),
          publishedAt: nowStr,
          publishedBy: 'HOD'
        };
        await this.writeJsonFile('exam_master_config.json', activePayload);
      }

      // Preserve deletedExamIds tombstone list if present
      let existingManifest = await this.readJsonFile('exams_manifest.json');
      let deletedExamIds = (existingManifest && Array.isArray(existingManifest.deletedExamIds)) ? existingManifest.deletedExamIds : [];

      // Write exams_manifest.json
      await this.writeJsonFile('exams_manifest.json', { exams: manifest, deletedExamIds: deletedExamIds, publishedAt: nowStr });

      this.showToast(`Published all ${manifest.length} exam papers to Shared Folder!`, 'success');
      this.dispatchSyncEvent({ type: 'exams_published', count: manifest.length, manifest });
      return { success: true, count: manifest.length };
    } catch (err) {
      console.error('[SyncService] Failed to publish all exams:', err);
      return { success: false, error: err.message };
    }
  }

  async publishSingleExam(examId) {
    if (!this.isConnected()) {
      const connected = await this.connectSharedFolder();
      if (!connected) return { success: false, error: 'Not connected to shared folder.' };
    }
    try {
      const root = db.getRootState();
      const exams = (root && Array.isArray(root.exams)) ? root.exams : [];
      const exam = exams.find(e => e.id === examId);
      if (!exam) return { success: false, error: 'Examination paper not found.' };

      const nowStr = new Date().toISOString();
      const masterPayload = {
        examId: exam.id,
        title: exam.title,
        level: exam.level || 'Primary 4',
        subject: exam.subject || 'Mother Tongue',
        paper: exam.paper || 'Paper 1 (Writing)',
        academicYear: exam.academicYear || '2026',
        config: exam.config,
        security: exam.security || (typeof db !== 'undefined' ? db.getPaperSecurity(exam.id) : { markerPasscode: '1132', moderatorPin: 'MOD88' }),
        markers: exam.markers || [],
        feedbackTags: exam.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS,
        studentRoster: (exam.students || []).map(s => ({
          id: s.id,
          scriptId: s.scriptId,
          name: s.name,
          chineseName: s.chineseName || '',
          formClass: s.formClass,
          mtClass: s.mtClass,
          regNo: s.regNo
        })),
        publishedAt: nowStr,
        publishedBy: 'HOD'
      };

      await this.writeJsonFile(`exam_master_${exam.id}.json`, masterPayload);

      // Update or create exams_manifest.json
      let manifest = await this.readJsonFile('exams_manifest.json');
      let manifestExams = (manifest && Array.isArray(manifest.exams)) ? manifest.exams : [];
      let deletedExamIds = (manifest && Array.isArray(manifest.deletedExamIds)) ? manifest.deletedExamIds : [];
      // Remove this exam from tombstone list if explicitly republished
      deletedExamIds = deletedExamIds.filter(id => id !== exam.id);
      
      const newEntry = {
        id: exam.id,
        title: exam.title,
        level: exam.level || 'Primary 4',
        subject: exam.subject || 'Mother Tongue',
        paper: exam.paper || 'Paper 1 (Writing)',
        totalStudents: (exam.students || []).length,
        security: masterPayload.security,
        publishedAt: nowStr
      };

      const existingIdx = manifestExams.findIndex(m => m.id === exam.id);
      if (existingIdx !== -1) {
        manifestExams[existingIdx] = newEntry;
      } else {
        manifestExams.push(newEntry);
      }

      await this.writeJsonFile('exams_manifest.json', { exams: manifestExams, deletedExamIds: deletedExamIds, publishedAt: nowStr });

      // Update exam in local database
      exam.lastPublishedAt = nowStr;
      exam.isArchived = false;
      db.save();

      this.showToast(`Published "${exam.title}" to Shared Folder!`, 'success');
      this.dispatchSyncEvent({ type: 'exam_published', examId: exam.id, title: exam.title });
      return { success: true, exam };
    } catch (err) {
      console.error('[SyncService] Failed to publish single exam:', err);
      return { success: false, error: err.message };
    }
  }

  async deleteExamFromSharedFolder(examId) {
    if (!this.isConnected() || !this.syncDirHandle) return { success: false, error: 'Not connected to shared folder.' };
    try {
      const nowStr = new Date().toISOString();

      // 1. Read current manifest
      let manifest = await this.readJsonFile('exams_manifest.json');
      let manifestExams = (manifest && Array.isArray(manifest.exams)) ? manifest.exams : [];
      let deletedExamIds = (manifest && Array.isArray(manifest.deletedExamIds)) ? manifest.deletedExamIds : [];

      // 2. Remove deleted exam from manifest active list
      manifestExams = manifestExams.filter(e => e.id !== examId);

      // 3. Record in tombstone list so all connected devices/browsers purge it
      if (!deletedExamIds.includes(examId)) {
        deletedExamIds.push(examId);
      }

      // 4. Write updated manifest back to shared folder
      await this.writeJsonFile('exams_manifest.json', {
        exams: manifestExams,
        deletedExamIds: deletedExamIds,
        publishedAt: nowStr,
        lastDeletedExamId: examId,
        lastDeletedAt: nowStr
      });

      // 5. Attempt to physically remove the exam master JSON file from shared folder
      try {
        if (typeof this.syncDirHandle.removeEntry === 'function') {
          await this.syncDirHandle.removeEntry(`exam_master_${examId}.json`);
        }
      } catch (rmErr) {
        // Ignored if file does not exist on disk
      }

      // 6. Invalidate memory cache so local polling does not re-read
      delete this.fileTimestamps[`exam_master_${examId}.json`];
      delete this.fileTimestamps['exams_manifest.json'];

      this.dispatchSyncEvent({ type: 'exam_deleted_from_shared', examId });
      return { success: true };
    } catch (err) {
      console.error('[SyncService] Failed to delete exam from shared folder:', err);
      return { success: false, error: err.message };
    }
  }

  getPaperPublishStatus(examId) {
    if (!this.isConnected()) {
      return { isConnected: false, isPublished: false, publishedAt: null, totalStudents: 0, statusText: 'Not Connected' };
    }
    const root = db.getRootState();
    const exam = (root && Array.isArray(root.exams)) ? root.exams.find(e => e.id === examId) : null;
    if (!exam) {
      return { isConnected: true, isPublished: false, publishedAt: null, totalStudents: 0, statusText: 'Paper Not Found' };
    }

    const isPub = !!exam.lastPublishedAt;
    return {
      isConnected: true,
      isPublished: isPub,
      publishedAt: exam.lastPublishedAt || null,
      totalStudents: (exam.students || []).length,
      statusText: isPub ? 'Published to Shared Folder' : 'Local Draft (Not in Shared Folder)'
    };
  }

  async publishExamMaster() {
    return await this.publishAllExams();
  }

  async checkAndPublishMasterIfNeeded() {
    if (!auth || !auth.isHOD()) return;
    const existing = await this.readJsonFile('exam_master_config.json');
    if (!existing) {
      // Auto-publish active exam so markers can immediately connect
      await this.publishExamMaster();
    }
  }

  // =========================================================================
  // 7. BACKGROUND LIVE POLLING & MULTI-USER MERGE
  // =========================================================================

  startPolling() {
    this.stopPolling();
    this.pollTimer = setInterval(() => {
      this.pollOnce();
    }, this.pollIntervalMs);
  }

  stopPolling() {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
  }

  async pollOnce(force = false) {
    if (!this.isConnected()) return;
    if (this.isPolling) {
      if (this.pollingStartedAt && (Date.now() - this.pollingStartedAt > 10000)) {
        console.warn('[SyncService] Watchdog: Resetting hung polling lock after 10s timeout.');
        this.isPolling = false;
      } else {
        return;
      }
    }
    this.isPolling = true;
    this.pollingStartedAt = Date.now();

    if (force) {
      this.fileTimestamps = {};
    }

    try {
      const activeExam = db.getActiveExam();
      if (!activeExam || !Array.isArray(activeExam.students)) {
        this.isPolling = false;
        return;
      }

      let changesDetected = 0;
      const discoveredMarkers = {};

      // Scan directory entries in 'secs_sync'
      for await (const [name, handle] of this.syncDirHandle.entries()) {
        if (handle.kind === 'file') {
          // A. Check marker files (e.g. marker_M01.json)
          if (name.startsWith('marker_') && name.endsWith('.json')) {
            const markerCode = name.replace('marker_', '').replace('.json', '');
            try {
              const file = await handle.getFile();
              const fileKey = `${file.lastModified}_${file.size}`;

              if (!this.fileTimestamps[name] || this.fileTimestamps[name] !== fileKey) {
                const text = await file.text();
                if (text && text.trim()) {
                  const data = JSON.parse(text);
                  if (data && data.marks) {
                    const merged = this.mergeMarkerData(data, activeExam);
                    changesDetected += merged.changes;
                    discoveredMarkers[markerCode] = {
                      lastSeen: data.lastUpdated || new Date(file.lastModified).toISOString(),
                      count: Object.keys(data.marks).length
                    };
                    this.fileTimestamps[name] = fileKey;
                  }
                }
              } else {
                // Known timestamp, retain active marker stats
                if (this.activeMarkers[markerCode]) {
                  discoveredMarkers[markerCode] = this.activeMarkers[markerCode];
                }
              }
            } catch (fileErr) {
              console.warn(`[SyncService] Could not parse ${name}:`, fileErr);
            }
          }

          // B. Check moderation files (supports partitioned moderation_${code}.json and legacy moderation.json)
          if ((name.startsWith('moderation_') && name.endsWith('.json')) || name === 'moderation.json') {
            try {
              const file = await handle.getFile();
              const fileKey = `${file.lastModified}_${file.size}`;
              if (!this.fileTimestamps[name] || this.fileTimestamps[name] !== fileKey) {
                const text = await file.text();
                if (text && text.trim()) {
                  const modData = JSON.parse(text);
                  if (modData && modData.moderations) {
                    const modChanges = this.mergeModerationData(modData, activeExam);
                    changesDetected += modChanges;
                    this.fileTimestamps[name] = fileKey;
                  }
                }
              }
            } catch (modErr) {
              console.warn(`[SyncService] Could not parse moderation file ${name}:`, modErr);
            }
          }

          // C. Check Master Exam Setup & Manifest files
          if (name === 'exams_manifest.json') {
            try {
              const file = await handle.getFile();
              const fileKey = `${file.lastModified}_${file.size}`;
              if (!this.fileTimestamps[name] || this.fileTimestamps[name] !== fileKey) {
                const text = await file.text();
                if (text && text.trim()) {
                  const manifestData = JSON.parse(text);
                  const deletedSet = new Set(Array.isArray(manifestData.deletedExamIds) ? manifestData.deletedExamIds : []);
                  const root = db.getRootState();

                  // 1. Immediately purge any local exams that were deleted by HOD on another device
                  if (root && Array.isArray(root.exams) && deletedSet.size > 0) {
                    const origLen = root.exams.length;
                    root.exams = root.exams.filter(e => !deletedSet.has(e.id));
                    if (root.exams.length !== origLen) {
                      changesDetected++;
                      if (deletedSet.has(root.activeExamId)) {
                        const nextActive = root.exams.find(e => !e.isArchived) || root.exams[0];
                        root.activeExamId = nextActive ? nextActive.id : null;
                      }
                    }
                  }

                  if (manifestData && Array.isArray(manifestData.exams)) {
                    for (const mExam of manifestData.exams) {
                      if (deletedSet.has(mExam.id)) continue;
                      const examFileName = `exam_master_${mExam.id}.json`;
                      const mExamData = await this.readJsonFile(examFileName);
                      if (mExamData) {
                        const examChanges = this.mergeExamMaster(mExamData);
                        changesDetected += examChanges;
                      }
                    }

                    // Clean up any orphan local starter demo seed that is not in the shared folder manifest
                    if (root && Array.isArray(root.exams) && manifestData.exams.length > 0) {
                      const manifestIds = new Set(manifestData.exams.filter(e => !deletedSet.has(e.id)).map(e => e.id));
                      const origLen = root.exams.length;
                      root.exams = root.exams.filter(e => {
                        if (deletedSet.has(e.id)) return false;
                        if (manifestIds.has(e.id)) return true;
                        // Purge default unedited demo template when connected to shared manifest
                        if (e.id === 'exam_2026_p4_mt_p1') return false;
                        // For markers/landing view, strictly align with the shared manifest
                        if (typeof auth === 'undefined' || !auth.isHOD()) {
                          return false;
                        }
                        return true;
                      });
                      if (root.exams.length !== origLen) {
                        changesDetected++;
                        if (!manifestIds.has(root.activeExamId) && root.exams[0]) {
                          root.activeExamId = root.exams[0].id;
                        }
                      }
                    }

                    this.fileTimestamps[name] = fileKey;
                  }
                }
              }
            } catch (manifestErr) {
              console.warn('[SyncService] Could not parse exams_manifest.json:', manifestErr);
            }
          } else if ((name.startsWith('exam_master_') || name === 'exam_master_config.json') && name.endsWith('.json')) {
            try {
              const file = await handle.getFile();
              const fileKey = `${file.lastModified}_${file.size}`;
              if (!this.fileTimestamps[name] || this.fileTimestamps[name] !== fileKey) {
                const text = await file.text();
                if (text && text.trim()) {
                  const masterData = JSON.parse(text);
                  if (masterData && masterData.examId && Array.isArray(masterData.studentRoster)) {
                    // Check if exam is tombstoned/deleted in manifest
                    let isDeletedExam = false;
                    try {
                      const mf = await this.readJsonFile('exams_manifest.json');
                      if (mf && Array.isArray(mf.deletedExamIds) && mf.deletedExamIds.includes(masterData.examId)) {
                        isDeletedExam = true;
                      }
                    } catch (e) {}

                    if (!isDeletedExam) {
                      const examChanges = this.mergeExamMaster(masterData);
                      changesDetected += examChanges;
                    }
                    this.fileTimestamps[name] = fileKey;
                  }
                }
              }
            } catch (masterErr) {
              console.warn(`[SyncService] Could not parse master config ${name}:`, masterErr);
            }
          }
        }
      }

      this.activeMarkers = { ...this.activeMarkers, ...discoveredMarkers };
      this.lastSyncTime = new Date();

      if (changesDetected > 0) {
        db.save(); // Persist merged state into local storage
        this.dispatchSyncEvent({
          changesCount: changesDetected,
          activeMarkers: this.activeMarkers,
          lastSyncTime: this.lastSyncTime
        });
      }

      this.notifyStatusChange();
    } catch (err) {
      console.error('[SyncService] Error during pollOnce:', err);
    } finally {
      this.isPolling = false;
    }
  }

  mergeExamMaster(masterData) {
    if (!masterData || !masterData.examId) return 0;
    const root = db.getRootState();
    if (!root || !Array.isArray(root.exams)) return 0;

    let exam = root.exams.find(e => e.id === masterData.examId);
    let changed = 0;

    if (!exam) {
      // New exam paper broadcast by HOD! Add it directly to local exam registry
      exam = {
        id: masterData.examId,
        title: masterData.title,
        level: masterData.level || 'Primary 4',
        subject: masterData.subject || 'Mother Tongue',
        paper: masterData.paper || 'Paper 1 (Writing)',
        academicYear: masterData.academicYear || '2026',
        semester: 'Mid-Year',
        isArchived: false,
        archivedAt: null,
        config: masterData.config,
        security: masterData.security || { markerPasscode: '1132', moderatorPin: 'MOD88', requireModeratorPin: true },
        markers: masterData.markers || [],
        feedbackTags: masterData.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS,
        lastPublishedAt: masterData.publishedAt,
        students: (masterData.studentRoster || []).map(r => ({
          ...r,
          status: 'unmarked',
          markerCode: null,
          score: { content: null, language: null, total: null, pct: null },
          initialScore: null,
          tags: [],
          remark: '',
          markedAt: null,
          moderation: { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatorCode: null, moderatedBy: null, moderatedAt: null, originalScore: null }
        }))
      };
      root.exams.push(exam);
      changed++;
    } else {
      // Exam exists; check if published version from HOD has newer specs or updated roster
      const isNewer = !exam.lastPublishedAt || !masterData.publishedAt || new Date(masterData.publishedAt) >= new Date(exam.lastPublishedAt);
      if (exam.isArchived) { exam.isArchived = false; exam.archivedAt = null; changed++; }
      if (isNewer) {
        if (masterData.title && masterData.title !== exam.title) { exam.title = masterData.title; changed++; }
        if (masterData.config) { exam.config = { ...masterData.config }; changed++; }
        if (masterData.security) { exam.security = { ...masterData.security }; changed++; }
        if (Array.isArray(masterData.markers) && masterData.markers.length > 0) { exam.markers = masterData.markers; changed++; }
        if (masterData.feedbackTags) { exam.feedbackTags = masterData.feedbackTags; changed++; }
        exam.lastPublishedAt = masterData.publishedAt || new Date().toISOString();

        // Sync pupil roster without disturbing marked scores
        const studentMap = new Map(exam.students.map(s => [s.id, s]));
        const incomingIds = new Set();

        (masterData.studentRoster || []).forEach(r => {
          incomingIds.add(r.id);
          if (studentMap.has(r.id)) {
            const existing = studentMap.get(r.id);
            let pupilChanged = false;
            if (r.name && r.name !== existing.name) { existing.name = r.name; pupilChanged = true; }
            if (r.chineseName !== undefined && r.chineseName !== existing.chineseName) { existing.chineseName = r.chineseName; pupilChanged = true; }
            if (r.formClass && r.formClass !== existing.formClass) { existing.formClass = r.formClass; pupilChanged = true; }
            if (r.mtClass && r.mtClass !== existing.mtClass) { existing.mtClass = r.mtClass; pupilChanged = true; }
            if (r.regNo !== undefined && r.regNo !== existing.regNo) { existing.regNo = r.regNo; pupilChanged = true; }
            if (r.scriptId && r.scriptId !== existing.scriptId) { existing.scriptId = r.scriptId; pupilChanged = true; }
            if (pupilChanged) changed++;
          } else {
            exam.students.push({
              ...r,
              status: 'unmarked',
              markerCode: null,
              score: { content: null, language: null, total: null, pct: null },
              initialScore: null,
              tags: [],
              remark: '',
              markedAt: null,
              moderation: { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatorCode: null, moderatedBy: null, moderatedAt: null, originalScore: null }
            });
            changed++;
          }
        });

        // Reconcile deleted pupils: If HOD removed an unmarked student on another device, mirror removal
        if (masterData.studentRoster && masterData.studentRoster.length > 0) {
          const prevLen = exam.students.length;
          exam.students = exam.students.filter(s => {
            if (incomingIds.has(s.id)) return true;
            // Retain pupil if marked or moderated so marks are never lost
            if (s.status !== 'unmarked' || (s.score && s.score.total !== null)) return true;
            return false;
          });
          if (exam.students.length !== prevLen) changed++;
        }
      }
    }
    return changed;
  }

  async pullExamMaster(examId) {
    if (!this.isConnected()) {
      return { success: false, error: 'Not connected to shared folder.' };
    }
    try {
      const activeExam = db.getActiveExam();
      const targetId = examId || (activeExam ? activeExam.id : null);
      if (!targetId) return { success: false, error: 'No active exam selected.' };

      const examFileName = `exam_master_${targetId}.json`;
      const masterData = await this.readJsonFile(examFileName);
      if (!masterData) {
        return { success: false, error: `Master file ${examFileName} not found in shared folder.` };
      }

      const changes = this.mergeExamMaster(masterData);
      if (changes > 0) {
        db.save();
        this.dispatchSyncEvent({ type: 'exam_pulled', examId: targetId, changes });
      }
      this.showToast(`📥 Synced updated classlist and paper settings from shared folder (${changes} update(s)). All marker scores remain intact!`, 'success');
      return { success: true, changes, masterData };
    } catch (err) {
      console.error('[SyncService] Failed to pull exam master:', err);
      return { success: false, error: err.message };
    }
  }

  mergeMarkerData(data, activeExam) {
    let changes = 0;
    if (!data || !data.marks) return { changes: 0 };

    const root = typeof db !== 'undefined' ? db.getRootState() : null;
    const marksMap = data.marks;

    Object.keys(marksMap).forEach(studentId => {
      const remote = marksMap[studentId];
      if (!remote) return;

      // 1. Determine target exam paper (by remote.examId or fallback to activeExam)
      let targetExam = activeExam;
      if (remote.examId && root && Array.isArray(root.exams)) {
        const matchingExam = root.exams.find(e => e.id === remote.examId);
        if (matchingExam) targetExam = matchingExam;
      }

      // 2. Find target student in the target exam (by ID or Script ID)
      let student = targetExam && Array.isArray(targetExam.students)
        ? targetExam.students.find(s => s.id === studentId || (remote.scriptId && s.scriptId === remote.scriptId))
        : null;

      // 3. Global fallback: search all exams in registry if student not in target exam
      if (!student && root && Array.isArray(root.exams)) {
        for (const ex of root.exams) {
          const found = (ex.students || []).find(s => s.id === studentId || (remote.scriptId && s.scriptId === remote.scriptId));
          if (found) {
            student = found;
            targetExam = ex;
            break;
          }
        }
      }

      if (!student) return;

      // Don't overwrite if student has been moderated unless remote is newer
      const isRemoteMarked = remote.score && remote.score.total !== null;
      const isLocalMarked = student.score && student.score.total !== null;

      if (isRemoteMarked) {
        let shouldUpdate = false;
        if (!isLocalMarked) {
          shouldUpdate = true;
        } else if (remote.markedAt && (!student.markedAt || new Date(remote.markedAt) > new Date(student.markedAt))) {
          // If remote marked timestamp is strictly newer
          shouldUpdate = true;
        }

        if (shouldUpdate) {
          student.score = { ...remote.score };
          if (remote.initialScore) student.initialScore = { ...remote.initialScore };
          student.markerCode = data.markerCode || remote.markerCode || student.markerCode;
          student.tags = Array.isArray(remote.tags) ? [...remote.tags] : [];
          student.remark = remote.remark || '';
          student.markedAt = remote.markedAt || new Date().toISOString();
          if (!student.moderation || !student.moderation.moderated) {
            student.status = 'marked';
          }
          changes++;

          // Ticker item for other viewers
          this.addActivityItem({
            id: `act_${Date.now()}_${student.scriptId}`,
            time: new Date(remote.markedAt || Date.now()).toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            markerCode: data.markerCode,
            scriptId: student.scriptId,
            text: `${data.markerCode} scored ${student.scriptId} (${student.formClass}): ${remote.score.total} pts`,
            type: 'mark'
          });
        }
      }
    });

    if (changes > 0) {
      this.showToast(`🔄 Live-Sync: Synced ${changes} mark(s) from ${data.markerCode || 'peer marker'}!`, 'info');
    }

    return { changes };
  }

  mergeModerationData(modData, activeExam) {
    let changes = 0;
    if (!modData || !modData.moderations) return 0;
    const root = typeof db !== 'undefined' ? db.getRootState() : null;

    Object.keys(modData.moderations).forEach(studentId => {
      const remote = modData.moderations[studentId];
      if (!remote) return;

      // 1. Determine target exam paper (by remote.examId or fallback to activeExam)
      let targetExam = activeExam;
      if (remote.examId && root && Array.isArray(root.exams)) {
        const matchingExam = root.exams.find(e => e.id === remote.examId);
        if (matchingExam) targetExam = matchingExam;
      }

      // 2. Find target student in target exam
      let student = targetExam && Array.isArray(targetExam.students)
        ? targetExam.students.find(s => s.id === studentId || (remote.scriptId && s.scriptId === remote.scriptId))
        : null;

      // 3. Fallback: search all exams in registry
      if (!student && root && Array.isArray(root.exams)) {
        for (const ex of root.exams) {
          const found = (ex.students || []).find(s => s.id === studentId || (remote.scriptId && s.scriptId === remote.scriptId));
          if (found) {
            student = found;
            targetExam = ex;
            break;
          }
        }
      }

      if (!student) return;

      if (remote.moderation && remote.moderation.moderated) {
        const localModTime = student.moderation ? student.moderation.moderatedAt : null;
        const remoteModTime = remote.moderation.moderatedAt;

        if (!student.moderation || !student.moderation.moderated || (remoteModTime && (!localModTime || new Date(remoteModTime) > new Date(localModTime)))) {
          student.moderation = { ...remote.moderation };
          if (remote.score) student.score = { ...remote.score };
          student.status = 'moderated';
          changes++;
        }
      }
    });

    return changes;
  }

  // =========================================================================
  // 8. ACTIVITY FEED & EVENT DISPATCHING
  // =========================================================================

  addActivityItem(item) {
    // Avoid duplicate script items in rapid succession
    if (this.activityFeed.some(a => a.id === item.id)) return;
    this.activityFeed.unshift(item);
    if (this.activityFeed.length > 50) {
      this.activityFeed.pop();
    }
  }

  dispatchSyncEvent(payload) {
    window.dispatchEvent(new CustomEvent('secs:sync:updated', { detail: payload }));
  }

  onStatusChange(cb) {
    if (typeof cb === 'function') {
      this.statusListeners.push(cb);
    }
  }

  setStatus(status) {
    this.status = status;
    this.notifyStatusChange();
  }

  notifyStatusChange() {
    const info = {
      status: this.status,
      folderName: this.folderName,
      lastSyncTime: this.lastSyncTime,
      activeMarkersCount: Object.keys(this.activeMarkers).length
    };
    this.statusListeners.forEach(fn => fn(info));
    this.updateGlobalBadge(info);
    if (typeof app !== 'undefined' && app.renderLandingSyncUI) {
      app.renderLandingSyncUI(info);
    }
  }

  updateGlobalBadge(info) {
    const badge = document.getElementById('globalSyncStatusBadge');
    const label = document.getElementById('globalSyncStatusLabel');
    const dot = document.getElementById('globalSyncStatusDot');

    if (!badge || !label) return;

    if (info.status === 'CONNECTED') {
      badge.className = 'flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-300 shadow-2xs hover:bg-emerald-100 transition-colors cursor-pointer';
      if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-500 animate-pulse';
      const timeStr = info.lastSyncTime ? info.lastSyncTime.toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Just now';
      label.innerHTML = `Live Sync Active <span class="font-normal text-[11px] text-emerald-600">(${info.activeMarkersCount} markers • ${timeStr})</span> <span class="ml-1.5 px-2 py-0.5 rounded-md bg-emerald-200 text-emerald-900 hover:bg-emerald-300 text-[10px] font-bold transition-all shadow-2xs" onclick="event.stopPropagation(); syncService.pollOnce(true); syncService.showToast('🔄 Live sync refreshed now!', 'info');" title="Click to force instant sync pull">🔄 Sync</span>`;
    } else if (info.status === 'CONNECTING') {
      badge.className = 'flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300';
      if (dot) dot.className = 'w-2 h-2 rounded-full bg-amber-500 animate-spin';
      label.textContent = 'Connecting to Shared Folder...';
    } else if (info.status === 'ERROR') {
      badge.className = 'flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-800 border border-rose-300 cursor-pointer';
      if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500';
      label.textContent = 'Sync Error (Click to reconnect)';
    } else {
      badge.className = 'flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-300 hover:bg-slate-200 transition-colors cursor-pointer';
      if (dot) dot.className = 'w-2 h-2 rounded-full bg-slate-400';
      label.innerHTML = `📁 Link Shared Folder <span class="text-[10px] text-slate-400">(Local Only)</span>`;
    }
  }

  showToast(msg, type = 'info') {
    if (typeof app !== 'undefined' && app.showToast) {
      app.showToast(msg, type);
    } else {
      console.log(`[Toast ${type}] ${msg}`);
    }
  }
}

// Global Singleton Instance
const syncService = new SyncService();
