/**
 * SECS - Marker Interface Controller
 * Provides isolated, distraction-free scoring, qualitative tag feedback,
 * pre-advance score confirmation dialogs, and KP Moderation access.
 */

class MarkerController {
  constructor() {
    this.selectedStudentId = null;
    this.selectedTags = new Set();
    this.classFilter = 'ALL';
    this.classFilterType = 'formClass'; // 'formClass' or 'mtClass'
    this.searchQuery = '';
    this.onlyUnmarked = false;
    this.pendingSave = null;

    // Key Personnel (KP) Moderation & Sampling Hub State
    this.activeMarkerTab = 'marking'; // 'marking' | 'kpModeration'
    this.kpSampleFilter = 'recommended'; // 'all' | 'recommended' | 'borderlinePass' | 'borderlineQuality' | 'outliers' | 'random10' | 'par' | 'unmarked'
    this.kpFormClassFilter = 'ALL';
    this.kpMtClassFilter = 'ALL';
    this.kpMarkerFilter = 'ALL';
    this.kpStatusFilter = 'ALL';
    this.kpSearchQuery = '';
    this.kpModeratingStudentId = null;
    this.graceCountdownTimer = null;
    this.isCurrentStudentVerified = false;
    this.autoAdvanceEnabled = false;
  }

  init() {
    this.activeMarkerTab = 'marking';
    try {
      const savedClassFilter = sessionStorage.getItem('SECS_MARKER_CLASS_FILTER');
      if (savedClassFilter) this.classFilter = savedClassFilter;
    } catch (e) {}

    this.bindEvents();
    this.renderMarkerHeader();
    this.renderAutoAdvanceToggle();
    this.populateClassFilters();
    this.renderClassProgressBar();
    this.renderStudentList();
    this.renderFeedbackTags();
    this.renderRecentMarkedTable();
    this.switchMarkerTab('marking');

    try {
      const savedStudentId = sessionStorage.getItem('SECS_MARKER_STUDENT_ID');
      const state = db.getState();
      if (savedStudentId && state && state.students && state.students.some(s => s.id === savedStudentId)) {
        this.selectStudent(savedStudentId);
      }
    } catch (e) {}
  }

  bindEvents() {
    // Score input listeners for real-time total & bounds checking
    const contentInput = document.getElementById('markerContentInput');
    const langInput = document.getElementById('markerLangInput');

    if (contentInput && langInput) {
      contentInput.addEventListener('input', () => this.handleScoreChange());
      langInput.addEventListener('input', () => this.handleScoreChange());
    }

    // Save and Next button
    const saveBtn = document.getElementById('markerSaveNextBtn');
    if (saveBtn) {
      saveBtn.addEventListener('click', () => this.saveAndNext());
    }

    // Score Confirmation Modal Buttons
    const confirmScoreBtn = document.getElementById('btnConfirmMarkerScore');
    if (confirmScoreBtn) {
      confirmScoreBtn.addEventListener('click', () => this.executeConfirmScore());
    }

    const cancelScoreBtn = document.getElementById('btnCancelMarkerScore');
    if (cancelScoreBtn) {
      cancelScoreBtn.addEventListener('click', () => this.closeScoreConfirmationModal());
    }

    // Keyboard support for Confirmation Modal
    const confirmModal = document.getElementById('markerConfirmModal');
    if (confirmModal) {
      document.addEventListener('keydown', (e) => {
        if (!confirmModal.classList.contains('hidden')) {
          if (e.key === 'Enter') {
            e.preventDefault();
            this.executeConfirmScore();
          } else if (e.key === 'Escape') {
            e.preventDefault();
            this.closeScoreConfirmationModal();
          }
        }
      });
    }

    // Reset / Clear button
    const clearBtn = document.getElementById('markerClearBtn');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => this.clearActiveStudentForm());
    }

    // Search filter
    const searchInput = document.getElementById('markerSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value.toLowerCase().trim();
        this.renderStudentList();
      });
    }

    // Post-Save Random Booklet Picker Input
    const postSaveInput = document.getElementById('markerPostSavePickerInput');
    if (postSaveInput) {
      postSaveInput.addEventListener('input', (e) => {
        this.renderPostSavePickerSuggestions(e.target.value);
      });
      postSaveInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const state = db.getState();
          const q = e.target.value.toLowerCase().trim();
          if (!q) return;
          const match = state.students.find(s => {
            if (this.classFilter !== 'ALL' && s[this.classFilterType] !== this.classFilter) return false;
            if (s.status !== 'unmarked') return false;
            const name = (s.name || '').toLowerCase();
            const cn = (s.chineseName || '').toLowerCase();
            const script = (s.scriptId || '').toLowerCase();
            return script === q || name === q || cn === q || script.includes(q) || name.includes(q);
          });
          if (match) {
            this.selectStudent(match.id);
          }
        }
      });
    }

    // Class dropdown filter
    const classSelect = document.getElementById('markerClassFilter');
    if (classSelect) {
      classSelect.addEventListener('change', (e) => {
        this.classFilter = e.target.value;
        try { sessionStorage.setItem('SECS_MARKER_CLASS_FILTER', this.classFilter); } catch (err) {}
        this.renderMarkerHeader();
        this.renderClassProgressBar();
        this.renderStudentList();
      });
    }

    // Filter Type toggle (Form Class vs MT Class)
    const radioInputs = document.querySelectorAll('input[name="markerFilterType"]');
    radioInputs.forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.classFilterType = e.target.value;
        this.classFilter = 'ALL';
        this.populateClassFilters();
        this.renderMarkerHeader();
        this.renderClassProgressBar();
        this.renderStudentList();
      });
    });

    // Only unmarked checkbox
    const onlyUnmarkedCb = document.getElementById('markerOnlyUnmarkedCheck');
    if (onlyUnmarkedCb) {
      onlyUnmarkedCb.addEventListener('change', (e) => {
        this.onlyUnmarked = e.target.checked;
        this.renderStudentList();
      });
    }

    // KP Moderation Hub Header Switch button
    const kpBtn = document.getElementById('btnMarkerSwitchToModeration');
    if (kpBtn) {
      kpBtn.addEventListener('click', () => {
        this.switchMarkerTab('kpModeration');
      });
    }

    // Shared Folder Live-Sync Update Listener
    window.addEventListener('secs:sync:updated', (e) => {
      this.renderMarkerHeader();
      this.populateClassFilters();
      this.renderClassProgressBar();
      this.renderStudentList();
      this.renderRecentMarkedTable();
      if (this.selectedStudentId) {
        const state = db.getState();
        const cur = state.students.find(s => s.id === this.selectedStudentId);
        if (cur) {
          const warningBox = document.getElementById('markerOtherMarkerNotice');
          if (cur.markerCode && cur.markerCode !== auth.session.markerCode && cur.status !== 'unmarked') {
            if (warningBox) {
              warningBox.classList.remove('hidden');
              warningBox.innerHTML = `✓ <strong>Marked by ${cur.markerCode} (Live-Synced from Shared Folder)</strong>.<br><span class="text-[11px] text-amber-800">In accordance with Singapore Primary School double-blind standardisation rules, prior peer marks remain confidential during independent grading.</span>`;
            }
          }
        }
      }
      if (this.activeMarkerTab === 'kpModeration') {
        this.renderKpModerationHub();
      }
    });
  }

  renderMarkerHeader() {
    const state = db.getState();
    const codeEl = document.getElementById('currentMarkerCodeBadge');
    const nameEl = document.getElementById('currentMarkerNameLabel');
    const examTitleEl = document.getElementById('markerCurrentExamTitle');
    const kpBtn = document.getElementById('btnMarkerSwitchToModeration');
    const kpBadge = document.getElementById('markerKpBadge');

    if (codeEl) codeEl.textContent = auth.session.markerCode || 'M--';
    if (nameEl) nameEl.textContent = auth.session.markerName || 'Active Marker';
    if (examTitleEl) examTitleEl.textContent = state.config.examTitle || state.title || 'Paper 1 (Writing) Marking Entry';

    const isKP = auth.canModerate();
    if (kpBtn) {
      if (isKP) kpBtn.classList.remove('hidden');
      else kpBtn.classList.add('hidden');
    }
    if (kpBadge) {
      if (isKP) kpBadge.classList.remove('hidden');
      else kpBadge.classList.add('hidden');
    }

    const kpTabBtn = document.getElementById('btnMarkerTabKpModeration');
    const kpIndicator = document.getElementById('kpMarkerStatusIndicator');
    const markerNavTabBar = document.getElementById('markerNavTabBar');

    if (kpTabBtn) {
      if (isKP) kpTabBtn.classList.remove('hidden');
      else kpTabBtn.classList.add('hidden');
    }
    if (kpIndicator) {
      if (isKP && this.activeMarkerTab === 'kpModeration') {
        kpIndicator.classList.remove('hidden');
        kpIndicator.classList.add('flex');
      } else {
        kpIndicator.classList.add('hidden');
        kpIndicator.classList.remove('flex');
      }
    }
    if (markerNavTabBar) {
      if (isKP) markerNavTabBar.classList.remove('hidden');
      else markerNavTabBar.classList.add('hidden');
    }

    // Update config bounds in UI labels
    const contentMaxEl = document.getElementById('markerContentMaxLabel');
    const langMaxEl = document.getElementById('markerLangMaxLabel');
    const totalMaxEl = document.getElementById('markerTotalMaxLabel');

    if (contentMaxEl) contentMaxEl.textContent = `/ ${state.config.contentMax}`;
    if (langMaxEl) langMaxEl.textContent = `/ ${state.config.languageMax}`;
    if (totalMaxEl) totalMaxEl.textContent = `/ ${state.config.totalMax}`;

    const contentInput = document.getElementById('markerContentInput');
    const langInput = document.getElementById('markerLangInput');
    if (contentInput) {
      contentInput.max = state.config.contentMax;
      contentInput.min = state.config.contentMin;
    }
    if (langInput) {
      langInput.max = state.config.languageMax;
      langInput.min = state.config.languageMin;
    }

    // 1. Cohort Marked Progress
    const totalCohort = state.students.length;
    const markedCohort = state.students.filter(s => s.score && s.score.total !== null).length;
    const cohortPct = totalCohort > 0 ? Math.round((markedCohort / totalCohort) * 1000) / 10 : 0;
    const cohortPill = document.getElementById('markerCohortProgressPill');
    if (cohortPill) cohortPill.textContent = `${markedCohort} / ${totalCohort} (${cohortPct}%)`;

    // 2. Selected Class Marked Progress
    const classTitleEl = document.getElementById('markerClassProgressTitle');
    const classPillEl = document.getElementById('markerClassProgressPill');
    if (this.classFilter === 'ALL') {
      if (classTitleEl) classTitleEl.textContent = 'Cohort Marked';
      if (classPillEl) classPillEl.textContent = `${markedCohort} / ${totalCohort} (${cohortPct}%)`;
    } else {
      const classStudents = state.students.filter(s => s[this.classFilterType] === this.classFilter);
      const totalClass = classStudents.length;
      const markedClass = classStudents.filter(s => s.score && s.score.total !== null).length;
      const classPct = totalClass > 0 ? Math.round((markedClass / totalClass) * 1000) / 10 : 0;
      if (classTitleEl) classTitleEl.textContent = `Class Marked`;
      if (classPillEl) classPillEl.textContent = `${markedClass} / ${totalClass} (${classPct}%)`;
    }

    // 3. Marked by You
    const myCode = auth.session.markerCode;
    const myMarked = state.students.filter(s => s.markerCode === myCode && s.score && s.score.total !== null).length;
    const myPill = document.getElementById('markerMyCountPill');
    if (myPill) myPill.textContent = `${myMarked} Scripts`;
  }

  toggleAutoAdvance() {
    this.autoAdvanceEnabled = !this.autoAdvanceEnabled;
    try {
      localStorage.setItem('SECS_MARKER_AUTO_ADVANCE', String(this.autoAdvanceEnabled));
    } catch (e) {}
    this.renderAutoAdvanceToggle();
    this.showToast(this.autoAdvanceEnabled 
      ? '⚡ Auto-Advance enabled: Next unmarked script will load automatically after saving.' 
      : '⏸️ Auto-Advance paused: System will pause after saving so you can verify each physical script booklet.',
      'info');
  }

  renderAutoAdvanceToggle() {
    const btn = document.getElementById('markerAutoAdvanceToggleBtn');
    const label = document.getElementById('markerAutoAdvanceLabel');
    const icon = document.getElementById('markerAutoAdvanceIcon');
    if (btn && label) {
      if (this.autoAdvanceEnabled) {
        btn.className = 'px-2 py-0.5 text-[11px] rounded-lg font-bold border transition-all cursor-pointer flex items-center gap-1 shadow-2xs bg-sky-50 text-sky-800 border-sky-300 hover:bg-sky-100';
        label.textContent = 'Auto-Advance: ON';
        if (icon) icon.textContent = '⚡';
      } else {
        btn.className = 'px-2 py-0.5 text-[11px] rounded-lg font-bold border transition-all cursor-pointer flex items-center gap-1 shadow-2xs bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100';
        label.textContent = 'Auto-Advance: OFF (Manual)';
        if (icon) icon.textContent = '⏸️';
      }
    }
  }

  showPostSaveCard(savedStudent) {
    const emptyNotice = document.getElementById('markerEmptySelectionNotice');
    const detailsBox = document.getElementById('markerActiveStudentCard');
    const scoringSection = document.getElementById('markerScoringForm');
    const pauseCard = document.getElementById('markerPostSavePauseCard');

    if (emptyNotice) emptyNotice.classList.add('hidden');
    if (detailsBox) detailsBox.classList.add('hidden');
    if (scoringSection) scoringSection.classList.add('hidden');
    if (pauseCard) {
      pauseCard.classList.remove('hidden');

      const titleEl = document.getElementById('markerPostSaveTitle');
      const subEl = document.getElementById('markerPostSaveSubtitle');
      const inputEl = document.getElementById('markerPostSavePickerInput');

      const savedDisplayName = savedStudent.chineseName 
        ? `${savedStudent.name} (${savedStudent.chineseName})` 
        : savedStudent.name;

      if (titleEl) titleEl.textContent = `${savedStudent.scriptId} — ${savedDisplayName} Saved!`;
      if (subEl) subEl.textContent = `Score recorded: ${savedStudent.score.total}/${db.getState().config.totalMax} pts (${savedStudent.score.content}C + ${savedStudent.score.language}L). 10-minute amendment window active.`;

      if (inputEl) {
        inputEl.value = '';
        inputEl.focus();
      }

      this.renderPostSavePickerSuggestions('');
    }
  }

  renderPostSavePickerSuggestions(query = '') {
    const suggestionsEl = document.getElementById('markerPostSavePickerSuggestions');
    if (!suggestionsEl) return;

    const state = db.getState();
    const q = (query || '').toLowerCase().trim();

    const unmarked = state.students.filter(s => {
      if (this.classFilter !== 'ALL' && s[this.classFilterType] !== this.classFilter) return false;
      if (s.status !== 'unmarked') return false;
      if (!q) return true;
      const name = (s.name || '').toLowerCase();
      const cn = (s.chineseName || '').toLowerCase();
      const script = (s.scriptId || '').toLowerCase();
      const reg = String(s.regNo || '');
      return name.includes(q) || cn.includes(q) || script.includes(q) || reg.includes(q);
    }).slice(0, 8);

    if (unmarked.length === 0) {
      if (!q) {
        suggestionsEl.innerHTML = `<div class="p-3 text-center text-xs text-emerald-700 font-bold">🎉 All scripts in this filter group have been marked!</div>`;
      } else {
        suggestionsEl.innerHTML = `<div class="p-3 text-center text-xs text-slate-500">No unmarked script matching "${query}".</div>`;
      }
      suggestionsEl.classList.remove('hidden');
      return;
    }

    suggestionsEl.innerHTML = unmarked.map(s => {
      const displayName = s.chineseName ? `${s.name} (${s.chineseName})` : s.name;
      return `
        <button type="button" onclick="markerApp.selectStudent('${s.id}')" class="w-full p-2.5 hover:bg-sky-50 text-left flex items-center justify-between cursor-pointer transition-colors">
          <div class="flex items-center gap-2">
            <span class="font-mono font-bold text-xs text-sky-700">${s.scriptId}</span>
            <span class="font-semibold text-xs text-slate-900">${displayName}</span>
            <span class="text-[11px] text-slate-500 font-normal">(${s.formClass} • Reg #${s.regNo})</span>
          </div>
          <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800">Select Script →</span>
        </button>
      `;
    }).join('');
    suggestionsEl.classList.remove('hidden');
  }

  renderClassProgressBar() {
    const state = db.getState();
    const labelEl = document.getElementById('markerClassProgressLabel');
    const countEl = document.getElementById('markerClassProgressCount');
    const barEl = document.getElementById('markerClassProgressBar');
    const remainingEl = document.getElementById('markerClassProgressRemaining');
    const cohortSummaryEl = document.getElementById('markerCohortTallySummary');

    const totalCohort = state.students.length;
    const markedCohort = state.students.filter(s => s.score && s.score.total !== null).length;
    const cohortPct = totalCohort > 0 ? Math.round((markedCohort / totalCohort) * 1000) / 10 : 0;

    let targetTotal = totalCohort;
    let targetMarked = markedCohort;
    let targetPct = cohortPct;
    let label = this.classFilterType === 'formClass' ? 'All Form Classes' : 'All MT Classes';

    if (this.classFilter !== 'ALL') {
      const classStudents = state.students.filter(s => s[this.classFilterType] === this.classFilter);
      targetTotal = classStudents.length;
      targetMarked = classStudents.filter(s => s.score && s.score.total !== null).length;
      targetPct = targetTotal > 0 ? Math.round((targetMarked / targetTotal) * 1000) / 10 : 0;
      label = this.classFilter;
    }

    const remaining = targetTotal - targetMarked;

    if (labelEl) labelEl.textContent = label;
    if (countEl) countEl.textContent = `${targetMarked} / ${targetTotal} (${targetPct}%)`;
    if (barEl) barEl.style.width = `${targetPct}%`;
    if (remainingEl) {
      remainingEl.textContent = remaining === 0 
        ? '🎉 All scripts marked!' 
        : `${remaining} script${remaining > 1 ? 's' : ''} remaining in physical bundle`;
    }
    if (cohortSummaryEl) {
      cohortSummaryEl.textContent = `Cohort total: ${markedCohort}/${totalCohort} (${cohortPct}%)`;
    }
  }

  populateClassFilters() {
    const select = document.getElementById('markerClassFilter');
    if (!select) return;

    const state = db.getState();
    const classes = Array.from(new Set(state.students.map(s => s[this.classFilterType]))).sort();

    const previousValue = this.classFilter;
    select.innerHTML = '<option value="ALL">All Classes (Full Cohort)</option>';
    classes.forEach(c => {
      const classStudents = state.students.filter(s => s[this.classFilterType] === c);
      const total = classStudents.length;
      const marked = classStudents.filter(s => s.score && s.score.total !== null).length;
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = `${c} [${marked}/${total} marked]`;
      select.appendChild(opt);
    });

    if (classes.includes(previousValue) || previousValue === 'ALL') {
      select.value = previousValue;
      this.classFilter = previousValue;
    } else {
      select.value = 'ALL';
      this.classFilter = 'ALL';
    }
  }

  renderStudentList() {
    const container = document.getElementById('markerStudentListContainer');
    if (!container) return;

    const state = db.getState();
    const isBlindMode = state.config.blindMode;

    let list = state.students.filter(student => {
      if (this.classFilter !== 'ALL' && student[this.classFilterType] !== this.classFilter) {
        return false;
      }
      if (this.onlyUnmarked && student.status !== 'unmarked') {
        return false;
      }
      if (this.searchQuery) {
        const q = this.searchQuery;
        const regMatch = String(student.regNo) === q || `#${student.regNo}` === q;
        const nameMatch = student.name.toLowerCase().includes(q);
        const chineseMatch = student.chineseName && student.chineseName.includes(q);
        const scriptMatch = student.scriptId.toLowerCase().includes(q);
        return regMatch || nameMatch || chineseMatch || scriptMatch;
      }
      return true;
    });

    list.sort((a, b) => {
      if (a[this.classFilterType] !== b[this.classFilterType]) {
        return a[this.classFilterType].localeCompare(b[this.classFilterType]);
      }
      return a.regNo - b.regNo;
    });

    if (list.length === 0) {
      container.innerHTML = `
        <div class="p-6 text-center text-slate-400 text-sm">
          No matching scripts found in this filter.
        </div>
      `;
      return;
    }

    container.innerHTML = list.map(student => {
      const isSelected = student.id === this.selectedStudentId;
      const isMarkedByMe = student.markerCode === auth.session.markerCode && student.status !== 'unmarked';
      const isMarkedByOther = student.markerCode && student.markerCode !== auth.session.markerCode && student.status !== 'unmarked';

      let statusBadge = '';
      let cardBg = isSelected ? 'bg-sky-50 border-sky-500 shadow-sm' : 'bg-white hover:bg-slate-50 border-slate-200';

      if (student.moderation && student.moderation.moderated) {
        const delta = student.moderation.delta || 0;
        const deltaSign = delta > 0 ? `+${delta}` : `${delta}`;
        const isKP = typeof auth !== 'undefined' && auth.canModerate();
        if (isMarkedByMe || isKP) {
          statusBadge = `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-purple-100 text-purple-900 border border-purple-300 shadow-2xs" title="Moderated by Key Personnel / HOD. Initial: ${student.initialScore ? student.initialScore.total : '-'} → Moderated: ${student.score.total} (Δ ${deltaSign})">🟣 Moderated (${student.score.total}/${state.config.totalMax})</span>`;
        } else {
          statusBadge = `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-purple-50 text-purple-800 border border-purple-200">🟣 Moderated (${student.markerCode})</span>`;
        }
      } else if (isMarkedByMe) {
        const editStatus = db.getStudentEditStatus(student);
        if (editStatus.isEditable) {
          const remM = Math.ceil(editStatus.remainingSec / 60);
          statusBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-300 shadow-2xs animate-pulse" title="${editStatus.remainingSec}s remaining to amend score">⏱️ Edit (${remM}m)</span>`;
        } else {
          statusBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-800" title="10-minute amendment period expired - Finalized">🔒 Finalized (${student.score.total}/${state.config.totalMax})</span>`;
        }
      } else if (isMarkedByOther) {
        const isKP = typeof auth !== 'undefined' && auth.canModerate();
        const scoreSnippet = isKP ? ` (${student.score.total}/${state.config.totalMax})` : '';
        statusBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-sky-50 text-sky-800 border border-sky-300">✓ Marked by ${student.markerCode}${scoreSnippet}</span>`;
      } else {
        statusBadge = `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800">Unmarked</span>`;
      }

      const displayName = isBlindMode 
        ? `Script [${student.scriptId}]` 
        : (student.chineseName ? `${student.name} <span class="text-slate-500 font-normal">(${student.chineseName})</span>` : student.name);
      const identifierSubtitle = isBlindMode 
        ? `Reg: ${student.regNo} | ${student.formClass}` 
        : `Reg: #${student.regNo} | Form: ${student.formClass} | MT: ${student.mtClass}`;

      return `
        <div onclick="markerApp.selectStudent('${student.id}')" 
             class="cursor-pointer border rounded-lg p-3 transition-all ${cardBg}">
          <div class="flex items-center justify-between">
            <div class="font-semibold text-slate-800 text-sm flex items-center gap-2">
              <span class="w-6 h-6 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center text-xs font-mono font-bold">${student.regNo}</span>
              <span>${displayName}</span>
            </div>
            <div>${statusBadge}</div>
          </div>
          <div class="text-xs text-slate-500 mt-1 flex items-center justify-between">
            <span>${identifierSubtitle}</span>
            <span class="font-mono text-slate-400 text-[11px]">${student.scriptId}</span>
          </div>
        </div>
      `;
    }).join('');
  }

  selectStudent(studentId) {
    this.selectedStudentId = studentId;
    try { sessionStorage.setItem('SECS_MARKER_STUDENT_ID', studentId); } catch (e) {}
    const state = db.getState();
    const student = state.students.find(s => s.id === studentId);
    if (!student) return;

    this.renderStudentList();

    const emptyNotice = document.getElementById('markerEmptySelectionNotice');
    const detailsBox = document.getElementById('markerActiveStudentCard');
    const scoringSection = document.getElementById('markerScoringForm');
    const pauseCard = document.getElementById('markerPostSavePauseCard');

    if (emptyNotice) emptyNotice.classList.add('hidden');
    if (pauseCard) pauseCard.classList.add('hidden');
    if (detailsBox) detailsBox.classList.remove('hidden');
    if (scoringSection) scoringSection.classList.remove('hidden');

    const isBlind = state.config.blindMode;
    const activeName = document.getElementById('activeStudentName');
    const activeScriptId = document.getElementById('activeStudentScriptId');
    const activeClass = document.getElementById('activeStudentClass');

    if (activeName) {
      activeName.textContent = isBlind 
        ? `Candidate [${student.scriptId}]` 
        : (student.chineseName ? `${student.name} (${student.chineseName})` : student.name);
    }
    if (activeScriptId) activeScriptId.textContent = student.scriptId;
    if (activeClass) {
      activeClass.textContent = isBlind
        ? `Reg #${student.regNo} | Class: ${student.formClass}`
        : `Reg #${student.regNo} | Form: ${student.formClass} | MT: ${student.mtClass}`;
    }

    // Populate Candidate Physical Script Verification Banner & Gate
    const verifyScriptEl = document.getElementById('markerVerifyCandidateScriptId');
    const verifyNameEl = document.getElementById('markerVerifyCandidateName');
    const verifyMetaEl = document.getElementById('markerVerifyCandidateMeta');
    const fullDisplayName = student.chineseName ? `${student.name} (${student.chineseName})` : student.name;
    if (verifyScriptEl) verifyScriptEl.textContent = student.scriptId;
    if (verifyNameEl) verifyNameEl.textContent = `${fullDisplayName} [${student.formClass}]`;
    if (verifyMetaEl) verifyMetaEl.textContent = `Reg #${student.regNo} | Form: ${student.formClass} | MT: ${student.mtClass}`;

    // Candidate Physical Script Verification State
    // Unmarked scripts REQUIRE mandatory physical booklet verification before scoring inputs unlock!
    if (student.status === 'unmarked') {
      this.isCurrentStudentVerified = false;
    } else {
      this.isCurrentStudentVerified = true;
    }

    const verifyGate = document.getElementById('markerCandidateVerifyGate');
    const verifiedBadge = document.getElementById('markerCandidateVerifiedBadge');
    const scoringFields = document.getElementById('markerScoringInputFields');

    if (!this.isCurrentStudentVerified) {
      if (verifyGate) verifyGate.classList.remove('hidden');
      if (verifiedBadge) verifiedBadge.classList.add('hidden');
      if (scoringFields) scoringFields.classList.add('opacity-40', 'pointer-events-none', 'select-none');
    } else {
      if (verifyGate) verifyGate.classList.add('hidden');
      if (verifiedBadge) {
        verifiedBadge.classList.remove('hidden');
        const sumEl = document.getElementById('markerVerifiedCandidateSummary');
        if (sumEl) sumEl.textContent = `${fullDisplayName} [${student.formClass}] verified with physical script in hand.`;
      }
      if (scoringFields) scoringFields.classList.remove('opacity-40', 'pointer-events-none', 'select-none');
    }

    // Populate Moderation Notice Banner if script has been reviewed by KP / HOD
    const modBanner = document.getElementById('markerModerationNoticeBanner');
    if (student.moderation && student.moderation.moderated) {
      if (modBanner) {
        modBanner.classList.remove('hidden');
        const deltaBadge = document.getElementById('markerModNoticeDeltaBadge');
        const detailsEl = document.getElementById('markerModNoticeDetails');
        const scoresEl = document.getElementById('markerModNoticeScores');
        const remarkEl = document.getElementById('markerModNoticeRemark');

        const delta = student.moderation.delta || 0;
        const deltaSign = delta > 0 ? `+${delta}` : `${delta}`;
        if (deltaBadge) {
          deltaBadge.textContent = `Δ ${deltaSign} marks`;
          deltaBadge.className = `font-mono font-bold text-xs px-2 py-0.5 rounded ${delta > 0 ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : (delta < 0 ? 'bg-rose-100 text-rose-800 border border-rose-300' : 'bg-slate-100 text-slate-800 border border-slate-300')}`;
        }
        if (detailsEl) {
          const modBy = student.moderation.moderatedBy || student.moderation.moderatorCode || 'Key Personnel';
          detailsEl.textContent = `Moderated by: ${modBy}`;
        }
        if (scoresEl) {
          const orig = student.initialScore || student.moderation.originalScore || { total: (student.score.total - delta) };
          scoresEl.textContent = `Initial Awarded: ${orig.total !== undefined ? orig.total : '-'}/${state.config.totalMax} pts (${orig.content || '-'}C + ${orig.language || '-'}L) → Moderated Final: ${student.score.total}/${state.config.totalMax} pts (${student.score.content}C + ${student.score.language}L)`;
        }
        if (remarkEl) {
          if (student.moderation.hodRemark) {
            remarkEl.textContent = `"${student.moderation.hodRemark}"`;
            remarkEl.classList.remove('hidden');
          } else {
            remarkEl.classList.add('hidden');
          }
        }
      }
    } else {
      if (modBanner) modBanner.classList.add('hidden');
    }

    if (this.graceCountdownTimer) {
      clearInterval(this.graceCountdownTimer);
      this.graceCountdownTimer = null;
    }

    const editStatus = db.getStudentEditStatus(student);
    const lockBanner = document.getElementById('markerLockedBanner');
    const graceBanner = document.getElementById('markerEditGraceBanner');
    const expiredBanner = document.getElementById('markerEditExpiredBanner');
    const graceCountdownText = document.getElementById('markerGraceCountdownText');
    const saveBtn = document.getElementById('markerSaveNextBtn');
    const clearBtn = document.getElementById('markerClearBtn');
    const contentInput = document.getElementById('markerContentInput');
    const langInput = document.getElementById('markerLangInput');
    const remarkInput = document.getElementById('markerRemarkInput');
    const isLocked = !!state.config.markingLocked;

    // Reset banners
    if (lockBanner) lockBanner.classList.add('hidden');
    if (graceBanner) graceBanner.classList.add('hidden');
    if (expiredBanner) expiredBanner.classList.add('hidden');

    const warningBox = document.getElementById('markerOtherMarkerNotice');
    const isMarkedByOther = student.markerCode && student.markerCode !== auth.session.markerCode && student.status !== 'unmarked';
    const isMarkedByMe = student.markerCode === auth.session.markerCode && student.status !== 'unmarked';

    let canEdit = true;

    if (isLocked) {
      if (lockBanner) lockBanner.classList.remove('hidden');
      canEdit = false;
      if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.classList.add('opacity-50', 'cursor-not-allowed');
        saveBtn.innerHTML = `<span>🔒 Marking Frozen (Read-Only)</span>`;
      }
    } else if (isMarkedByOther) {
      canEdit = false;
      if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.classList.add('opacity-50', 'cursor-not-allowed');
        saveBtn.innerHTML = `<span>🔒 Marked by ${student.markerCode} (Approach HOD to Edit)</span>`;
      }
    } else if (isMarkedByMe) {
      if (editStatus.isEditable) {
        // Within 10-minute grace period!
        if (graceBanner) graceBanner.classList.remove('hidden');
        canEdit = true;
        if (saveBtn) {
          saveBtn.disabled = false;
          saveBtn.classList.remove('opacity-50', 'cursor-not-allowed');
          saveBtn.innerHTML = `<span>💾 Save Amendments</span><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>`;
        }
        // Start live ticker
        const updateCountdown = () => {
          const currentStatus = db.getStudentEditStatus(student);
          if (!currentStatus.isEditable) {
            if (this.graceCountdownTimer) {
              clearInterval(this.graceCountdownTimer);
              this.graceCountdownTimer = null;
            }
            this.selectStudent(student.id);
            this.showToast(`🔒 10-Minute amendment window expired for script ${student.scriptId}. Script is now finalized.`, 'info');
            return;
          }
          const sec = currentStatus.remainingSec;
          const m = Math.floor(sec / 60);
          const s = sec % 60;
          if (graceCountdownText) {
            graceCountdownText.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
          }
        };
        updateCountdown();
        this.graceCountdownTimer = setInterval(updateCountdown, 1000);
      } else {
        // 10-minute grace period expired!
        if (expiredBanner) expiredBanner.classList.remove('hidden');
        canEdit = false;
        if (saveBtn) {
          saveBtn.disabled = true;
          saveBtn.classList.add('opacity-50', 'cursor-not-allowed');
          saveBtn.innerHTML = `<span>🔒 Finalized (10-Min Expired)</span>`;
        }
      }
    } else {
      // Unmarked script
      if (!this.isCurrentStudentVerified) {
        canEdit = false;
        if (saveBtn) {
          saveBtn.disabled = true;
          saveBtn.classList.add('opacity-50', 'cursor-not-allowed');
          saveBtn.innerHTML = `<span>🔒 Verify Booklet to Mark</span>`;
        }
      } else {
        canEdit = true;
        if (saveBtn) {
          saveBtn.disabled = false;
          saveBtn.classList.remove('opacity-50', 'cursor-not-allowed');
          saveBtn.innerHTML = `<span>Save & Record Mark</span><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>`;
        }
      }
    }

    if (contentInput) contentInput.disabled = !canEdit;
    if (langInput) langInput.disabled = !canEdit;
    if (remarkInput) remarkInput.disabled = !canEdit;
    if (clearBtn) clearBtn.disabled = !canEdit;

    if (isMarkedByOther) {
      if (warningBox) {
        warningBox.classList.remove('hidden');
        const isKP = typeof auth !== 'undefined' && auth.canModerate();
        if (isKP) {
          warningBox.className = 'text-xs bg-purple-50 text-purple-950 border border-purple-200 px-3 py-2 rounded-xl shadow-2xs';
          warningBox.innerHTML = `⚖️ <strong>Live-Synced Script marked by ${student.markerCode}</strong> (Score: ${student.score ? student.score.total : '-'}/${state.config.totalMax} pts). As a Key Personnel (KP) moderator, you can review this script or use the <a href="javascript:void(0)" onclick="markerApp.switchMarkerTab('kpModeration')" class="underline font-bold text-purple-800">Moderation Portal</a>.`;
        } else {
          warningBox.className = 'text-xs bg-rose-50 text-rose-900 border border-rose-200 px-3.5 py-2.5 rounded-xl space-y-1 shadow-2xs';
          warningBox.innerHTML = `
            <div class="flex items-center gap-1.5 font-bold">
              <span>🔒 Marked by ${student.markerCode} (Peer Script)</span>
            </div>
            <div class="text-[11px] text-rose-800 leading-relaxed">
              Regular markers cannot edit or overwrite scripts marked by other markers. If you require changes to this mark, please approach your <strong>HOD or Key Personnel (KP) Moderator</strong>.
            </div>
          `;
        }
      }
      if (contentInput) contentInput.value = '';
      if (langInput) langInput.value = '';
      if (remarkInput) remarkInput.value = '';
      this.selectedTags.clear();
    } else {
      if (warningBox) warningBox.classList.add('hidden');
      if (student.score && student.score.total !== null) {
        if (contentInput) contentInput.value = student.score.content;
        if (langInput) langInput.value = student.score.language;
        if (remarkInput) remarkInput.value = student.remark || '';
        this.selectedTags = new Set(student.tags || []);
      } else {
        if (contentInput) contentInput.value = '';
        if (langInput) langInput.value = '';
        if (remarkInput) remarkInput.value = '';
        this.selectedTags.clear();
      }
    }

    this.renderFeedbackTags();
    this.handleScoreChange();

    if (window.innerWidth < 768) {
      scoringSection.scrollIntoView({ behavior: 'smooth' });
    }
  }

  confirmPhysicalVerification() {
    if (!this.selectedStudentId) return;
    const state = db.getState();
    const student = state.students.find(s => s.id === this.selectedStudentId);
    if (!student) return;

    this.isCurrentStudentVerified = true;

    const verifyGate = document.getElementById('markerCandidateVerifyGate');
    const verifiedBadge = document.getElementById('markerCandidateVerifiedBadge');
    const scoringFields = document.getElementById('markerScoringInputFields');
    const contentInput = document.getElementById('markerContentInput');
    const langInput = document.getElementById('markerLangInput');
    const remarkInput = document.getElementById('markerRemarkInput');
    const saveBtn = document.getElementById('markerSaveNextBtn');
    const clearBtn = document.getElementById('markerClearBtn');

    if (verifyGate) verifyGate.classList.add('hidden');
    if (verifiedBadge) {
      verifiedBadge.classList.remove('hidden');
      const sumEl = document.getElementById('markerVerifiedCandidateSummary');
      const fullDisplayName = student.chineseName ? `${student.name} (${student.chineseName})` : student.name;
      if (sumEl) sumEl.textContent = `${fullDisplayName} [${student.formClass}] verified with physical script in hand.`;
    }
    if (scoringFields) scoringFields.classList.remove('opacity-40', 'pointer-events-none', 'select-none');

    if (contentInput) {
      contentInput.disabled = false;
      contentInput.focus();
    }
    if (langInput) langInput.disabled = false;
    if (remarkInput) remarkInput.disabled = false;
    if (clearBtn) clearBtn.disabled = false;

    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.classList.remove('opacity-50', 'cursor-not-allowed');
      saveBtn.innerHTML = `<span>Save & Record Mark</span><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>`;
    }

    this.renderFeedbackTags();
    this.showToast(`✓ Physical booklet verified for ${student.scriptId} (${student.name}). Scoring unlocked.`);
  }

  handleScoreChange() {
    const state = db.getState();
    const contentInput = document.getElementById('markerContentInput');
    const langInput = document.getElementById('markerLangInput');
    const totalDisplay = document.getElementById('markerComputedTotal');
    const pctDisplay = document.getElementById('markerComputedPct');
    const errorMsg = document.getElementById('markerScoreValidationError');

    const cVal = contentInput.value.trim();
    const lVal = langInput.value.trim();

    if (cVal === '' && lVal === '') {
      if (totalDisplay) totalDisplay.textContent = '-';
      if (pctDisplay) pctDisplay.textContent = '-%';
      if (errorMsg) errorMsg.classList.add('hidden');
      return;
    }

    const c = Number(cVal);
    const l = Number(lVal);
    let hasError = false;
    let errors = [];

    if (isNaN(c) || c < state.config.contentMin || c > state.config.contentMax) {
      errors.push(`Content mark must be between ${state.config.contentMin} and ${state.config.contentMax}.`);
      hasError = true;
    }

    if (isNaN(l) || l < state.config.languageMin || l > state.config.languageMax) {
      errors.push(`Language mark must be between ${state.config.languageMin} and ${state.config.languageMax}.`);
      hasError = true;
    }

    if (hasError) {
      if (errorMsg) {
        errorMsg.textContent = errors.join(' ');
        errorMsg.classList.remove('hidden');
      }
      if (totalDisplay) totalDisplay.textContent = 'Err';
      if (pctDisplay) pctDisplay.textContent = 'Err';
    } else {
      if (errorMsg) errorMsg.classList.add('hidden');
      const total = c + l;
      const pct = Math.round((total / state.config.totalMax) * 1000) / 10;
      if (totalDisplay) totalDisplay.textContent = total;
      if (pctDisplay) pctDisplay.textContent = `${pct}%`;
    }
  }

  renderFeedbackTags() {
    const state = db.getState();
    const curStudent = this.selectedStudentId ? state.students.find(s => s.id === this.selectedStudentId) : null;
    const editStatus = curStudent ? db.getStudentEditStatus(curStudent) : { isEditable: true };
    const isLocked = !!state.config.markingLocked || !editStatus.isEditable;

    const cStrengthsContainer = document.getElementById('markerContentStrengthsContainer');
    const cWeaknessesContainer = document.getElementById('markerContentWeaknessesContainer');
    const lStrengthsContainer = document.getElementById('markerLangStrengthsContainer');
    const lWeaknessesContainer = document.getElementById('markerLangWeaknessesContainer');

    const fb = state.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS;

    const cStrengths = (fb.content && fb.content.strengths) ||
      (fb.strengths && fb.strengths.filter(t => t.criterion === 'content' || t.category === '审题与立意' || t.category === '内容与情节' || t.category === '结构与组织')) || [];

    const cWeaknesses = (fb.content && fb.content.weaknesses) ||
      (fb.mistakes && fb.mistakes.filter(t => t.criterion === 'content' || t.category === '审题与内容' || t.category === '结构与组织')) || [];

    const lStrengths = (fb.language && fb.language.strengths) ||
      (fb.strengths && fb.strengths.filter(t => t.criterion === 'language' || t.category === '语言与表达' || t.category === '标点与书写')) || [];

    const lWeaknesses = (fb.language && fb.language.weaknesses) ||
      (fb.mistakes && fb.mistakes.filter(t => t.criterion === 'language' || t.category === '语言与表达' || t.category === '标点与错别字')) || [];

    const renderTagButtons = (tags, isPositive) => {
      return tags.map(tag => {
        const isSelected = this.selectedTags.has(tag.label);
        let sentimentClass = '';
        if (isPositive) {
          sentimentClass = isSelected
            ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs font-semibold ring-2 ring-emerald-500/40'
            : 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100 hover:border-emerald-400';
        } else {
          sentimentClass = isSelected
            ? 'bg-rose-700 text-white border-rose-800 shadow-xs font-semibold ring-2 ring-rose-500/40'
            : 'bg-rose-50 text-rose-900 border-rose-300 hover:bg-rose-100 hover:border-rose-400';
        }
        const lockClass = isLocked ? 'opacity-60 pointer-events-none cursor-not-allowed' : 'cursor-pointer';

        return `
          <button type="button" 
                  ${isLocked ? 'disabled' : ''}
                  onclick="markerApp.toggleTag('${tag.label.replace(/'/g, "\\'")}')" 
                  class="px-2.5 py-1 text-xs rounded-lg border font-medium transition-all ${sentimentClass} ${lockClass}">
            ${isSelected ? '✓ ' : '+ '}${tag.label}
          </button>
        `;
      }).join('');
    };

    if (cStrengthsContainer) cStrengthsContainer.innerHTML = renderTagButtons(cStrengths, true);
    if (cWeaknessesContainer) cWeaknessesContainer.innerHTML = renderTagButtons(cWeaknesses, false);
    if (lStrengthsContainer) lStrengthsContainer.innerHTML = renderTagButtons(lStrengths, true);
    if (lWeaknessesContainer) lWeaknessesContainer.innerHTML = renderTagButtons(lWeaknesses, false);
  }

  toggleTag(label) {
    if (db.getState().config.markingLocked) return;
    if (this.selectedStudentId) {
      const curStudent = db.getState().students.find(s => s.id === this.selectedStudentId);
      if (curStudent && curStudent.markerCode && curStudent.markerCode !== auth.session.markerCode && curStudent.status !== 'unmarked') {
        this.showToast(`🔒 Marked by ${curStudent.markerCode}. Regular markers cannot edit peer scripts.`, 'info');
        return;
      }
      const editStatus = db.getStudentEditStatus(curStudent);
      if (!editStatus.isEditable && editStatus.isFinalized) {
        this.showToast('🔒 10-Minute amendment window expired. Feedback tags are locked.', 'info');
        return;
      }
    }
    if (this.selectedTags.has(label)) {
      this.selectedTags.delete(label);
    } else {
      this.selectedTags.add(label);
    }
    this.renderFeedbackTags();
  }

  // Pre-Advance Score Confirmation Dialog Workflow
  saveAndNext() {
    if (db.getState().config.markingLocked) {
      alert('🔒 Marking has been locked by HOD in Read-Only mode. Amendments cannot be saved.');
      return;
    }

    if (!this.selectedStudentId) {
      alert('Please select a student paper first.');
      return;
    }

    const state = db.getState();
    const student = state.students.find(s => s.id === this.selectedStudentId);
    if (!student) return;

    // Guard against regular marker overwriting a script marked by another marker
    const isMarkedByOther = student.markerCode && student.markerCode !== auth.session.markerCode && student.status !== 'unmarked';
    if (isMarkedByOther) {
      alert(`🔒 Cannot overwrite script: This script was marked by ${student.markerCode}.\n\nRegular markers cannot overwrite or edit marks recorded by other markers. If you require changes to this script, please approach your HOD or Key Personnel (KP) Moderator.`);
      return;
    }

    const editStatus = db.getStudentEditStatus(student);
    if (!editStatus.isEditable && editStatus.isFinalized) {
      alert(`🔒 Cannot save amendments: ${editStatus.reason}. This script is finalized for Key Personnel moderation.`);
      return;
    }
    const contentInput = document.getElementById('markerContentInput');
    const langInput = document.getElementById('markerLangInput');
    const remarkInput = document.getElementById('markerRemarkInput');

    const cVal = contentInput.value.trim();
    const lVal = langInput.value.trim();

    if (cVal === '' || lVal === '') {
      alert('Please enter both Content and Language marks.');
      return;
    }

    const c = Number(cVal);
    const l = Number(lVal);

    if (isNaN(c) || c < state.config.contentMin || c > state.config.contentMax) {
      alert(`Content mark must be within ${state.config.contentMin} and ${state.config.contentMax}.`);
      contentInput.focus();
      return;
    }

    if (isNaN(l) || l < state.config.languageMin || l > state.config.languageMax) {
      alert(`Language mark must be within ${state.config.languageMin} and ${state.config.languageMax}.`);
      langInput.focus();
      return;
    }

    const total = c + l;
    const pct = Math.round((total / state.config.totalMax) * 1000) / 10;
    const tagsArray = Array.from(this.selectedTags);
    const remark = remarkInput.value.trim();

    this.pendingSave = {
      studentId: this.selectedStudentId,
      markerCode: auth.session.markerCode,
      content: c,
      language: l,
      total: total,
      pct: pct,
      tags: tagsArray,
      remark: remark
    };

    this.showScoreConfirmationModal();
  }

  showScoreConfirmationModal() {
    if (!this.pendingSave) return;
    const state = db.getState();
    const student = state.students.find(s => s.id === this.pendingSave.studentId);
    if (!student) return;

    const modal = document.getElementById('markerConfirmModal');
    if (!modal) {
      this.executeConfirmScore();
      return;
    }

    const nameEl = document.getElementById('markerConfirmStudentName');
    const classEl = document.getElementById('markerConfirmStudentClass');
    const contentEl = document.getElementById('markerConfirmContentScore');
    const langEl = document.getElementById('markerConfirmLangScore');
    const totalEl = document.getElementById('markerConfirmTotalScore');
    const pctEl = document.getElementById('markerConfirmPct');
    const tagsEl = document.getElementById('markerConfirmTagsPreview');
    const remarkEl = document.getElementById('markerConfirmRemark');

    const displayName = student.chineseName ? `${student.name} (${student.chineseName})` : student.name;
    if (nameEl) nameEl.textContent = displayName;
    if (classEl) classEl.textContent = `Reg #${student.regNo} | Form: ${student.formClass} | MT: ${student.mtClass} | Script: ${student.scriptId}`;

    if (contentEl) contentEl.textContent = `${this.pendingSave.content} / ${state.config.contentMax}`;
    if (langEl) langEl.textContent = `${this.pendingSave.language} / ${state.config.languageMax}`;
    if (totalEl) totalEl.textContent = `${this.pendingSave.total} / ${state.config.totalMax}`;
    if (pctEl) pctEl.textContent = `${this.pendingSave.pct}%`;

    const advanceNoticeText = document.getElementById('markerConfirmAdvanceText');
    const advanceNoticeIcon = document.getElementById('markerConfirmAdvanceIcon');
    if (advanceNoticeText) {
      advanceNoticeText.textContent = 'Random Pick Protocol: Save score and pick next physical booklet from pile to verify';
      if (advanceNoticeIcon) advanceNoticeIcon.textContent = '📋';
    }

    if (tagsEl) {
      if (this.pendingSave.tags.length === 0) {
        tagsEl.innerHTML = `<span class="text-slate-400 italic text-xs">No qualitative tags selected</span>`;
      } else {
        tagsEl.innerHTML = this.pendingSave.tags.map(tag => {
          const isNegative = tag.includes('离题') || tag.includes('偏题') || tag.includes('病') || tag.includes('错') || tag.includes('不') || tag.includes('乱') || tag.includes('不足');
          const pillClass = isNegative 
            ? 'bg-rose-50 text-rose-800 border-rose-300' 
            : 'bg-emerald-50 text-emerald-800 border-emerald-300';
          return `<span class="inline-block px-2 py-0.5 text-[11px] rounded-md border font-medium ${pillClass}">${tag}</span>`;
        }).join(' ');
      }
    }

    if (remarkEl) {
      if (this.pendingSave.remark) {
        remarkEl.textContent = `"${this.pendingSave.remark}"`;
        remarkEl.classList.remove('hidden');
      } else {
        remarkEl.classList.add('hidden');
      }
    }

    modal.classList.remove('hidden');
    const confirmBtn = document.getElementById('btnConfirmMarkerScore');
    if (confirmBtn) confirmBtn.focus();
  }

  closeScoreConfirmationModal() {
    const modal = document.getElementById('markerConfirmModal');
    if (modal) modal.classList.add('hidden');
    this.pendingSave = null;
    const contentInput = document.getElementById('markerContentInput');
    if (contentInput) contentInput.focus();
  }

  executeConfirmScore() {
    if (!this.pendingSave) return;
    const state = db.getState();
    const payload = this.pendingSave;

    const res = db.saveStudentMark(
      payload.studentId,
      payload.markerCode,
      payload.content,
      payload.language,
      payload.tags,
      payload.remark
    );

    const modal = document.getElementById('markerConfirmModal');
    if (modal) modal.classList.add('hidden');
    this.pendingSave = null;

    if (res.success) {
      const currentList = state.students.filter(s => {
        if (this.classFilter !== 'ALL' && s[this.classFilterType] !== this.classFilter) return false;
        return s.status === 'unmarked';
      });

      this.renderMarkerHeader();
      this.populateClassFilters();
      this.renderClassProgressBar();
      this.renderStudentList();
      this.renderRecentMarkedTable();

      this.showToast(`✓ Confirmed & saved score (${payload.total}/${state.config.totalMax}) for ${res.student.name}!`);

      // Platinum Standard Exam Protocol: NEVER automatically push the next candidate's script.
      // Markers pick physical scripts randomly from the pile; they must search & verify candidate before marking.
      this.showPostSaveCard(res.student);
    }
  }

  clearActiveStudentForm() {
    if (this.graceCountdownTimer) {
      clearInterval(this.graceCountdownTimer);
      this.graceCountdownTimer = null;
    }
    this.selectedStudentId = null;
    this.isCurrentStudentVerified = false;
    try { sessionStorage.removeItem('SECS_MARKER_STUDENT_ID'); } catch (e) {}
    this.selectedTags.clear();
    const emptyNotice = document.getElementById('markerEmptySelectionNotice');
    const detailsBox = document.getElementById('markerActiveStudentCard');
    const scoringSection = document.getElementById('markerScoringForm');
    const pauseCard = document.getElementById('markerPostSavePauseCard');

    if (emptyNotice) emptyNotice.classList.remove('hidden');
    if (pauseCard) pauseCard.classList.add('hidden');
    if (detailsBox) detailsBox.classList.add('hidden');
    if (scoringSection) scoringSection.classList.add('hidden');

    const contentInput = document.getElementById('markerContentInput');
    const langInput = document.getElementById('markerLangInput');
    const remarkInput = document.getElementById('markerRemarkInput');
    if (contentInput) contentInput.value = '';
    if (langInput) langInput.value = '';
    if (remarkInput) remarkInput.value = '';

    this.renderStudentList();
  }

  renderRecentMarkedTable() {
    const tbody = document.getElementById('markerRecentTableBody');
    const countBadge = document.getElementById('markerMyCountBadge');
    if (!tbody) return;

    const state = db.getState();
    const myMarked = state.students
      .filter(s => s.markerCode === auth.session.markerCode && s.score && s.score.total !== null)
      .sort((a, b) => new Date(b.markedAt || 0) - new Date(a.markedAt || 0));

    if (countBadge) countBadge.textContent = `${myMarked.length} scripts marked`;

    if (myMarked.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" class="p-4 text-center text-xs text-slate-400">
            You haven't marked any scripts yet. Select a student from the list to start marking.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = myMarked.map(s => {
      const isBlind = state.config.blindMode;
      const displayName = isBlind ? s.scriptId : (s.chineseName ? `${s.name} (${s.chineseName})` : s.name);
      const editStatus = db.getStudentEditStatus(s);

      return `
        <tr class="hover:bg-slate-50 transition-colors">
          <td class="px-3 py-2 text-xs font-mono text-slate-500">${s.scriptId}</td>
          <td class="px-3 py-2 text-xs font-medium text-slate-800">${displayName}</td>
          <td class="px-3 py-2 text-xs text-slate-600">${s.formClass}</td>
          <td class="px-3 py-2 text-xs text-slate-600">${s.mtClass}</td>
          <td class="px-3 py-2 text-xs">
            ${isMod ? `
              <div class="flex items-center gap-1.5">
                <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-purple-100 text-purple-900 border border-purple-300 shadow-2xs">🟣 Moderated</span>
                <span class="font-bold font-mono text-purple-950">${s.score.total}/${state.config.totalMax}</span>
              </div>
              <div class="text-[10px] text-slate-500 font-mono mt-0.5">Orig: ${s.initialScore ? s.initialScore.total : (s.score.total - (s.moderation.delta || 0))} → Mod: ${s.score.total} (Δ ${(s.moderation.delta || 0) >= 0 ? '+' : ''}${s.moderation.delta || 0})</div>
            ` : `
              <span class="font-bold text-sky-700 font-mono">${s.score.content} + ${s.score.language} = ${s.score.total}</span>
            `}
          </td>
          <td class="px-3 py-2 text-xs text-slate-500 max-w-xs truncate">${(s.tags || []).join(', ') || s.remark || '-'}</td>
          <td class="px-3 py-2 text-xs text-right">
            ${isMod ? `
              <button onclick="markerApp.selectStudent('${s.id}')" class="px-2.5 py-1 rounded bg-purple-50 text-purple-800 hover:bg-purple-100 font-semibold cursor-pointer text-[11px] border border-purple-200" title="Script moderated by Key Personnel - View breakdown">
                🟣 View (Moderated)
              </button>
            ` : (editStatus.isEditable ? `
              <button onclick="markerApp.selectStudent('${s.id}')" class="px-2.5 py-1 rounded bg-amber-100 text-amber-900 hover:bg-amber-200 font-semibold cursor-pointer text-[11px] shadow-2xs border border-amber-300" title="${editStatus.remainingSec}s left to amend score">
                ⏱️ Amend (${Math.ceil(editStatus.remainingSec / 60)}m)
              </button>
            ` : `
              <button onclick="markerApp.selectStudent('${s.id}')" class="px-2.5 py-1 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 font-medium cursor-pointer text-[11px] border border-slate-200" title="10-minute amendment window expired - View only">
                🔒 View (Finalized)
              </button>
            `)}
          </td>
        </tr>
      `;
    }).join('');
  }

  showToast(msg) {
    const toast = document.getElementById('systemToast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.remove('translate-y-24', 'opacity-0');
    setTimeout(() => {
      toast.classList.add('translate-y-24', 'opacity-0');
    }, 2500);
  }

  // =========================================================================
  // KEY PERSONNEL (KP) MODERATION & SCRIPT SAMPLING HUB
  // =========================================================================

  switchMarkerTab(tabName) {
    const isKP = (typeof auth !== 'undefined' && auth.canModerate) ? auth.canModerate() : false;
    if (tabName === 'kpModeration' && !isKP) {
      const activeExam = typeof db !== 'undefined' ? db.getActiveExam() : null;
      const markerObj = (activeExam && Array.isArray(activeExam.markers))
        ? activeExam.markers.find(m => m.code === auth.session.markerCode)
        : null;
      if (markerObj && markerObj.isKP) {
        if (typeof app !== 'undefined') {
          app.openKpModeratorAuthModal(auth.session.markerCode, auth.session.markerName, activeExam.id);
        }
        return;
      } else {
        this.showToast('⚠️ Confidential: Key Personnel Moderator credentials required.', 'warning');
        tabName = 'marking';
      }
    }

    this.activeMarkerTab = tabName;

    const btnMarking = document.getElementById('btnMarkerTabMarking');
    const btnKp = document.getElementById('btnMarkerTabKpModeration');
    const markingPane = document.getElementById('markerMarkingPane');
    const kpPane = document.getElementById('markerKpModerationPane');
    const kpIndicator = document.getElementById('kpMarkerStatusIndicator');
    const markerNavTabBar = document.getElementById('markerNavTabBar');

    if (markerNavTabBar) {
      if (isKP) markerNavTabBar.classList.remove('hidden');
      else markerNavTabBar.classList.add('hidden');
    }

    if (tabName === 'marking') {
      if (btnMarking) {
        btnMarking.className = 'px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-2 bg-sky-600 text-white cursor-pointer';
      }
      if (btnKp) {
        if (isKP) {
          btnKp.className = 'px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 text-purple-700 bg-purple-50 hover:bg-purple-100 cursor-pointer border border-purple-200';
        } else {
          btnKp.className = 'hidden';
        }
      }
      if (markingPane) markingPane.classList.remove('hidden');
      if (kpPane) kpPane.classList.add('hidden');
      if (kpIndicator) {
        kpIndicator.classList.add('hidden');
        kpIndicator.classList.remove('flex');
      }
      this.renderStudentList();
      this.renderClassProgressBar();
      this.renderRecentMarkedTable();
    } else if (tabName === 'kpModeration' && isKP) {
      if (btnMarking) {
        btnMarking.className = 'px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer';
      }
      if (btnKp) {
        btnKp.className = 'px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 bg-purple-700 text-white shadow-xs border border-purple-700 cursor-pointer';
      }
      if (markingPane) markingPane.classList.add('hidden');
      if (kpPane) kpPane.classList.remove('hidden');
      if (kpIndicator) {
        kpIndicator.classList.remove('hidden');
        kpIndicator.classList.add('flex');
      }
      this.renderKpModerationHub();
    }
  }

  setKpSampleFilter(filterName) {
    this.kpSampleFilter = filterName;

    // Update pill styles
    const pills = document.querySelectorAll('.kp-sample-pill');
    pills.forEach(p => {
      const f = p.getAttribute('data-filter');
      if (f === filterName) {
        p.className = 'kp-sample-pill px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer bg-purple-700 text-white shadow-2xs';
      } else {
        p.className = 'kp-sample-pill px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-700';
      }
    });

    this.renderKpModerationHub();
  }

  handleKpFilterChange() {
    const fClass = document.getElementById('kpFormClassFilter');
    const mtClass = document.getElementById('kpMtClassFilter');
    const marker = document.getElementById('kpMarkerFilter');
    const status = document.getElementById('kpStatusFilter');

    if (fClass) this.kpFormClassFilter = fClass.value;
    if (mtClass) this.kpMtClassFilter = mtClass.value;
    if (marker) this.kpMarkerFilter = marker.value;
    if (status) this.kpStatusFilter = status.value;

    this.renderKpModerationHub();
  }

  handleKpSearch(query) {
    this.kpSearchQuery = (query || '').toLowerCase().trim();
    this.renderKpModerationHub();
  }

  renderKpModerationHub() {
    const state = db.getState();
    const config = state.config;
    const students = state.students || [];

    // Exam Title & Subtitle in KP Banner
    const titleEl = document.getElementById('kpPaperTitle');
    const subEl = document.getElementById('kpPaperSubtitle');
    if (titleEl) titleEl.textContent = config.examTitle || state.title || 'Paper 1 (Writing) Examination';
    if (subEl) subEl.textContent = `${config.level || 'Primary'} ${config.subject || 'Mother Tongue'} · ${config.component || 'Paper 1 (Writing)'}`;

    // Populate Dropdowns
    const fClassSelect = document.getElementById('kpFormClassFilter');
    if (fClassSelect) {
      const forms = Array.from(new Set(students.map(s => s.formClass))).filter(Boolean).sort();
      fClassSelect.innerHTML = '<option value="ALL">All Form Classes</option>' + 
        forms.map(f => `<option value="${f}">${f}</option>`).join('');
      fClassSelect.value = this.kpFormClassFilter;
    }

    const mtClassSelect = document.getElementById('kpMtClassFilter');
    if (mtClassSelect) {
      const mts = Array.from(new Set(students.map(s => s.mtClass))).filter(Boolean).sort();
      mtClassSelect.innerHTML = '<option value="ALL">All MT Classes</option>' + 
        mts.map(m => `<option value="${m}">${m}</option>`).join('');
      mtClassSelect.value = this.kpMtClassFilter;
    }

    const markerSelect = document.getElementById('kpMarkerFilter');
    if (markerSelect) {
      const markers = state.markers || [];
      markerSelect.innerHTML = '<option value="ALL">All Markers</option>' + 
        markers.map(m => `<option value="${m.code}">${m.code} - ${m.name}${m.isKP ? ' ⭐' : ''}</option>`).join('');
      markerSelect.value = this.kpMarkerFilter;
    }

    const statusSelect = document.getElementById('kpStatusFilter');
    if (statusSelect) {
      statusSelect.value = this.kpStatusFilter;
    }

    // Classify students for smart sampling
    const marked = students.filter(s => s.score && s.score.total !== null);
    const unmarked = students.filter(s => !s.score || s.score.total === null);
    const moderated = students.filter(s => s.moderation && s.moderation.moderated);

    const borderlinePass = marked.filter(s => s.score.pct >= 46 && s.score.pct <= 54);
    const borderlineQuality = marked.filter(s => s.score.pct >= 76 && s.score.pct <= 84);
    const outliers = marked.filter(s => Math.abs(s.score.content - s.score.language) >= Math.max(3, config.contentMax * 0.35));
    const random10 = marked.filter((_, idx) => idx % 10 === 0);
    const par = marked.filter(s => s.score.pct < config.passCutoffPct);
    const recommended = Array.from(new Set([...borderlinePass, ...borderlineQuality, ...outliers]));

    // Update KPI metric numbers
    const setText = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setText('kpStatTotal', students.length);
    setText('kpStatMarked', marked.length);
    setText('kpStatUnmarked', unmarked.length);
    setText('kpStatModerated', moderated.length);
    setText('kpStatRecommended', recommended.length);

    const badgeRec = document.getElementById('kpRecommendedCountBadge');
    if (badgeRec) badgeRec.textContent = `${recommended.length} Rec`;

    // Update Sampling Pill Badges
    setText('kpBadgeCountRec', recommended.length);
    setText('kpBadgeCountPass', borderlinePass.length);
    setText('kpBadgeCountQuality', borderlineQuality.length);
    setText('kpBadgeCountDiscrepancy', outliers.length);
    setText('kpBadgeCountRandom', random10.length);
    setText('kpBadgeCountPar', par.length);
    setText('kpBadgeCountUnmarked', unmarked.length);
    setText('kpBadgeCountAll', students.length);

    // Filter by Active Sample Pill
    let candidatePool = students;
    if (this.kpSampleFilter === 'recommended') {
      candidatePool = recommended;
    } else if (this.kpSampleFilter === 'borderlinePass') {
      candidatePool = borderlinePass;
    } else if (this.kpSampleFilter === 'borderlineQuality') {
      candidatePool = borderlineQuality;
    } else if (this.kpSampleFilter === 'outliers') {
      candidatePool = outliers;
    } else if (this.kpSampleFilter === 'random10') {
      candidatePool = random10;
    } else if (this.kpSampleFilter === 'par') {
      candidatePool = par;
    } else if (this.kpSampleFilter === 'unmarked') {
      candidatePool = unmarked;
    }

    // Secondary Filters
    const filtered = candidatePool.filter(s => {
      if (this.kpFormClassFilter !== 'ALL' && s.formClass !== this.kpFormClassFilter) return false;
      if (this.kpMtClassFilter !== 'ALL' && s.mtClass !== this.kpMtClassFilter) return false;
      if (this.kpMarkerFilter !== 'ALL' && s.markerCode !== this.kpMarkerFilter) return false;

      const isMarked = s.score && s.score.total !== null;
      const isMod = s.moderation && s.moderation.moderated;

      if (this.kpStatusFilter === 'MARKED' && !isMarked) return false;
      if (this.kpStatusFilter === 'UNMARKED' && isMarked) return false;
      if (this.kpStatusFilter === 'MODERATED' && !isMod) return false;

      if (this.kpSearchQuery) {
        const q = this.kpSearchQuery;
        const matchName = s.name.toLowerCase().includes(q);
        const matchChinese = s.chineseName && s.chineseName.toLowerCase().includes(q);
        const matchScript = s.scriptId.toLowerCase().includes(q);
        const matchReg = String(s.regNo) === q;
        const matchMarker = (s.markerCode || '').toLowerCase().includes(q);
        return matchName || matchChinese || matchScript || matchReg || matchMarker;
      }

      return true;
    });

    const countBadge = document.getElementById('kpModerationCountBadge');
    if (countBadge) countBadge.textContent = `${filtered.length} scripts matching`;

    // Render Table
    const tbody = document.getElementById('kpModerationTableBody');
    if (!tbody) return;

    if (filtered.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="9" class="p-8 text-center text-sm text-slate-400 bg-slate-50/50">
            No scripts match the current sampling criteria and filters. Select "All Scripts" or adjust your filters above.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = filtered.map(s => {
      const isMarked = s.score && s.score.total !== null;
      const isMod = s.moderation && s.moderation.moderated;
      const displayName = s.chineseName ? `${s.name} <span class="text-slate-500 font-normal">(${s.chineseName})</span>` : s.name;

      // Status Badge
      let statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">⚪ Unmarked</span>';
      if (isMod) {
        statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">🟣 Moderated</span>';
      } else if (isMarked) {
        const editStatus = db.getStudentEditStatus(s);
        if (editStatus.isEditable) {
          const remM = Math.ceil(editStatus.remainingSec / 60);
          statusBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300" title="Marker amendment window active (${editStatus.remainingSec}s remaining)">⏱️ Marker Window (${remM}m)</span>`;
        } else {
          statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200" title="10-minute edit window elapsed. Finalized and ready for moderation.">🔒 Finalized (Ready)</span>';
        }
      }

      // First Mark
      let firstMarkLabel = '<span class="text-slate-400">-</span>';
      if (isMarked) {
        const orig = s.initialScore || s.score;
        firstMarkLabel = `
          <div class="font-bold text-slate-800 font-mono">${orig.total} <span class="text-xs font-normal text-slate-500">/ ${config.totalMax}</span></div>
          <div class="text-[10px] text-slate-400 font-mono">${orig.content}C + ${orig.language}L (${orig.pct}%)</div>
        `;
      }

      // Moderated Score & Delta
      let modLabel = '<span class="text-slate-400">-</span>';
      if (isMod) {
        const delta = s.moderation.delta;
        let deltaClass = 'bg-slate-100 text-slate-700';
        let deltaText = 'Δ 0 (Agreed)';
        if (delta > 0) {
          deltaClass = 'bg-emerald-100 text-emerald-800';
          deltaText = `Δ +${delta}`;
        } else if (delta < 0) {
          deltaClass = 'bg-rose-100 text-rose-800';
          deltaText = `Δ ${delta}`;
        }
        modLabel = `
          <div class="font-extrabold text-purple-900 font-mono">${s.score.total} <span class="text-xs font-normal text-slate-500">/ ${config.totalMax}</span></div>
          <span class="inline-block px-1.5 py-0.2 rounded text-[10px] font-bold ${deltaClass}">${deltaText}</span>
        `;
      }

      // Sampling Recommendation Tag
      let recTags = [];
      if (!isMarked) {
        recTags.push('<span class="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-500">Pending Marking</span>');
      } else {
        if (s.score.pct >= 46 && s.score.pct <= 54) {
          recTags.push('<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">🟡 Borderline Pass</span>');
        }
        if (s.score.pct >= 76 && s.score.pct <= 84) {
          recTags.push('<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">🟢 Quality Edge</span>');
        }
        if (Math.abs(s.score.content - s.score.language) >= Math.max(3, config.contentMax * 0.35)) {
          recTags.push('<span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">⚡ Discrepancy</span>');
        }
        if (recTags.length === 0) {
          recTags.push('<span class="px-1.5 py-0.5 rounded text-[10px] text-slate-400">Standard</span>');
        }
      }

      // Action Button
      const actionBtn = `
        <button onclick="markerApp.openKpModerationDrawer('${s.id}')" 
                class="px-3 py-1.5 ${isMod ? 'bg-indigo-600 hover:bg-indigo-700' : (isMarked ? 'bg-purple-600 hover:bg-purple-700' : 'bg-slate-700 hover:bg-slate-800')} text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1">
          <span>${isMod ? '✏️ Edit Moderation' : (isMarked ? '🔍 Moderate' : '✏️ Moderate / Mark')}</span>
        </button>
      `;

      let markerCellHtml = `<div class="font-bold text-slate-700 font-mono">${s.markerCode || '-'}</div>`;
      if (isMod) {
        const modCode = (s.moderation && s.moderation.moderatorCode)
          ? s.moderation.moderatorCode
          : (s.moderation && s.moderation.moderatedBy ? (s.moderation.moderatedBy.match(/\(([^)]+)\)/)?.[1] || s.moderation.moderatedBy) : 'MOD');
        markerCellHtml += `
          <div class="mt-0.5">
            <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200" title="Moderated by ${s.moderation?.moderatedBy || modCode}">
              Mod: ${modCode}
            </span>
          </div>`;
      }

      return `
        <tr class="hover:bg-purple-50/30 transition-colors text-xs text-slate-700">
          <td class="px-3 py-3 font-mono font-bold text-slate-600">${s.scriptId}</td>
          <td class="px-3 py-3 font-medium">${displayName}</td>
          <td class="px-3 py-3">${s.formClass} <span class="text-slate-400 font-mono text-[11px]">(${s.mtClass})</span></td>
          <td class="px-3 py-3 font-mono text-slate-700">${markerCellHtml}</td>
          <td class="px-3 py-3 text-center">${statusBadge}</td>
          <td class="px-3 py-3 text-center">${firstMarkLabel}</td>
          <td class="px-3 py-3 text-center">${modLabel}</td>
          <td class="px-3 py-3"><div class="flex flex-wrap gap-1">${recTags.join('')}</div></td>
          <td class="px-3 py-3 text-right">${actionBtn}</td>
        </tr>
      `;
    }).join('');
  }

  openKpModerationDrawer(studentId) {
    this.kpModeratingStudentId = studentId;
    const state = db.getState();
    const config = state.config;
    const student = state.students.find(s => s.id === studentId);

    if (!student) return;

    const modal = document.getElementById('kpModerationModal');
    if (!modal) return;

    // Student Demographics
    const nameEl = document.getElementById('kpModStudentName');
    const scriptEl = document.getElementById('kpModScriptId');
    const classEl = document.getElementById('kpModFormClass');
    if (nameEl) nameEl.textContent = student.chineseName ? `${student.name} (${student.chineseName})` : student.name;
    if (scriptEl) scriptEl.textContent = student.scriptId;
    if (classEl) classEl.textContent = `(${student.formClass}${student.mtClass ? ' / ' + student.mtClass : ''})`;

    // First Marker Details
    const isScriptMarked = student.score && student.score.total !== null;
    const orig = student.initialScore || (isScriptMarked ? student.score : null);
    const markerEl = document.getElementById('kpModMarkerLabel');
    const firstContentEl = document.getElementById('kpModFirstContent');
    const firstLangEl = document.getElementById('kpModFirstLang');
    const firstTotalEl = document.getElementById('kpModFirstTotal');
    const firstRemarkEl = document.getElementById('kpModFirstRemark');
    const firstTagsEl = document.getElementById('kpModFirstTagsContainer');

    if (markerEl) markerEl.textContent = student.markerCode || 'M01';
    if (orig && orig.total !== null) {
      if (firstContentEl) firstContentEl.textContent = `${orig.content} / ${config.contentMax}`;
      if (firstLangEl) firstLangEl.textContent = `${orig.language} / ${config.languageMax}`;
      if (firstTotalEl) firstTotalEl.textContent = `${orig.total} (${orig.pct}%)`;
    } else {
      if (firstContentEl) firstContentEl.textContent = 'Unmarked';
      if (firstLangEl) firstLangEl.textContent = 'Unmarked';
      if (firstTotalEl) firstTotalEl.textContent = 'Unmarked';
    }
    if (firstRemarkEl) firstRemarkEl.textContent = student.remark ? `"${student.remark}"` : 'No qualitative remarks recorded.';

    // Tags - Aligned with config and fallback safe
    if (firstTagsEl) {
      const tags = student.tags || [];
      if (tags.length === 0) {
        firstTagsEl.innerHTML = '<span class="text-xs text-slate-400 italic">No feedback descriptors selected.</span>';
      } else {
        const fb = state.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS;
        const allTags = fb.all || [...(fb.strengths || []), ...(fb.mistakes || [])];
        firstTagsEl.innerHTML = tags.map(tagText => {
          const tagObj = allTags.find(t => t.label === tagText);
          const isWeakness = tagObj ? tagObj.sentiment === 'negative' : false;
          const badgeClass = isWeakness 
            ? 'bg-rose-50 text-rose-800 border-rose-200' 
            : 'bg-emerald-50 text-emerald-800 border-emerald-200';
          return `<span class="px-2 py-0.5 rounded-md text-[11px] font-semibold border ${badgeClass}">${tagText}</span>`;
        }).join('');
      }
    }

    // Set Max mark labels
    const cMax = document.getElementById('kpModContentMaxLabel');
    const lMax = document.getElementById('kpModLangMaxLabel');
    if (cMax) cMax.textContent = `/ ${config.contentMax}`;
    if (lMax) lMax.textContent = `/ ${config.languageMax}`;

    // Pre-fill KP Moderation Inputs
    const cInput = document.getElementById('kpModContentInput');
    const lInput = document.getElementById('kpModLangInput');
    const rInput = document.getElementById('kpModRemarkInput');

    const curC = student.moderation ? student.moderation.hodContent : (student.score && student.score.content !== null ? student.score.content : '');
    const curL = student.moderation ? student.moderation.hodLanguage : (student.score && student.score.language !== null ? student.score.language : '');

    if (cInput) {
      cInput.value = curC;
      cInput.max = config.contentMax;
      cInput.min = config.contentMin;
    }
    if (lInput) {
      lInput.value = curL;
      lInput.max = config.languageMax;
      lInput.min = config.languageMin;
    }
    if (rInput) {
      rInput.value = student.moderation ? (student.moderation.hodRemark || '') : '';
    }

    this.handleKpModerationScoreChange();
    modal.classList.remove('hidden');

    // Auto-focus content input
    setTimeout(() => {
      if (cInput) cInput.focus();
    }, 100);
  }

  agreeWithFirstMarker() {
    const state = db.getState();
    const student = state.students.find(s => s.id === this.kpModeratingStudentId);
    if (!student) return;

    const orig = student.initialScore || student.score;
    if (!orig || orig.total === null) {
      alert('This script has not been marked by a first marker yet.');
      return;
    }

    const cInput = document.getElementById('kpModContentInput');
    const lInput = document.getElementById('kpModLangInput');
    const rInput = document.getElementById('kpModRemarkInput');

    if (cInput) cInput.value = orig.content;
    if (lInput) lInput.value = orig.language;
    if (rInput && !rInput.value.trim()) {
      rInput.value = 'Sample checked and verified. Concurred with original marker score.';
    }

    this.handleKpModerationScoreChange();
    this.showToast('Copied first marker scores (Δ 0 Agreement)!');
  }

  handleKpModerationScoreChange() {
    const state = db.getState();
    const config = state.config;
    const student = state.students.find(s => s.id === this.kpModeratingStudentId);
    if (!student) return;

    const cInput = document.getElementById('kpModContentInput');
    const lInput = document.getElementById('kpModLangInput');
    const totalEl = document.getElementById('kpModTotalLabel');
    const deltaBadge = document.getElementById('kpModDeltaBadge');

    const cRaw = cInput ? cInput.value : '';
    const lRaw = lInput ? lInput.value : '';

    if (cRaw === '' && lRaw === '') {
      if (totalEl) totalEl.textContent = '-';
      if (deltaBadge) {
        deltaBadge.className = 'px-2 py-0.5 rounded text-xs font-bold bg-slate-100 text-slate-700';
        deltaBadge.textContent = 'Pending input';
      }
      return;
    }

    let c = Number(cRaw || 0);
    let l = Number(lRaw || 0);

    if (isNaN(c)) c = 0;
    if (isNaN(l)) l = 0;

    if (c > config.contentMax) c = config.contentMax;
    if (c < 0) c = 0;
    if (l > config.languageMax) l = config.languageMax;
    if (l < 0) l = 0;

    const total = c + l;
    const pct = Math.round((total / config.totalMax) * 1000) / 10;
    if (totalEl) totalEl.textContent = `${total} (${pct}%)`;

    const initialTotal = student.initialScore ? student.initialScore.total : (student.score && student.score.total !== null ? student.score.total : null);

    if (deltaBadge) {
      if (initialTotal === null) {
        deltaBadge.className = 'px-2 py-0.5 rounded text-xs font-bold bg-purple-100 text-purple-800';
        deltaBadge.textContent = 'Direct Moderation';
      } else {
        const delta = total - initialTotal;
        if (delta === 0) {
          deltaBadge.className = 'px-2 py-0.5 rounded text-xs font-bold bg-slate-100 text-slate-700';
          deltaBadge.textContent = 'Δ 0 (Agreed)';
        } else if (delta > 0) {
          deltaBadge.className = 'px-2 py-0.5 rounded text-xs font-bold bg-emerald-100 text-emerald-800';
          deltaBadge.textContent = `Δ +${delta} (Upgraded)`;
        } else {
          deltaBadge.className = 'px-2 py-0.5 rounded text-xs font-bold bg-rose-100 text-rose-800';
          deltaBadge.textContent = `Δ ${delta} (Downgraded)`;
        }
      }
    }
  }

  closeKpModerationDrawer() {
    const modal = document.getElementById('kpModerationModal');
    if (modal) modal.classList.add('hidden');
    this.kpModeratingStudentId = null;
  }

  submitKpModeration() {
    const state = db.getState();
    const config = state.config;
    const student = state.students.find(s => s.id === this.kpModeratingStudentId);
    if (!student) return;

    const cInput = document.getElementById('kpModContentInput');
    const lInput = document.getElementById('kpModLangInput');
    const rInput = document.getElementById('kpModRemarkInput');

    const cVal = cInput ? cInput.value.trim() : '';
    const lVal = lInput ? lInput.value.trim() : '';

    if (cVal === '' || lVal === '') {
      alert('Please enter both Content and Language scores to moderate.');
      return;
    }

    const c = Number(cVal);
    const l = Number(lVal);
    const remark = rInput ? rInput.value.trim() : '';

    if (isNaN(c) || c < 0 || c > config.contentMax) {
      alert(`Content mark must be a valid number between 0 and ${config.contentMax}.`);
      return;
    }
    if (isNaN(l) || l < 0 || l > config.languageMax) {
      alert(`Language mark must be a valid number between 0 and ${config.languageMax}.`);
      return;
    }

    const moderatorName = (typeof auth !== 'undefined' && auth.session && auth.session.markerName) 
      ? `${auth.session.markerName} (${auth.session.markerCode || 'KP'})`
      : 'KP Moderator';

    db.moderateStudent(this.kpModeratingStudentId, c, l, remark, moderatorName);

    this.closeKpModerationDrawer();
    this.renderKpModerationHub();
    this.renderClassProgressBar();
    this.renderMarkerHeader();
    this.showToast(`Script ${student.scriptId} (${student.name}) moderated successfully: ${c + l}/${config.totalMax}!`);
  }
}

const markerApp = new MarkerController();
window.markerApp = markerApp;
