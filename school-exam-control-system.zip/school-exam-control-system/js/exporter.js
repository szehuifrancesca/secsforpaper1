/**
 * SECS - Multi-Format Export Engine (Excel, Word, PDF, Email, JSON)
 * Supports:
 * 1. Simplified Class Teacher Diagnostic Report (clean, pedagogical, initial vs final marks, tags, remarks)
 * 2. Comprehensive HOD Post-Exam Audit Report (configurable sections, calibration, moderation audit log, dual marks)
 * 3. Cohort or Specific Class scope with authentic Singapore primary Chinese composition feedback tags
 */

class ExportService {
  /**
   * Helper: Determine Achievement Band
   */
  getBand(score, totalMax) {
    if (!score || score.total === null || score.total === undefined) return '-';
    const pct = (score.total / totalMax) * 100;
    if (pct >= 80) return 'Band 1 (>=80%)';
    if (pct >= 65) return 'Band 2 (65-79%)';
    if (pct >= 50) return 'Band 3 (50-64%)';
    return 'Band 4 (<50%)';
  }

  /**
   * Helper: Clean string for safe filename
   */
  cleanFilename(str) {
    return (str || 'Report')
      .replace(/[()]/g, '')
      .replace(/[^a-zA-Z0-9_\u4e00-\u9fa5-]/g, '_')
      .replace(/_+/g, '_')
      .replace(/^_|_$/g, '');
  }

  /**
   * Export Master Consolidated Data or Class Diagnostic to Excel (.xlsx) using SheetJS
   */
  exportToExcel(students, config, markers, scopeOptions = { scope: 'cohort', reportType: 'hod' }) {
    if (typeof XLSX === 'undefined') {
      alert('Excel export library is loading or unavailable.');
      return;
    }

    const wb = XLSX.utils.book_new();
    const dateStr = new Date().toISOString().slice(0, 10);
    const reportType = scopeOptions.reportType || 'hod';
    const sections = scopeOptions.sections || {
      executive: true,
      descriptive: true,
      classComp: true,
      bands: true,
      tags: true,
      moderation: true,
      calibration: true,
      roster: true
    };

    const isClassScope = scopeOptions.scope === 'class' && scopeOptions.className;
    const classKey = scopeOptions.classType || 'formClass';
    const targetStudents = isClassScope
      ? students.filter(s => s[classKey] === scopeOptions.className)
      : students;

    const cohortStats = analytics.computeCohortStats(students, config);
    const targetStats = isClassScope ? analytics.computeCohortStats(targetStudents, config) : cohortStats;
    const feedbackAnalysis = analytics.computeClassFeedbackAnalysis(targetStudents, config);

    // =========================================================================
    // OPTION A: CLASS TEACHER REPORT (Simplified, Pedagogical, Dual Marks)
    // =========================================================================
    if (reportType === 'classTeacher') {
      // Sheet 1: Pupil Diagnostic Roster (Clean, No Administrative Clutter)
      const rosterData = targetStudents.map(s => {
        const isMarked = s.score && s.score.total !== null;
        const isModerated = !!(s.moderation && s.moderation.moderated);
        
        // Initial marks (strictly for moderated pupils)
        const initContent = isModerated ? (s.initialScore ? s.initialScore.content : (s.moderation.originalScore ? s.moderation.originalScore.content : '')) : '';
        const initLang = isModerated ? (s.initialScore ? s.initialScore.language : (s.moderation.originalScore ? s.moderation.originalScore.language : '')) : '';
        const initTotal = isModerated ? (s.initialScore ? s.initialScore.total : (s.moderation.originalScore ? s.moderation.originalScore.total : '')) : '';
        const delta = isModerated ? s.moderation.delta : 0;

        // Final marks (always displayed for all marked pupils!)
        const finalContent = isMarked ? s.score.content : '';
        const finalLang = isMarked ? s.score.language : '';
        const finalTotal = isMarked ? s.score.total : '';

        return {
          'Reg No': s.regNo,
          'Student Name (English)': s.name,
          'Chinese Name (华文姓名)': s.chineseName || '',
          'Form Class': s.formClass,
          'MT Class': s.mtClass,
          'Initial Content (初评内容)': isModerated ? initContent : '-',
          'Initial Language (初评表达)': isModerated ? initLang : '-',
          'Initial Mark (初评总分)': isModerated ? initTotal : '-',
          'Final Content (定评内容)': finalContent,
          'Final Language (定评表达)': finalLang,
          'Final Total Mark (最终总分)': finalTotal,
          'Moderation Delta (调整分)': isModerated ? (delta > 0 ? `+${delta}` : delta) : '-',
          'Percentage (%)': isMarked ? s.score.pct : '',
          'Achievement Band': this.getBand(s.score, config.totalMax),
          'Feedback Tags (评语标签)': (s.tags || []).join('; '),
          'Marker Qualitative Remarks (评语)': s.remark || ''
        };
      });
      const wsRoster = XLSX.utils.json_to_sheet(rosterData);
      XLSX.utils.book_append_sheet(wb, wsRoster, 'Pupil Diagnostic Roster');

      // Sheet 2: Class Performance & Cohort Benchmark
      const deltaMean = Math.round((targetStats.mean - cohortStats.mean) * 10) / 10;
      const perfData = [
        { Indicator: 'Target Class', 'Class Value': isClassScope ? scopeOptions.className : 'All Classes', 'Cohort Benchmark': 'Entire Cohort', 'Variance (Δ)': isClassScope ? `${deltaMean >= 0 ? '+' : ''}${deltaMean}` : '-' },
        { Indicator: 'Examination Title', 'Class Value': config.examTitle, 'Cohort Benchmark': config.examTitle, 'Variance (Δ)': '-' },
        { Indicator: 'Subject & Level', 'Class Value': `${config.level} - ${config.subject}`, 'Cohort Benchmark': `${config.level} - ${config.subject}`, 'Variance (Δ)': '-' },
        { Indicator: 'Total Candidature', 'Class Value': targetStats.totalCandidature, 'Cohort Benchmark': cohortStats.totalCandidature, 'Variance (Δ)': '-' },
        { Indicator: 'Scripts Marked', 'Class Value': `${targetStats.totalMarked} (${Math.round((targetStats.totalMarked / (targetStats.totalCandidature || 1)) * 100)}%)`, 'Cohort Benchmark': `${cohortStats.totalMarked} (${Math.round((cohortStats.totalMarked / (cohortStats.totalCandidature || 1)) * 100)}%)`, 'Variance (Δ)': '-' },
        { Indicator: 'Class Average (Mean)', 'Class Value': `${targetStats.mean} / ${config.totalMax}`, 'Cohort Benchmark': `${cohortStats.mean} / ${config.totalMax}`, 'Variance (Δ)': `${deltaMean >= 0 ? '+' : ''}${deltaMean}` },
        { Indicator: 'Content Component Mean', 'Class Value': `${targetStats.contentMean} / ${config.contentMax}`, 'Cohort Benchmark': `${cohortStats.contentMean} / ${config.contentMax}`, 'Variance (Δ)': `${Math.round((targetStats.contentMean - cohortStats.contentMean) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.contentMean - cohortStats.contentMean) * 10) / 10}` },
        { Indicator: 'Language Component Mean', 'Class Value': `${targetStats.langMean} / ${config.languageMax}`, 'Cohort Benchmark': `${cohortStats.langMean} / ${config.languageMax}`, 'Variance (Δ)': `${Math.round((targetStats.langMean - cohortStats.langMean) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.langMean - cohortStats.langMean) * 10) / 10}` },
        { Indicator: 'Median Mark', 'Class Value': targetStats.median, 'Cohort Benchmark': cohortStats.median, 'Variance (Δ)': `${Math.round((targetStats.median - cohortStats.median) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.median - cohortStats.median) * 10) / 10}` },
        { Indicator: 'Standard Deviation', 'Class Value': targetStats.stdDev, 'Cohort Benchmark': cohortStats.stdDev, 'Variance (Δ)': '-' },
        { Indicator: 'Score Range (Min - Max)', 'Class Value': `${targetStats.min} - ${targetStats.max}`, 'Cohort Benchmark': `${cohortStats.min} - ${cohortStats.max}`, 'Variance (Δ)': '-' },
        { Indicator: `Quality Pass Rate (>= ${config.qualityCutoffPct}%)`, 'Class Value': `${targetStats.qualityCount} (${targetStats.qualityPct}%)`, 'Cohort Benchmark': `${cohortStats.qualityCount} (${cohortStats.qualityPct}%)`, 'Variance (Δ)': `${Math.round((targetStats.qualityPct - cohortStats.qualityPct) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.qualityPct - cohortStats.qualityPct) * 10) / 10}%` },
        { Indicator: `Pass Rate (>= ${config.passCutoffPct}%)`, 'Class Value': `${targetStats.passCount} (${targetStats.passPct}%)`, 'Cohort Benchmark': `${cohortStats.passCount} (${cohortStats.passPct}%)`, 'Variance (Δ)': `${Math.round((targetStats.passPct - cohortStats.passPct) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.passPct - cohortStats.passPct) * 10) / 10}%` },
        { Indicator: `Pupils-at-Risk (PAR < ${config.passCutoffPct}%)`, 'Class Value': `${targetStats.parCount} (${targetStats.parPct}%)`, 'Cohort Benchmark': `${cohortStats.parCount} (${cohortStats.parPct}%)`, 'Variance (Δ)': `${Math.round((targetStats.parPct - cohortStats.parPct) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.parPct - cohortStats.parPct) * 10) / 10}%` },
        { Indicator: 'Band 1 (Exemplary >= 80%)', 'Class Value': `${targetStats.bandCounts.band1} (${Math.round((targetStats.bandCounts.band1 / (targetStats.totalMarked || 1)) * 100)}%)`, 'Cohort Benchmark': `${cohortStats.bandCounts.band1} (${Math.round((cohortStats.bandCounts.band1 / (cohortStats.totalMarked || 1)) * 100)}%)`, 'Variance (Δ)': '-' },
        { Indicator: 'Band 2 (Competent 65% - 79%)', 'Class Value': `${targetStats.bandCounts.band2} (${Math.round((targetStats.bandCounts.band2 / (targetStats.totalMarked || 1)) * 100)}%)`, 'Cohort Benchmark': `${cohortStats.bandCounts.band2} (${Math.round((cohortStats.bandCounts.band2 / (cohortStats.totalMarked || 1)) * 100)}%)`, 'Variance (Δ)': '-' },
        { Indicator: 'Band 3 (Pass 50% - 64%)', 'Class Value': `${targetStats.bandCounts.band3} (${Math.round((targetStats.bandCounts.band3 / (targetStats.totalMarked || 1)) * 100)}%)`, 'Cohort Benchmark': `${cohortStats.bandCounts.band3} (${Math.round((cohortStats.bandCounts.band3 / (cohortStats.totalMarked || 1)) * 100)}%)`, 'Variance (Δ)': '-' },
        { Indicator: 'Band 4 (PAR < 50%)', 'Class Value': `${targetStats.bandCounts.band4} (${Math.round((targetStats.bandCounts.band4 / (targetStats.totalMarked || 1)) * 100)}%)`, 'Cohort Benchmark': `${cohortStats.bandCounts.band4} (${Math.round((cohortStats.bandCounts.band4 / (cohortStats.totalMarked || 1)) * 100)}%)`, 'Variance (Δ)': '-' }
      ];
      const wsPerf = XLSX.utils.json_to_sheet(perfData);
      XLSX.utils.book_append_sheet(wb, wsPerf, 'Class vs Cohort Benchmark');

      // Sheet 3: Feedback & Pedagogical Action Points
      const feedbackRows = [];
      feedbackRows.push({ Category: '=== 1. OBSERVED CLASS WRITING STRENGTHS ===', Item: '', Count: '', 'Prevalence (%)': '' });
      feedbackAnalysis.strengths.forEach(s => {
        feedbackRows.push({ Category: 'Writing Strength', Item: s.tag, Count: s.count, 'Prevalence (%)': `${s.pct}%` });
      });
      if (feedbackAnalysis.strengths.length === 0) {
        feedbackRows.push({ Category: 'Writing Strength', Item: 'No positive feedback tags recorded yet.', Count: 0, 'Prevalence (%)': '0%' });
      }

      feedbackRows.push({ Category: '', Item: '', Count: '', 'Prevalence (%)': '' });
      feedbackRows.push({ Category: '=== 2. COMMON LEARNING GAPS & EXAM SLIPS ===', Item: '', Count: '', 'Prevalence (%)': '' });
      feedbackAnalysis.learningGaps.forEach(g => {
        feedbackRows.push({ Category: 'Common Learning Gap', Item: g.tag, Count: g.count, 'Prevalence (%)': `${g.pct}%` });
      });
      if (feedbackAnalysis.learningGaps.length === 0) {
        feedbackRows.push({ Category: 'Common Learning Gap', Item: 'No writing weaknesses flagged.', Count: 0, 'Prevalence (%)': '0%' });
      }

      feedbackRows.push({ Category: '', Item: '', Count: '', 'Prevalence (%)': '' });
      feedbackRows.push({ Category: '=== 3. RECOMMENDED PEDAGOGICAL ACTION POINTS ===', Item: '', Count: '', 'Prevalence (%)': '' });
      feedbackAnalysis.actionPoints.forEach((ap, idx) => {
        feedbackRows.push({ Category: `Action Point ${idx + 1}`, Item: ap, Count: '', 'Prevalence (%)': '' });
      });

      const wsFeedback = XLSX.utils.json_to_sheet(feedbackRows);
      XLSX.utils.book_append_sheet(wb, wsFeedback, 'Writing Strengths & Gaps');

      const fileNamePrefix = isClassScope ? this.cleanFilename(scopeOptions.className) : 'All_Classes';
      XLSX.writeFile(wb, `${fileNamePrefix}_Class_Teacher_Report_${dateStr}.xlsx`);
      return;
    }

    // =========================================================================
    // OPTION B: COMPREHENSIVE HOD AUDIT WORKBOOK (Configurable Sections)
    // =========================================================================
    let sheetCount = 0;

    // 1. Master Marks Roster (with Dual Initial vs Final Marks)
    if (sections.roster !== false) {
      const marksData = targetStudents.map(s => {
        const isMarked = s.score && s.score.total !== null;
        const initTotal = s.initialScore ? s.initialScore.total : (isMarked ? s.score.total : '');
        const initContent = s.initialScore ? s.initialScore.content : (isMarked ? s.score.content : '');
        const initLang = s.initialScore ? s.initialScore.language : (isMarked ? s.score.language : '');
        const finalTotal = isMarked ? s.score.total : '';
        const finalContent = isMarked ? s.score.content : '';
        const finalLang = isMarked ? s.score.language : '';
        const isModerated = !!(s.moderation && s.moderation.moderated);
        const delta = isModerated
          ? s.moderation.delta
          : (isMarked && s.initialScore ? (s.score.total - s.initialScore.total) : 0);

        return {
          'Script ID': s.scriptId,
          'Form Class': s.formClass,
          'MT Class': s.mtClass,
          'Reg No': s.regNo,
          'Student Name (English)': s.name,
          'Chinese Name (华文姓名)': s.chineseName || '',
          'Marker Code': s.markerCode || 'Unassigned',
          'Marking Status': s.status ? s.status.toUpperCase() : 'UNMARKED',
          'Initial Content (初评内容)': initContent,
          'Initial Language (初评表达)': initLang,
          'Initial Total Mark (初评总分)': initTotal,
          'Final Content (定评内容)': finalContent,
          'Final Language (定评表达)': finalLang,
          'Final Total Mark (最终总分)': finalTotal,
          'Percentage (%)': isMarked ? s.score.pct : '',
          'Achievement Band': this.getBand(s.score, config.totalMax),
          'Moderated': isModerated ? 'YES' : 'NO',
          'Moderator Code': isModerated ? (s.moderation.moderatorCode || (s.moderation.moderatedBy ? (s.moderation.moderatedBy.match(/\(([^)]+)\)/)?.[1] || s.moderation.moderatedBy) : 'HOD')) : '',
          'Moderated By': isModerated ? (s.moderation.moderatedBy || 'Moderator') : '',
          'Moderation Delta (调整分)': isMarked && isModerated ? (delta > 0 ? `+${delta}` : delta) : 0,
          'Moderation Reason': isModerated ? (s.moderation.reason || 'Audit Sample') : '',
          'Feedback Tags': (s.tags || []).join('; '),
          'Marker / HOD Remarks': s.remark || ''
        };
      });
      const wsMarks = XLSX.utils.json_to_sheet(marksData);
      XLSX.utils.book_append_sheet(wb, wsMarks, isClassScope ? 'Class Marks Roster' : 'Master Marks Roster');
      sheetCount++;
    }

    // 2. Cohort Statistics & Item Analysis
    if (sections.descriptive !== false || sections.executive !== false) {
      const statsData = [
        { Metric: 'Examination Title', Value: config.examTitle },
        { Metric: 'Subject & Level', Value: `${config.level} - ${config.subject}` },
        { Metric: 'Scope of Report', Value: isClassScope ? `Class: ${scopeOptions.className}` : 'Entire Cohort' },
        { Metric: 'Content Maximum Mark', Value: config.contentMax },
        { Metric: 'Language Maximum Mark', Value: config.languageMax },
        { Metric: 'Total Maximum Mark', Value: config.totalMax },
        { Metric: 'Total Candidature', Value: targetStats.totalCandidature },
        { Metric: 'Total Scripts Marked', Value: targetStats.totalMarked },
        { Metric: 'Total Unmarked Scripts', Value: targetStats.totalUnmarked },
        { Metric: 'Total Moderated Scripts', Value: targetStats.totalModerated },
        { Metric: 'Overall Mean (Average)', Value: targetStats.mean },
        { Metric: 'Content Mean', Value: targetStats.contentMean },
        { Metric: 'Language Mean', Value: targetStats.langMean },
        { Metric: 'Median Mark', Value: targetStats.median },
        { Metric: 'Standard Deviation (Spread)', Value: targetStats.stdDev },
        { Metric: 'Minimum Mark', Value: targetStats.min },
        { Metric: 'Maximum Mark', Value: targetStats.max },
        { Metric: `Quality Pass Rate (>= ${config.qualityCutoffPct}%)`, Value: `${targetStats.qualityCount} (${targetStats.qualityPct}%)` },
        { Metric: `Pass Rate (>= ${config.passCutoffPct}%)`, Value: `${targetStats.passCount} (${targetStats.passPct}%)` },
        { Metric: `Pupils-at-Risk (PAR < ${config.passCutoffPct}%)`, Value: `${targetStats.parCount} (${targetStats.parPct}%)` }
      ];
      const wsStats = XLSX.utils.json_to_sheet(statsData);
      XLSX.utils.book_append_sheet(wb, wsStats, 'Item Analysis');
      sheetCount++;
    }

    // 3. Class Performance Comparison
    if (sections.classComp !== false) {
      const mtBreakdown = analytics.computeGroupBreakdown(students, 'mtClass', config);
      const formBreakdown = analytics.computeGroupBreakdown(students, 'formClass', config);
      const compRows = [];

      compRows.push({ 'Class Classification': '=== MOTHER TONGUE BANDED CLASSES ===', Class: '', Candidature: '', Marked: '', Mean: '', 'Pass Rate (%)': '', 'Quality Pass (%)': '', 'PAR Count': '' });
      mtBreakdown.forEach(m => {
        compRows.push({
          'Class Classification': 'Mother Tongue',
          Class: m.groupName,
          Candidature: m.totalCount,
          Marked: m.markedCount,
          Mean: `${m.mean} / ${config.totalMax}`,
          'Pass Rate (%)': `${m.passPct}%`,
          'Quality Pass (%)': `${m.qualityPct}%`,
          'PAR Count': m.parCount
        });
      });

      compRows.push({ 'Class Classification': '', Class: '', Candidature: '', Marked: '', Mean: '', 'Pass Rate (%)': '', 'Quality Pass (%)': '', 'PAR Count': '' });
      compRows.push({ 'Class Classification': '=== FORM CLASSES ===', Class: '', Candidature: '', Marked: '', Mean: '', 'Pass Rate (%)': '', 'Quality Pass (%)': '', 'PAR Count': '' });
      formBreakdown.forEach(f => {
        compRows.push({
          'Class Classification': 'Form Class',
          Class: f.groupName,
          Candidature: f.totalCount,
          Marked: f.markedCount,
          Mean: `${f.mean} / ${config.totalMax}`,
          'Pass Rate (%)': `${f.passPct}%`,
          'Quality Pass (%)': `${f.qualityPct}%`,
          'PAR Count': f.parCount
        });
      });

      const wsComp = XLSX.utils.json_to_sheet(compRows);
      XLSX.utils.book_append_sheet(wb, wsComp, 'Class Breakdown');
      sheetCount++;
    }

    // 4. Achievement Bands Distribution
    if (sections.bands !== false) {
      const bandRows = [
        { Band: 'Band 1 (Quality Pass)', 'Score Range': '>= 80%', 'Pupils Count': targetStats.bandCounts.band1, 'Percentage (%)': `${Math.round((targetStats.bandCounts.band1 / (targetStats.totalMarked || 1)) * 100)}%`, 'Performance Profile': 'Exemplary / Model writing; mature plot development and nuanced vocabulary' },
        { Band: 'Band 2 (Competent)', 'Score Range': '65% - 79%', 'Pupils Count': targetStats.bandCounts.band2, 'Percentage (%)': `${Math.round((targetStats.bandCounts.band2 / (targetStats.totalMarked || 1)) * 100)}%`, 'Performance Profile': 'Good story development, fluent vocabulary, occasional linguistic slips' },
        { Band: 'Band 3 (Pass)', 'Score Range': '50% - 64%', 'Pupils Count': targetStats.bandCounts.band3, 'Percentage (%)': `${Math.round((targetStats.bandCounts.band3 / (targetStats.totalMarked || 1)) * 100)}%`, 'Performance Profile': 'Adequate plot progression, repetitive phrasing, grammatical slips' },
        { Band: 'Band 4 (Pupils-at-Risk)', 'Score Range': '< 50%', 'Pupils Count': targetStats.bandCounts.band4, 'Percentage (%)': `${Math.round((targetStats.bandCounts.band4 / (targetStats.totalMarked || 1)) * 100)}%`, 'Performance Profile': 'Struggling with sentence structure, incomplete story arc, requires remediation' }
      ];
      const wsBands = XLSX.utils.json_to_sheet(bandRows);
      XLSX.utils.book_append_sheet(wb, wsBands, 'Achievement Bands');
      sheetCount++;
    }

    // 5. Qualitative Feedback Tag Taxonomy
    if (sections.tags !== false) {
      const tagRows = [];
      tagRows.push({ Type: '=== WRITING STRENGTHS TAXONOMY ===', Tag: '', 'Pupil Citations': '', 'Prevalence (%)': '' });
      feedbackAnalysis.strengths.forEach(s => {
        tagRows.push({ Type: 'Strength', Tag: s.tag, 'Pupil Citations': s.count, 'Prevalence (%)': `${s.pct}%` });
      });

      tagRows.push({ Type: '', Tag: '', 'Pupil Citations': '', 'Prevalence (%)': '' });
      tagRows.push({ Type: '=== COMMON ERRORS & LEARNING GAPS (SINGAPORE PRIMARY) ===', Tag: '', 'Pupil Citations': '', 'Prevalence (%)': '' });
      feedbackAnalysis.learningGaps.forEach(g => {
        tagRows.push({ Type: 'Learning Gap / Slip', Tag: g.tag, 'Pupil Citations': g.count, 'Prevalence (%)': `${g.pct}%` });
      });

      const wsTags = XLSX.utils.json_to_sheet(tagRows);
      XLSX.utils.book_append_sheet(wb, wsTags, 'Qualitative Feedback');
      sheetCount++;
    }

    // 6. Moderation Audit Log (Initial Mark vs Moderated Mark)
    if (sections.moderation !== false) {
      const moderatedStudents = targetStudents.filter(s => s.moderation && s.moderation.moderated);
      const modRows = moderatedStudents.map(s => {
        const initTotal = s.initialScore ? s.initialScore.total : (s.moderation.originalScore ? s.moderation.originalScore.total : (s.score.total - s.moderation.delta));
        const initContent = s.initialScore ? s.initialScore.content : (s.moderation.originalScore ? s.moderation.originalScore.content : '-');
        const initLang = s.initialScore ? s.initialScore.language : (s.moderation.originalScore ? s.moderation.originalScore.language : '-');

        return {
          'Script ID': s.scriptId,
          'Reg No': s.regNo,
          'Student Name': s.name,
          'Chinese Name (华文姓名)': s.chineseName || '',
          'Form Class': s.formClass,
          'First Marker': s.markerCode || '-',
          'Moderator Code': s.moderation.moderatorCode || (s.moderation.moderatedBy ? (s.moderation.moderatedBy.match(/\(([^)]+)\)/)?.[1] || s.moderation.moderatedBy) : 'HOD'),
          'Moderated By': s.moderation.moderatedBy || 'Moderator',
          'Initial Content (初评内容)': initContent,
          'Initial Language (初评表达)': initLang,
          'Initial Total Mark (初评总分)': initTotal,
          'Moderated Content (定评内容)': s.score ? s.score.content : '',
          'Moderated Language (定评表达)': s.score ? s.score.language : '',
          'Moderated Final Mark (定评总分)': s.score ? s.score.total : '',
          'Score Delta (调整分)': s.moderation.delta > 0 ? `+${s.moderation.delta}` : s.moderation.delta,
          'Moderation Reason': s.moderation.reason || 'HOD Sample Check',
          'Audit Remarks': s.moderation.remarks || s.remark || '-'
        };
      });

      if (modRows.length === 0) {
        modRows.push({
          'Script ID': 'No scripts sample-checked or moderated yet.',
          'Reg No': '',
          'Student Name': '',
          'Chinese Name (华文姓名)': '',
          'Form Class': '',
          'First Marker': '',
          'Moderator Code': '',
          'Moderated By': '',
          'Initial Content (初评内容)': '',
          'Initial Language (初评表达)': '',
          'Initial Total Mark (初评总分)': '',
          'Moderated Content (定评内容)': '',
          'Moderated Language (定评表达)': '',
          'Moderated Final Mark (定评总分)': '',
          'Score Delta (调整分)': '',
          'Moderation Reason': '',
          'Audit Remarks': ''
        });
      }

      const wsMod = XLSX.utils.json_to_sheet(modRows);
      XLSX.utils.book_append_sheet(wb, wsMod, 'Moderation Audit Log');
      sheetCount++;
    }

    // 7. Marker Calibration & Reliability
    if (sections.calibration !== false) {
      const markerReliability = analytics.computeMarkerReliability(students, markers, cohortStats.mean, config);
      const markerData = markerReliability.map(m => ({
        'Marker Code': m.markerCode,
        'Marker Name': m.markerName,
        'Scripts Marked': m.scriptCount,
        'Marker Average (Mean)': m.mean,
        'Marker Std Dev': m.stdDev,
        'Delta from Cohort Mean': m.deltaFromCohort > 0 ? `+${m.deltaFromCohort}` : m.deltaFromCohort,
        'Severity Index': m.calibrationStatus,
        'Sample Checked Count': m.sampleCheckedCount,
        'Avg Moderation Delta': m.avgModerationDelta
      }));
      const wsMarker = XLSX.utils.json_to_sheet(markerData);
      XLSX.utils.book_append_sheet(wb, wsMarker, 'Marker Calibration');
      sheetCount++;
    }

    // Fallback if all sections unchecked
    if (sheetCount === 0) {
      const wsDefault = XLSX.utils.json_to_sheet([{ Notice: 'No sections were selected for export.' }]);
      XLSX.utils.book_append_sheet(wb, wsDefault, 'Notice');
    }

    const titlePrefix = isClassScope
      ? `${this.cleanFilename(scopeOptions.className)}_HOD_Audit`
      : `${this.cleanFilename(config.examTitle)}_HOD_Audit`;
    XLSX.writeFile(wb, `${titlePrefix}_${dateStr}.xlsx`);
  }

  /**
   * Export Department Review or Class Diagnostic Report to Word (.doc)
   */
  exportToWord(students, config, markers, scopeOptions = { scope: 'cohort', reportType: 'hod' }) {
    const dateStr = new Date().toLocaleDateString('en-SG', { year: 'numeric', month: 'long', day: 'numeric' });
    const reportType = scopeOptions.reportType || 'hod';
    const isClassScope = scopeOptions.scope === 'class' && scopeOptions.className;
    const classKey = scopeOptions.classType || 'formClass';
    const targetStudents = isClassScope
      ? students.filter(s => s[classKey] === scopeOptions.className)
      : students;

    const cohortStats = analytics.computeCohortStats(students, config);
    const targetStats = isClassScope ? analytics.computeCohortStats(targetStudents, config) : cohortStats;
    const feedback = analytics.computeClassFeedbackAnalysis(targetStudents, config);
    const deltaMean = Math.round((targetStats.mean - cohortStats.mean) * 10) / 10;

    // =========================================================================
    // OPTION A: CLASS TEACHER DIAGNOSTIC REPORT (.doc)
    // =========================================================================
    if (reportType === 'classTeacher') {
      const classNameDisplay = isClassScope ? scopeOptions.className : 'All Form & Banded Classes';
      const cleanClassName = isClassScope ? this.cleanFilename(scopeOptions.className) : 'Cohort_Class_Summary';

      const docHtml = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
          <meta charset='utf-8'>
          <title>${config.examTitle} - Class Diagnostic Report (${classNameDisplay})</title>
          <style>
            body { font-family: 'Calibri', 'Segoe UI', 'Microsoft YaHei', 'PingFang SC', sans-serif; line-height: 1.5; color: #1e293b; padding: 20px; }
            h1 { color: #0f172a; font-size: 20pt; border-bottom: 2px solid #0284c7; padding-bottom: 6px; margin-bottom: 4px; }
            h2 { color: #0369a1; font-size: 14pt; margin-top: 16pt; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; }
            h3 { color: #334155; font-size: 11pt; margin-top: 10pt; }
            table { width: 100%; border-collapse: collapse; margin-top: 8px; margin-bottom: 12px; font-size: 9.5pt; }
            th { background-color: #f1f5f9; color: #0f172a; border: 1px solid #94a3b8; padding: 6px 8px; text-align: left; font-weight: bold; }
            td { border: 1px solid #cbd5e1; padding: 6px 8px; }
            .summary-card { background-color: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #0284c7; padding: 12px; margin-bottom: 16px; }
            .highlight { font-weight: bold; color: #0f172a; }
            .badge-strength { color: #047857; font-weight: bold; }
            .badge-gap { color: #b91c1c; font-weight: bold; }
            .action-box { background-color: #f0fdf4; border: 1px solid #bbf7d0; border-left: 4px solid #16a34a; padding: 10px 14px; margin: 10px 0; font-size: 9.5pt; }
            .footer { margin-top: 30pt; border-top: 1px solid #cbd5e1; padding-top: 12pt; font-size: 9pt; color: #64748b; }
          </style>
        </head>
        <body>
          <h1>${config.examTitle}</h1>
          <p style="color: #64748b; font-size: 11pt; margin-top: 0;">
            <strong>Class-Level Diagnostic & Form Teacher Post-Exam Report</strong><br/>
            Class: <strong style="color:#0369a1;">${classNameDisplay}</strong> (${isClassScope ? (classKey === 'formClass' ? 'Form Class' : 'Mother Tongue Banded Class') : 'Cohort Summary'}) | 
            Level: ${config.level} | Subject: ${config.subject} | Date: ${dateStr}
          </p>

          <div class="summary-card">
            <strong>Class Key Indicators vs Cohort Benchmark:</strong><br/>
            Class Candidature: <span class="highlight">${targetStats.totalCandidature} pupils</span> | 
            Marked Scripts: <span class="highlight">${targetStats.totalMarked}</span> (${Math.round((targetStats.totalMarked / (targetStats.totalCandidature || 1)) * 100)}%) | 
            Class Mean: <span class="highlight">${targetStats.mean} / ${config.totalMax}</span> 
            (Cohort Diff: <span class="highlight" style="color: ${deltaMean >= 0 ? '#047857' : '#b91c1c'};">${deltaMean >= 0 ? '+' : ''}${deltaMean}</span>) | 
            Class Median: <span class="highlight">${targetStats.median}</span> | 
            Pass Rate: <span class="highlight">${targetStats.passPct}%</span> | 
            Quality Pass (&ge;80%): <span class="highlight">${targetStats.qualityPct}%</span> | 
            Pupils-at-Risk (PAR): <span class="highlight" style="color:#b91c1c;">${targetStats.parCount} (${targetStats.parPct}%)</span>
          </div>

          <h2>1. Class Performance vs Cohort Benchmark</h2>
          <table>
            <tr><th>Metric</th><th>Target Group (${classNameDisplay})</th><th>Cohort Benchmark</th><th>Variance (&Delta;)</th></tr>
            <tr><td>Overall Average (Mean)</td><td><strong>${targetStats.mean}</strong> / ${config.totalMax}</td><td>${cohortStats.mean} / ${config.totalMax}</td><td><strong>${deltaMean >= 0 ? '+' : ''}${deltaMean}</strong></td></tr>
            <tr><td>Content Component Mean</td><td>${targetStats.contentMean} / ${config.contentMax}</td><td>${cohortStats.contentMean} / ${config.contentMax}</td><td>${Math.round((targetStats.contentMean - cohortStats.contentMean) * 10) / 10}</td></tr>
            <tr><td>Language Component Mean</td><td>${targetStats.langMean} / ${config.languageMax}</td><td>${cohortStats.langMean} / ${config.languageMax}</td><td>${Math.round((targetStats.langMean - cohortStats.langMean) * 10) / 10}</td></tr>
            <tr><td>Median Score</td><td>${targetStats.median}</td><td>${cohortStats.median}</td><td>-</td></tr>
            <tr><td>Standard Deviation (Spread)</td><td>${targetStats.stdDev}</td><td>${cohortStats.stdDev}</td><td>-</td></tr>
            <tr><td>Quality Pass Rate (&ge; 80%)</td><td><strong>${targetStats.qualityPct}%</strong> (${targetStats.qualityCount} pupils)</td><td>${cohortStats.qualityPct}%</td><td>${Math.round((targetStats.qualityPct - cohortStats.qualityPct) * 10) / 10}%</td></tr>
            <tr><td>Pass Rate (&ge; 50%)</td><td><strong>${targetStats.passPct}%</strong> (${targetStats.passCount} pupils)</td><td>${cohortStats.passPct}%</td><td>${Math.round((targetStats.passPct - cohortStats.passPct) * 10) / 10}%</td></tr>
            <tr><td>Pupils-at-Risk (PAR &lt; 50%)</td><td><strong style="color:#b91c1c;">${targetStats.parPct}%</strong> (${targetStats.parCount} pupils)</td><td>${cohortStats.parPct}%</td><td>Requires remediation</td></tr>
          </table>

          <h3>1.1 Achievement Band Distribution</h3>
          <table>
            <tr><th>Band</th><th>Score Range</th><th>Description</th><th>Pupils Count</th><th>Class %</th></tr>
            <tr><td>Band 1 (Quality Pass)</td><td>&ge; 80%</td><td>Exemplary / Model writing; mature plot and nuanced vocabulary</td><td><strong>${targetStats.bandCounts.band1}</strong></td><td>${Math.round((targetStats.bandCounts.band1 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
            <tr><td>Band 2 (Competent)</td><td>65% - 79%</td><td>Good story development, fluent vocabulary, occasional slips</td><td><strong>${targetStats.bandCounts.band2}</strong></td><td>${Math.round((targetStats.bandCounts.band2 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
            <tr><td>Band 3 (Pass)</td><td>50% - 64%</td><td>Adequate plot progression, repetitive phrasing, grammatical slips</td><td><strong>${targetStats.bandCounts.band3}</strong></td><td>${Math.round((targetStats.bandCounts.band3 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
            <tr><td>Band 4 (Pupils-at-Risk)</td><td>&lt; 50%</td><td>Struggling with sentence structure, incomplete story arc, requires remediation</td><td><strong style="color:#b91c1c;">${targetStats.bandCounts.band4}</strong></td><td>${Math.round((targetStats.bandCounts.band4 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
          </table>

          <h2>2. Marker Qualitative Feedback & Diagnostic Tag Analysis</h2>
          <p style="font-size: 9.5pt; color: #475569;">
            Summary of authentic Singapore primary composition qualitative criteria tags recorded by the marking team.
          </p>

          <h3>2.1 Key Class Strengths Observed</h3>
          <table>
            <tr><th>Observed Writing Strength</th><th>Pupils Cited</th><th>Prevalence in Class</th><th>Diagnostic Assessment</th></tr>
            ${feedback.strengths.length > 0 ? feedback.strengths.map(s => `
              <tr>
                <td><span class="badge-strength">✔ ${s.tag}</span></td>
                <td>${s.count}</td>
                <td><strong>${s.pct}%</strong></td>
                <td>Demonstrated consistency across class scripts.</td>
              </tr>
            `).join('') : '<tr><td colspan="4" style="color:#64748b; font-style:italic;">No positive feedback tags recorded for this group.</td></tr>'}
          </table>

          <h3>2.2 Common Learning Gaps & Examination Slips</h3>
          <table>
            <tr><th>Identified Learning Gap / Weakness</th><th>Pupils Affected</th><th>Prevalence in Class</th><th>Recommended Focus</th></tr>
            ${feedback.learningGaps.length > 0 ? feedback.learningGaps.map(g => `
              <tr>
                <td><span class="badge-gap">▲ ${g.tag}</span></td>
                <td>${g.count}</td>
                <td><strong style="color:#b91c1c;">${g.pct}%</strong></td>
                <td>Priority target for post-exam classroom teaching.</td>
              </tr>
            `).join('') : '<tr><td colspan="4" style="color:#64748b; font-style:italic;">No prominent writing weaknesses flagged by markers.</td></tr>'}
          </table>

          <h2>3. Pupil Diagnostic Marks & Qualitative Feedback Roster</h2>
          <p style="font-size: 9pt; color: #64748b;">
            Note: Displays official <strong>Final Content, Language, and Total Marks</strong> for all marked pupils. For moderated scripts, the <strong>Initial Mark</strong> and <strong>Score Delta (&Delta;)</strong> are recorded for complete standardisation transparency.
          </p>
          <table>
            <tr>
              <th style="width: 5%;">Reg #</th>
              <th style="width: 17%;">Student Name</th>
              <th style="width: 7%;">Class</th>
              <th style="width: 9%;">Initial Mark</th>
              <th style="width: 8%;">Final Content</th>
              <th style="width: 8%;">Final Language</th>
              <th style="width: 9%;">Final Total</th>
              <th style="width: 6%;">&Delta;</th>
              <th style="width: 18%;">Feedback Tagline</th>
              <th style="width: 13%;">Marker Remarks</th>
            </tr>
            ${targetStudents.map(s => {
              const isMarked = s.score && s.score.total !== null;
              const displayName = s.chineseName ? `${s.name} (${s.chineseName})` : s.name;
              const isModerated = !!(s.moderation && s.moderation.moderated);
              const delta = isModerated ? s.moderation.delta : 0;
              const deltaDisplay = isModerated ? (delta > 0 ? `+${delta}` : (delta < 0 ? `${delta}` : '0')) : '-';

              const initContent = isModerated ? (s.initialScore ? s.initialScore.content : (s.moderation.originalScore ? s.moderation.originalScore.content : '')) : '';
              const initLang = isModerated ? (s.initialScore ? s.initialScore.language : (s.moderation.originalScore ? s.moderation.originalScore.language : '')) : '';
              const initTotal = isModerated ? (s.initialScore ? s.initialScore.total : (s.moderation.originalScore ? s.moderation.originalScore.total : '')) : '';
              const initDisplay = isModerated ? `${initTotal} <span style="font-size:7.5pt; color:#64748b;">(${initContent}C+${initLang}L)</span>` : '-';

              const finalContent = isMarked ? `${s.score.content} / ${config.contentMax}` : '-';
              const finalLang = isMarked ? `${s.score.language} / ${config.languageMax}` : '-';
              const finalTotal = isMarked ? `<strong>${s.score.total}</strong> / ${config.totalMax} <span style="font-size:8pt; color:#64748b;">(${s.score.pct}%)</span>` : '-';

              return `
                <tr>
                  <td>#${s.regNo}</td>
                  <td><strong>${displayName}</strong></td>
                  <td>${s.formClass}</td>
                  <td style="color: #475569;">${initDisplay}</td>
                  <td>${finalContent}</td>
                  <td>${finalLang}</td>
                  <td>${finalTotal}</td>
                  <td style="font-weight: bold; color: ${delta > 0 ? '#047857' : (delta < 0 ? '#b91c1c' : '#64748b')};">${deltaDisplay}</td>
                  <td style="font-size: 8.5pt;">${(s.tags || []).join(', ') || '-'}</td>
                  <td style="font-size: 8.5pt; color: #334155;"><em>${s.remark ? `"${s.remark}"` : '-'}</em></td>
                </tr>
              `;
            }).join('')}
          </table>

          <h2>4. Targeted Pedagogical Action Plan & Interventions</h2>
          <div class="action-box">
            <strong>Recommended Immediate Instructional Next Steps for ${classNameDisplay}:</strong>
            <ul>
              ${feedback.actionPoints.map(ap => `<li style="margin-top: 4px;">${ap}</li>`).join('')}
            </ul>
          </div>
          <p style="font-size: 9.5pt;">
            <strong>PAR Intervention (&lt; 50%):</strong> Form/Subject teacher to conduct 1-on-1 conferencing with identified Band 4 students (${targetStats.parCount} pupils) focusing on simplified story arcs and sentence pattern retention.<br/>
            <strong>Quality Pass Bridging (65% - 79%):</strong> Provide Band 2 students (${targetStats.bandCounts.band2} pupils) with exemplar writing excerpts showcasing emotional depth and tension development.
          </p>

          <div class="footer">
            <table style="border:none; margin-top:30px;">
              <tr style="border:none;">
                <td style="border:none; width:50%;">
                  ___________________________<br/>
                  <strong>Form / Subject Teacher</strong><br/>
                  Class: ${classNameDisplay}<br/>
                  Date: 
                </td>
                <td style="border:none; width:50%;">
                  ___________________________<br/>
                  <strong>Head of Department (HOD)</strong><br/>
                  Mother Tongue / English Language<br/>
                  Date: ${dateStr}
                </td>
              </tr>
            </table>
          </div>
        </body>
        </html>
      `;

      const blob = new Blob(['\ufeff' + docHtml], { type: 'application/msword;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${cleanClassName}_Class_Teacher_Report_${new Date().toISOString().slice(0, 10)}.doc`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return;
    }

    // =========================================================================
    // OPTION B: COMPREHENSIVE HOD POST-EXAM AUDIT REPORT (.doc)
    // =========================================================================
    const sections = scopeOptions.sections || {
      executive: true,
      descriptive: true,
      classComp: true,
      bands: true,
      tags: true,
      moderation: true,
      calibration: true,
      roster: true
    };

    const mtBreakdown = analytics.computeGroupBreakdown(students, 'mtClass', config);
    const formBreakdown = analytics.computeGroupBreakdown(students, 'formClass', config);
    const markerReliability = analytics.computeMarkerReliability(students, markers, cohortStats.mean, config);
    const moderatedStudents = targetStudents.filter(s => s.moderation && s.moderation.moderated);

    let docHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta charset='utf-8'>
        <title>${config.examTitle} - Post-Exam Audit Report</title>
        <style>
          body { font-family: 'Calibri', 'Segoe UI', 'Microsoft YaHei', 'PingFang SC', sans-serif; line-height: 1.5; color: #1e293b; padding: 20px; }
          h1 { color: #0f172a; font-size: 22pt; border-bottom: 2px solid #0284c7; padding-bottom: 6px; margin-bottom: 4px; }
          h2 { color: #0369a1; font-size: 14pt; margin-top: 18pt; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; }
          h3 { color: #334155; font-size: 11pt; margin-top: 12pt; }
          table { width: 100%; border-collapse: collapse; margin-top: 8px; margin-bottom: 14px; font-size: 9.5pt; }
          th { background-color: #f1f5f9; color: #0f172a; border: 1px solid #94a3b8; padding: 6px 8px; text-align: left; font-weight: bold; }
          td { border: 1px solid #cbd5e1; padding: 6px 8px; }
          .summary-card { background-color: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #0284c7; padding: 12px; margin-bottom: 16px; }
          .highlight { font-weight: bold; color: #0f172a; }
          .badge-strength { color: #047857; font-weight: bold; }
          .badge-gap { color: #b91c1c; font-weight: bold; }
          .footer { margin-top: 30pt; border-top: 1px solid #cbd5e1; padding-top: 12pt; font-size: 9pt; color: #64748b; }
        </style>
      </head>
      <body>
        <h1>${config.examTitle}</h1>
        <p style="color: #64748b; font-size: 11pt; margin-top: 0;">
          <strong>Departmental Post-Exam Audit & Review Report</strong><br/>
          Scope: <strong>${isClassScope ? `Class ${scopeOptions.className}` : 'Entire Level Cohort'}</strong> | 
          Level: ${config.level} | Subject: ${config.subject} | Date: ${dateStr}
        </p>
    `;

    // 1. Executive Summary
    if (sections.executive !== false) {
      docHtml += `
        <div class="summary-card">
          <strong>Key Audit Indicators:</strong><br/>
          Candidature: <span class="highlight">${targetStats.totalCandidature} pupils</span> | 
          Marked Scripts: <span class="highlight">${targetStats.totalMarked}</span> (${Math.round((targetStats.totalMarked / (targetStats.totalCandidature || 1)) * 100)}%) | 
          Cohort Mean: <span class="highlight">${targetStats.mean} / ${config.totalMax}</span> | 
          Median: <span class="highlight">${targetStats.median}</span> | 
          Pass Rate: <span class="highlight">${targetStats.passPct}%</span> | 
          Quality Pass (&ge;80%): <span class="highlight">${targetStats.qualityPct}%</span> | 
          Pupils-at-Risk (PAR): <span class="highlight" style="color:#b91c1c;">${targetStats.parCount} (${targetStats.parPct}%)</span>
        </div>
      `;
    }

    // 2. Descriptive Statistics
    if (sections.descriptive !== false) {
      docHtml += `
        <h2>1. Descriptive Statistics & Component Breakdown</h2>
        <table>
          <tr><th>Indicator</th><th>Overall Cohort Value</th><th>Component Benchmark</th></tr>
          <tr><td>Total Maximum Mark</td><td>${config.totalMax} marks</td><td>Content: ${config.contentMax} | Language: ${config.languageMax}</td></tr>
          <tr><td>Mean (Average)</td><td><strong>${targetStats.mean}</strong> (${Math.round((targetStats.mean / config.totalMax) * 100)}%)</td><td>Content Mean: ${targetStats.contentMean} | Language Mean: ${targetStats.langMean}</td></tr>
          <tr><td>Median Score</td><td>${targetStats.median}</td><td>Standard Deviation: ${targetStats.stdDev}</td></tr>
          <tr><td>Score Range (Min - Max)</td><td>${targetStats.min} - ${targetStats.max}</td><td>Spread: ${targetStats.max - targetStats.min} marks</td></tr>
          <tr><td>Pass Rate (&ge; 50%)</td><td><strong>${targetStats.passPct}%</strong> (${targetStats.passCount} pupils)</td><td>Threshold: ${targetStats.passThreshold} marks</td></tr>
          <tr><td>Quality Pass Rate (&ge; 80%)</td><td><strong>${targetStats.qualityPct}%</strong> (${targetStats.qualityCount} pupils)</td><td>Threshold: ${targetStats.qualityThreshold} marks</td></tr>
          <tr><td>Pupils-at-Risk (PAR &lt; 50%)</td><td><strong style="color:#b91c1c;">${targetStats.parPct}%</strong> (${targetStats.parCount} pupils)</td><td>Priority for department post-exam remediation</td></tr>
        </table>
      `;
    }

    // 3. Class Comparison Breakdown
    if (sections.classComp !== false) {
      docHtml += `
        <h2>2. Class Performance Breakdown</h2>
        <h3>2.1 Mother Tongue Classes (Banded)</h3>
        <table>
          <tr><th>MT Class</th><th>Candidature</th><th>Marked</th><th>Class Mean</th><th>Pass Rate (%)</th><th>Quality Pass (%)</th><th>PAR Count</th></tr>
          ${mtBreakdown.map(m => `
            <tr>
              <td><strong>${m.groupName}</strong></td>
              <td>${m.totalCount}</td>
              <td>${m.markedCount}</td>
              <td>${m.mean} / ${config.totalMax}</td>
              <td>${m.passPct}%</td>
              <td>${m.qualityPct}%</td>
              <td>${m.parCount}</td>
            </tr>
          `).join('')}
        </table>

        <h3>2.2 Form Classes</h3>
        <table>
          <tr><th>Form Class</th><th>Candidature</th><th>Marked</th><th>Class Mean</th><th>Pass Rate (%)</th><th>Quality Pass (%)</th><th>PAR Count</th></tr>
          ${formBreakdown.map(f => `
            <tr>
              <td><strong>${f.groupName}</strong></td>
              <td>${f.totalCount}</td>
              <td>${f.markedCount}</td>
              <td>${f.mean} / ${config.totalMax}</td>
              <td>${f.passPct}%</td>
              <td>${f.qualityPct}%</td>
              <td>${f.parCount}</td>
            </tr>
          `).join('')}
        </table>
      `;
    }

    // 4. Achievement Bands
    if (sections.bands !== false) {
      docHtml += `
        <h2>3. Achievement Band Distribution</h2>
        <table>
          <tr><th>Band</th><th>Score Range</th><th>Description</th><th>Pupils Count</th><th>Cohort %</th></tr>
          <tr><td>Band 1 (Quality Pass)</td><td>&ge; 80%</td><td>Exemplary / Model writing; mature plot and nuanced vocabulary</td><td><strong>${targetStats.bandCounts.band1}</strong></td><td>${Math.round((targetStats.bandCounts.band1 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
          <tr><td>Band 2 (Competent)</td><td>65% - 79%</td><td>Good story development, fluent vocabulary, minor slips</td><td><strong>${targetStats.bandCounts.band2}</strong></td><td>${Math.round((targetStats.bandCounts.band2 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
          <tr><td>Band 3 (Pass)</td><td>50% - 64%</td><td>Adequate plot progression, repetitive phrasing, grammatical slips</td><td><strong>${targetStats.bandCounts.band3}</strong></td><td>${Math.round((targetStats.bandCounts.band3 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
          <tr><td>Band 4 (Pupils-at-Risk)</td><td>&lt; 50%</td><td>Struggling with sentence structure, incomplete story arc</td><td><strong style="color:#b91c1c;">${targetStats.bandCounts.band4}</strong></td><td>${Math.round((targetStats.bandCounts.band4 / (targetStats.totalMarked || 1)) * 100)}%</td></tr>
        </table>
      `;
    }

    // 5. Qualitative Feedback Tag Taxonomy
    if (sections.tags !== false) {
      docHtml += `
        <h2>4. Qualitative Feedback & Common Mistakes Analysis</h2>
        <h3>4.1 Cohort Writing Strengths Observed</h3>
        <table>
          <tr><th>Observed Writing Strength</th><th>Pupils Cited</th><th>Prevalence</th></tr>
          ${feedback.strengths.length > 0 ? feedback.strengths.map(s => `
            <tr>
              <td><span class="badge-strength">✔ ${s.tag}</span></td>
              <td>${s.count}</td>
              <td><strong>${s.pct}%</strong></td>
            </tr>
          `).join('') : '<tr><td colspan="3" style="color:#64748b; font-style:italic;">No positive feedback tags recorded yet.</td></tr>'}
        </table>

        <h3>4.2 High-Frequency Writing Weaknesses & Slips (Singapore Primary)</h3>
        <table>
          <tr><th>Common Learning Gap / Error Pattern</th><th>Pupils Affected</th><th>Prevalence</th></tr>
          ${feedback.learningGaps.length > 0 ? feedback.learningGaps.map(g => `
            <tr>
              <td><span class="badge-gap">▲ ${g.tag}</span></td>
              <td>${g.count}</td>
              <td><strong style="color:#b91c1c;">${g.pct}%</strong></td>
            </tr>
          `).join('') : '<tr><td colspan="3" style="color:#64748b; font-style:italic;">No common writing errors flagged.</td></tr>'}
        </table>
      `;
    }

    // 6. Moderation Audit Log
    if (sections.moderation !== false) {
      docHtml += `
        <h2>5. HOD Sample Check & Moderation Audit Log</h2>
        <p style="font-size: 9pt; color: #64748b;">
          This audit log documents all scripts sampled by the HOD for quality assurance, displaying both the <strong>Initial Mark</strong> awarded by the marker and the <strong>Final Moderated Mark</strong> with variance delta.
        </p>
        <table>
          <tr>
            <th style="width: 8%;">Script ID</th>
            <th style="width: 22%;">Student Name</th>
            <th style="width: 10%;">Class</th>
            <th style="width: 10%;">Marker</th>
            <th style="width: 10%;">Initial Mark</th>
            <th style="width: 10%;">Final Mark</th>
            <th style="width: 8%;">&Delta;</th>
            <th style="width: 22%;">Moderation Reason & Remarks</th>
          </tr>
          ${moderatedStudents.length > 0 ? moderatedStudents.map(s => {
            const displayName = s.chineseName ? `${s.name} (${s.chineseName})` : s.name;
            const initTotal = s.initialScore ? s.initialScore.total : (s.moderation.originalScore ? s.moderation.originalScore.total : (s.score.total - s.moderation.delta));
            const delta = s.moderation.delta;
            return `
              <tr>
                <td><strong>${s.scriptId}</strong></td>
                <td>${displayName}</td>
                <td>${s.formClass}</td>
                <td>${s.markerCode || '-'}</td>
                <td>${initTotal}</td>
                <td><strong>${s.score.total}</strong></td>
                <td style="font-weight: bold; color: ${delta > 0 ? '#047857' : (delta < 0 ? '#b91c1c' : '#64748b')};">${delta > 0 ? `+${delta}` : delta}</td>
                <td style="font-size: 8.5pt;">${s.moderation.reason || 'Audit Sample'}${s.moderation.remarks ? ` - <em>"${s.moderation.remarks}"</em>` : ''}</td>
              </tr>
            `;
          }).join('') : '<tr><td colspan="8" style="color:#64748b; font-style:italic;">No scripts moderated in this sample yet.</td></tr>'}
        </table>
      `;
    }

    // 7. Marker Calibration
    if (sections.calibration !== false) {
      docHtml += `
        <h2>6. Marker Calibration & Inter-Rater Reliability</h2>
        <table>
          <tr><th>Marker Code</th><th>Marker Name</th><th>Scripts Marked</th><th>Marker Mean</th><th>Cohort Diff (&Delta;)</th><th>Severity Index</th><th>HOD Sample Checked</th></tr>
          ${markerReliability.map(r => `
            <tr>
              <td><strong>${r.markerCode}</strong></td>
              <td>${r.markerName}</td>
              <td>${r.scriptCount}</td>
              <td>${r.mean}</td>
              <td>${r.deltaFromCohort > 0 ? '+' : ''}${r.deltaFromCohort}</td>
              <td>${r.calibrationStatus}</td>
              <td>${r.sampleCheckedCount} scripts (Avg &Delta;: ${r.avgModerationDelta})</td>
            </tr>
          `).join('')}
        </table>
      `;
    }

    // 8. Consolidated Roster
    if (sections.roster !== false) {
      docHtml += `
        <h2>7. Consolidated Student Marks Roster</h2>
        <table>
          <tr>
            <th style="width: 6%;">Reg #</th>
            <th style="width: 22%;">Student Name</th>
            <th style="width: 8%;">Class</th>
            <th style="width: 8%;">Marker</th>
            <th style="width: 10%;">Initial Mark</th>
            <th style="width: 10%;">Final Mark</th>
            <th style="width: 6%;">&Delta;</th>
            <th style="width: 14%;">Feedback Tags</th>
            <th style="width: 16%;">Marker Remarks</th>
          </tr>
          ${targetStudents.map(s => {
            const isMarked = s.score && s.score.total !== null;
            const displayName = s.chineseName ? `${s.name} (${s.chineseName})` : s.name;
            const initTotal = s.initialScore ? s.initialScore.total : (isMarked ? s.score.total : '-');
            const finalTotal = isMarked ? s.score.total : '-';
            const isModerated = !!(s.moderation && s.moderation.moderated);
            const delta = isModerated ? s.moderation.delta : (isMarked && s.initialScore ? (s.score.total - s.initialScore.total) : 0);
            const deltaDisplay = isMarked ? (delta > 0 ? `+${delta}` : (delta < 0 ? `${delta}` : '-')) : '-';

            return `
              <tr>
                <td>#${s.regNo}</td>
                <td><strong>${displayName}</strong></td>
                <td>${s.formClass}</td>
                <td>${s.markerCode || '-'}</td>
                <td style="color:#475569;">${initTotal}</td>
                <td><strong>${finalTotal}</strong></td>
                <td style="font-weight: bold; color: ${delta > 0 ? '#047857' : (delta < 0 ? '#b91c1c' : '#64748b')};">${deltaDisplay}</td>
                <td style="font-size: 8pt;">${(s.tags || []).join(', ') || '-'}</td>
                <td style="font-size: 8pt; color:#334155;"><em>${s.remark ? `"${s.remark}"` : '-'}</em></td>
              </tr>
            `;
          }).join('')}
        </table>
      `;
    }

    // Department Action Plan & Sign-off Block
    docHtml += `
        <h2>8. Department Quality Review & Action Plan</h2>
        <p>1. <strong>Pupils-at-Risk (PAR) Interventions:</strong> Students scoring below 50% (${targetStats.parCount} pupils) will be enrolled in modular pull-out remediation focusing on narrative structure, pictorial clues, and sentence connector mastery.</p>
        <p>2. <strong>Bridging to Quality Pass:</strong> Competent students in Band 2 (${targetStats.bandCounts.band2} pupils) will be provided with enrichment clinics targeting psychological description, idioms, and tension buildup.</p>
        <p>3. <strong>Marker Reliability Standardisation:</strong> Marking discrepancies identified during sample checking were moderated and calibrated to maintain grading parity across all marking teams.</p>

        <div class="footer">
          <table style="border:none; margin-top:30px;">
            <tr style="border:none;">
              <td style="border:none; width:50%;">
                ___________________________<br/>
                <strong>Prepared by: Teacher Leader / Exam Lead</strong><br/>
                Date: ${dateStr}
              </td>
              <td style="border:none; width:50%;">
                ___________________________<br/>
                <strong>Endorsed by: Head of Department (HOD)</strong><br/>
                Mother Tongue / English Language<br/>
                Date: 
              </td>
            </tr>
          </table>
        </div>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff' + docHtml], { type: 'application/msword;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const cleanTitle = isClassScope
      ? `${this.cleanFilename(scopeOptions.className)}_HOD_Audit_Report`
      : `${this.cleanFilename(config.examTitle)}_HOD_Audit_Report`;
    a.download = `${cleanTitle}_${new Date().toISOString().slice(0, 10)}.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Generate Dedicated Print-Optimized HTML for PDF Printing (Class Teacher or HOD)
   */
  generatePrintableHtml(students, config, markers, scopeOptions = { scope: 'cohort', reportType: 'hod' }) {
    const dateStr = new Date().toLocaleDateString('en-SG', { year: 'numeric', month: 'long', day: 'numeric' });
    const reportType = scopeOptions.reportType || 'hod';
    const isClassScope = scopeOptions.scope === 'class' && scopeOptions.className;
    const classKey = scopeOptions.classType || 'formClass';
    const targetStudents = isClassScope
      ? students.filter(s => s[classKey] === scopeOptions.className)
      : students;

    const cohortStats = analytics.computeCohortStats(students, config);
    const targetStats = isClassScope ? analytics.computeCohortStats(targetStudents, config) : cohortStats;
    const feedback = analytics.computeClassFeedbackAnalysis(targetStudents, config);
    const deltaMean = Math.round((targetStats.mean - cohortStats.mean) * 10) / 10;
    const classNameDisplay = isClassScope ? scopeOptions.className : 'All Form & Banded Classes';

    const commonStyles = `
      @page {
        size: A4 portrait;
        margin: 12mm 10mm;
      }
      @media print {
        .no-print { display: none !important; }
        body { margin: 0; padding: 0; font-size: 8.5pt; color: #0f172a; }
        .page-break { page-break-before: always; }
        table { page-break-inside: auto; }
        tr { page-break-inside: avoid; page-break-after: auto; }
        thead { display: table-header-group; }
        tfoot { display: table-footer-group; }
      }
      body {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Microsoft YaHei', sans-serif;
        line-height: 1.4;
        color: #1e293b;
        background-color: #f8fafc;
        margin: 0;
        padding: 20px;
      }
      .printable-container {
        max-width: 900px;
        margin: 0 auto;
        background: #ffffff;
        padding: 24px 30px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
      }
      @media print {
        .printable-container {
          border: none;
          box-shadow: none;
          padding: 0;
          max-width: 100%;
        }
      }
      .print-action-bar {
        position: sticky;
        top: 0;
        z-index: 50;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #0f172a;
        color: white;
        padding: 10px 20px;
        margin-bottom: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      }
      .btn-print {
        background: #0284c7;
        color: white;
        border: none;
        padding: 8px 16px;
        font-size: 13px;
        font-weight: bold;
        border-radius: 6px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .btn-print:hover { background: #0369a1; }
      .btn-close {
        background: #334155;
        color: white;
        border: none;
        padding: 8px 14px;
        font-size: 13px;
        font-weight: 500;
        border-radius: 6px;
        cursor: pointer;
      }
      .btn-close:hover { background: #475569; }
      h1 { font-size: 17pt; color: #0f172a; margin: 0 0 4px 0; border-bottom: 2px solid #0284c7; padding-bottom: 4px; }
      h2 { font-size: 11pt; color: #0369a1; margin: 14pt 0 4pt 0; border-bottom: 1px solid #cbd5e1; padding-bottom: 2px; page-break-after: avoid; }
      h3 { font-size: 9.5pt; color: #334155; margin: 8pt 0 3pt 0; page-break-after: avoid; }
      table { width: 100%; border-collapse: collapse; margin-top: 4px; margin-bottom: 8px; font-size: 8pt; }
      th, td { border: 1px solid #cbd5e1; padding: 4px 6px; text-align: left; }
      th { background-color: #f1f5f9; color: #0f172a; font-weight: 600; }
      .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin: 10px 0; }
      .kpi-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px 10px; }
      .kpi-label { font-size: 7.5pt; color: #64748b; font-weight: 600; text-transform: uppercase; }
      .kpi-val { font-size: 13pt; font-weight: bold; color: #0f172a; margin-top: 2px; }
      .kpi-sub { font-size: 7.5pt; color: #475569; margin-top: 1px; }
      .badge-pos { color: #047857; font-weight: bold; }
      .badge-neg { color: #b91c1c; font-weight: bold; }
      .badge-tag { display: inline-block; padding: 1px 4px; border-radius: 3px; font-size: 7.5pt; margin: 1px; }
      .badge-strength { background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0; }
      .badge-gap { background: #fff1f2; color: #be123c; border: 1px solid #fecdd3; }
      .footer-sign { margin-top: 25pt; border-top: 1px solid #cbd5e1; padding-top: 10pt; font-size: 8pt; color: #475569; page-break-inside: avoid; }
    `;

    // =========================================================================
    // OPTION A: CLASS TEACHER DIAGNOSTIC PRINTABLE HTML
    // =========================================================================
    if (reportType === 'classTeacher') {
      return `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>${config.examTitle} - Class Diagnostic Report (${classNameDisplay})</title>
          <style>${commonStyles}</style>
        </head>
        <body>
          <div class="print-action-bar no-print">
            <div style="font-size: 13px;">
              <strong>Class Diagnostic Report</strong>: ${classNameDisplay} (${config.level} - ${config.subject})
              <span style="opacity: 0.7; margin-left: 8px;">| Tip: In print destination, select "Save as PDF"</span>
            </div>
            <div style="display: flex; gap: 8px;">
              <button class="btn-print" onclick="window.print()">🖨️ Print / Save as PDF</button>
              <button class="btn-close" onclick="window.close()">✕ Close</button>
            </div>
          </div>

          <div class="printable-container">
            <h1>${config.examTitle}</h1>
            <div style="font-size: 8.5pt; color: #64748b; margin-bottom: 8px;">
              <strong>Class Diagnostic & Pedagogical Post-Exam Report (Form & Subject Teachers)</strong><br/>
              Class: <strong style="color:#0369a1;">${classNameDisplay}</strong> | Level: ${config.level} | Subject: ${config.subject} | Date: ${dateStr}
            </div>

            <!-- Key Indicators Dashboard -->
            <div class="kpi-grid">
              <div class="kpi-card" style="border-left: 3px solid #0284c7;">
                <div class="kpi-label">Class Average (Mean)</div>
                <div class="kpi-val">${targetStats.mean} <span style="font-size:8pt; font-weight:normal; color:#64748b;">/ ${config.totalMax}</span></div>
                <div class="kpi-sub">Cohort Diff: <strong class="${deltaMean >= 0 ? 'badge-pos' : 'badge-neg'}">${deltaMean >= 0 ? '+' : ''}${deltaMean}</strong> (Cohort: ${cohortStats.mean})</div>
              </div>
              <div class="kpi-card" style="border-left: 3px solid #10b981;">
                <div class="kpi-label">Quality Pass (&ge;80%)</div>
                <div class="kpi-val">${targetStats.qualityPct}%</div>
                <div class="kpi-sub">${targetStats.qualityCount} / ${targetStats.totalMarked} pupils (Cohort: ${cohortStats.qualityPct}%)</div>
              </div>
              <div class="kpi-card" style="border-left: 3px solid #3b82f6;">
                <div class="kpi-label">Overall Pass (&ge;50%)</div>
                <div class="kpi-val">${targetStats.passPct}%</div>
                <div class="kpi-sub">${targetStats.passCount} / ${targetStats.totalMarked} pupils (Cohort: ${cohortStats.passPct}%)</div>
              </div>
              <div class="kpi-card" style="border-left: 3px solid #f43f5e;">
                <div class="kpi-label">Pupils-at-Risk (&lt;50%)</div>
                <div class="kpi-val" style="color: #be123c;">${targetStats.parPct}%</div>
                <div class="kpi-sub">${targetStats.parCount} pupils requiring remediation</div>
              </div>
            </div>

            <h2>1. Class Performance vs Cohort Benchmark</h2>
            <table>
              <thead>
                <tr>
                  <th style="width: 32%;">Key Metric / Indicator</th>
                  <th style="width: 24%;">Class Value (${classNameDisplay})</th>
                  <th style="width: 24%;">Cohort Benchmark</th>
                  <th style="width: 20%;">Variance (&Delta;)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Overall Mean Score</td>
                  <td><strong>${targetStats.mean}</strong> / ${config.totalMax}</td>
                  <td>${cohortStats.mean} / ${config.totalMax}</td>
                  <td class="${deltaMean >= 0 ? 'badge-pos' : 'badge-neg'}"><strong>${deltaMean >= 0 ? '+' : ''}${deltaMean}</strong></td>
                </tr>
                <tr>
                  <td>Content Component Mean</td>
                  <td>${targetStats.contentMean} / ${config.contentMax}</td>
                  <td>${cohortStats.contentMean} / ${config.contentMax}</td>
                  <td>${Math.round((targetStats.contentMean - cohortStats.contentMean) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.contentMean - cohortStats.contentMean) * 10) / 10}</td>
                </tr>
                <tr>
                  <td>Language Component Mean</td>
                  <td>${targetStats.langMean} / ${config.languageMax}</td>
                  <td>${cohortStats.langMean} / ${config.languageMax}</td>
                  <td>${Math.round((targetStats.langMean - cohortStats.langMean) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.langMean - cohortStats.langMean) * 10) / 10}</td>
                </tr>
                <tr>
                  <td>Median Score</td>
                  <td>${targetStats.median}</td>
                  <td>${cohortStats.median}</td>
                  <td>${Math.round((targetStats.median - cohortStats.median) * 10) / 10 >= 0 ? '+' : ''}${Math.round((targetStats.median - cohortStats.median) * 10) / 10}</td>
                </tr>
                <tr>
                  <td>Quality Pass Rate (&ge; 80%)</td>
                  <td><strong>${targetStats.qualityPct}%</strong> (${targetStats.qualityCount} pupils)</td>
                  <td>${cohortStats.qualityPct}%</td>
                  <td class="${targetStats.qualityPct >= cohortStats.qualityPct ? 'badge-pos' : 'badge-neg'}">${Math.round((targetStats.qualityPct - cohortStats.qualityPct) * 10) / 10}%</td>
                </tr>
                <tr>
                  <td>Overall Pass Rate (&ge; 50%)</td>
                  <td><strong>${targetStats.passPct}%</strong> (${targetStats.passCount} pupils)</td>
                  <td>${cohortStats.passPct}%</td>
                  <td class="${targetStats.passPct >= cohortStats.passPct ? 'badge-pos' : 'badge-neg'}">${Math.round((targetStats.passPct - cohortStats.passPct) * 10) / 10}%</td>
                </tr>
                <tr>
                  <td>Pupils-at-Risk (PAR &lt; 50%)</td>
                  <td><strong style="color:#b91c1c;">${targetStats.parPct}%</strong> (${targetStats.parCount} pupils)</td>
                  <td>${cohortStats.parPct}%</td>
                  <td>Requires targeted support</td>
                </tr>
              </tbody>
            </table>

            <h2>2. Achievement Band Distribution</h2>
            <table>
              <thead>
                <tr>
                  <th>Band</th>
                  <th>Score Range</th>
                  <th>Descriptor</th>
                  <th style="text-align:center;">Class Count</th>
                  <th style="text-align:center;">Class %</th>
                  <th style="text-align:center;">Cohort %</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>Band 1</strong></td>
                  <td>&ge; 80%</td>
                  <td>Exemplary composition; insightful ideas and rich vocabulary</td>
                  <td style="text-align:center;">${targetStats.bandCounts.band1}</td>
                  <td style="text-align:center;"><strong>${Math.round((targetStats.bandCounts.band1 / (targetStats.totalMarked || 1)) * 100)}%</strong></td>
                  <td style="text-align:center;">${Math.round((cohortStats.bandCounts.band1 / (cohortStats.totalMarked || 1)) * 100)}%</td>
                </tr>
                <tr>
                  <td><strong>Band 2</strong></td>
                  <td>65% - 79%</td>
                  <td>Competent; coherent storyline, minor expression slips</td>
                  <td style="text-align:center;">${targetStats.bandCounts.band2}</td>
                  <td style="text-align:center;"><strong>${Math.round((targetStats.bandCounts.band2 / (targetStats.totalMarked || 1)) * 100)}%</strong></td>
                  <td style="text-align:center;">${Math.round((cohortStats.bandCounts.band2 / (cohortStats.totalMarked || 1)) * 100)}%</td>
                </tr>
                <tr>
                  <td><strong>Band 3</strong></td>
                  <td>50% - 64%</td>
                  <td>Pass; basic plot progression, repetitive phrasing, punctuation slips</td>
                  <td style="text-align:center;">${targetStats.bandCounts.band3}</td>
                  <td style="text-align:center;"><strong>${Math.round((targetStats.bandCounts.band3 / (targetStats.totalMarked || 1)) * 100)}%</strong></td>
                  <td style="text-align:center;">${Math.round((cohortStats.bandCounts.band3 / (cohortStats.totalMarked || 1)) * 100)}%</td>
                </tr>
                <tr>
                  <td><strong>Band 4</strong></td>
                  <td>&lt; 50%</td>
                  <td>Struggling; incomplete narrative arc, sentence syntax issues (PAR)</td>
                  <td style="text-align:center; color:#b91c1c;"><strong>${targetStats.bandCounts.band4}</strong></td>
                  <td style="text-align:center; color:#b91c1c;"><strong>${Math.round((targetStats.bandCounts.band4 / (targetStats.totalMarked || 1)) * 100)}%</strong></td>
                  <td style="text-align:center;">${Math.round((cohortStats.bandCounts.band4 / (cohortStats.totalMarked || 1)) * 100)}%</td>
                </tr>
              </tbody>
            </table>

            <h2>3. Qualitative Diagnostic Analysis (Strengths vs Gaps)</h2>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
              <div>
                <h3>🟢 Observed Class Strengths</h3>
                <table>
                  <thead>
                    <tr><th>Strengths Descriptor</th><th style="text-align:center; width:22%;">Prevalence</th></tr>
                  </thead>
                  <tbody>
                    ${feedback.strengths.slice(0, 5).map(s => `
                      <tr>
                        <td><span class="badge-tag badge-strength">✔ ${s.tag}</span></td>
                        <td style="text-align:center;"><strong>${s.pct}%</strong> (${s.count})</td>
                      </tr>
                    `).join('') || '<tr><td colspan="2" style="color:#64748b; font-style:italic;">None recorded</td></tr>'}
                  </tbody>
                </table>
              </div>
              <div>
                <h3>🔴 Common Learning Gaps & Slips</h3>
                <table>
                  <thead>
                    <tr><th>Learning Gap Descriptor</th><th style="text-align:center; width:22%;">Prevalence</th></tr>
                  </thead>
                  <tbody>
                    ${feedback.learningGaps.slice(0, 5).map(g => `
                      <tr>
                        <td><span class="badge-tag badge-gap">▲ ${g.tag}</span></td>
                        <td style="text-align:center; color:#b91c1c;"><strong>${g.pct}%</strong> (${g.count})</td>
                      </tr>
                    `).join('') || '<tr><td colspan="2" style="color:#64748b; font-style:italic;">None recorded</td></tr>'}
                  </tbody>
                </table>
              </div>
            </div>

            <h2>4. Pupil Diagnostic Marks & Qualitative Feedback Roster</h2>
            <p style="font-size: 7.5pt; color: #64748b; margin-top: 1px; margin-bottom: 4px;">
              Official record displaying Final Content, Language, and Total marks for all marked pupils (with Initial marks and score adjustments for moderated scripts).
            </p>
            <table>
              <thead>
                <tr>
                  <th style="width: 4%;">Reg</th>
                  <th style="width: 18%;">Student Name</th>
                  <th style="width: 7%;">Class</th>
                  <th style="width: 9%;">Initial Mark</th>
                  <th style="width: 7%; text-align:center;">Content</th>
                  <th style="width: 7%; text-align:center;">Language</th>
                  <th style="width: 8%; text-align:center;">Final Total</th>
                  <th style="width: 5%; text-align:center;">&Delta;</th>
                  <th style="width: 22%;">Feedback Tagline</th>
                  <th style="width: 13%;">Marker Remarks</th>
                </tr>
              </thead>
              <tbody>
                ${targetStudents.map(s => {
                  const isMarked = s.score && s.score.total !== null;
                  const displayName = s.chineseName ? `${s.name} (${s.chineseName})` : s.name;
                  const isModerated = !!(s.moderation && s.moderation.moderated);
                  const delta = isModerated ? s.moderation.delta : 0;
                  const deltaDisplay = isModerated ? (delta > 0 ? `+${delta}` : (delta < 0 ? `${delta}` : '0')) : '-';

                  const initContent = isModerated ? (s.initialScore ? s.initialScore.content : (s.moderation.originalScore ? s.moderation.originalScore.content : '')) : '';
                  const initLang = isModerated ? (s.initialScore ? s.initialScore.language : (s.moderation.originalScore ? s.moderation.originalScore.language : '')) : '';
                  const initTotal = isModerated ? (s.initialScore ? s.initialScore.total : (s.moderation.originalScore ? s.moderation.originalScore.total : '')) : '';
                  const initDisplay = isModerated ? `${initTotal} <span style="font-size:7pt; color:#64748b;">(${initContent}+${initLang})</span>` : '-';

                  const finalContent = isMarked ? `${s.score.content}` : '-';
                  const finalLang = isMarked ? `${s.score.language}` : '-';
                  const finalTotal = isMarked ? `<strong>${s.score.total}</strong> <span style="font-size:7pt; color:#64748b;">(${s.score.pct}%)</span>` : '-';

                  return `
                    <tr>
                      <td>#${s.regNo}</td>
                      <td><strong>${displayName}</strong></td>
                      <td>${s.formClass}</td>
                      <td style="color: #475569;">${initDisplay}</td>
                      <td style="text-align:center;">${finalContent}</td>
                      <td style="text-align:center;">${finalLang}</td>
                      <td style="text-align:center;">${finalTotal}</td>
                      <td style="text-align:center; font-weight: bold; color: ${delta > 0 ? '#047857' : (delta < 0 ? '#b91c1c' : '#64748b')};">${deltaDisplay}</td>
                      <td style="font-size: 7.5pt;">${(s.tags || []).join('; ') || '-'}</td>
                      <td style="font-size: 7.5pt; color: #334155;"><em>${s.remark ? `"${s.remark}"` : '-'}</em></td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>

            <h2>5. Targeted Pedagogical Action Plan</h2>
            <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-left:3px solid #16a34a; padding:6px 10px; font-size:8pt; margin:6px 0;">
              <strong>Immediate Classroom Next Steps for ${classNameDisplay}:</strong>
              <ul style="margin: 3px 0 0 16px; padding: 0;">
                ${feedback.actionPoints.map(ap => `<li>${ap}</li>`).join('')}
              </ul>
            </div>

            <div class="footer-sign">
              <table style="border:none; margin-top:14px; font-size:8pt;">
                <tr style="border:none;">
                  <td style="border:none; width:50%;">
                    ___________________________<br/>
                    <strong>Form / Subject Teacher</strong><br/>
                    Class: ${classNameDisplay}<br/>
                    Date: 
                  </td>
                  <td style="border:none; width:50%;">
                    ___________________________<br/>
                    <strong>Head of Department (HOD)</strong><br/>
                    Mother Tongue / English Language<br/>
                    Date: ${dateStr}
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </body>
        </html>
      `;
    }

    // =========================================================================
    // OPTION B: COMPREHENSIVE HOD POST-EXAM AUDIT REPORT PRINTABLE HTML
    // =========================================================================
    const mtBreakdown = analytics.computeGroupBreakdown(students, 'mtClass', config);
    const formBreakdown = analytics.computeGroupBreakdown(students, 'formClass', config);
    const markerReliability = analytics.computeMarkerReliability(students, markers, cohortStats.mean, config);
    const moderatedStudents = targetStudents.filter(s => s.moderation && s.moderation.moderated);

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>${config.examTitle} - Comprehensive HOD Post-Exam Audit Report</title>
        <style>${commonStyles}</style>
      </head>
      <body>
        <div class="print-action-bar no-print">
          <div style="font-size: 13px;">
            <strong>Comprehensive HOD Post-Exam Audit Report</strong>: ${config.examTitle} (${config.level} - ${config.subject})
            <span style="opacity: 0.7; margin-left: 8px;">| Tip: In print destination, select "Save as PDF"</span>
          </div>
          <div style="display: flex; gap: 8px;">
            <button class="btn-print" onclick="window.print()">🖨️ Print / Save as PDF</button>
            <button class="btn-close" onclick="window.close()">✕ Close</button>
          </div>
        </div>

        <div class="printable-container">
          <h1>${config.examTitle}</h1>
          <div style="font-size: 8.5pt; color: #64748b; margin-bottom: 8px;">
            <strong>Comprehensive Head of Department Post-Exam Audit & Review Report</strong><br/>
            Level: ${config.level} | Subject: ${config.subject} | Marking Rubric Max: ${config.totalMax} pts (Content: ${config.contentMax}, Lang: ${config.languageMax}) | Date: ${dateStr}
          </div>

          <!-- Cohort Key Metrics Dashboard -->
          <div class="kpi-grid">
            <div class="kpi-card" style="border-left: 3px solid #0284c7;">
              <div class="kpi-label">Cohort Average (Mean)</div>
              <div class="kpi-val">${cohortStats.mean} <span style="font-size:8pt; font-weight:normal; color:#64748b;">/ ${config.totalMax}</span></div>
              <div class="kpi-sub">Content: ${cohortStats.contentMean} | Lang: ${cohortStats.langMean}</div>
            </div>
            <div class="kpi-card" style="border-left: 3px solid #10b981;">
              <div class="kpi-label">Quality Pass Rate (&ge;80%)</div>
              <div class="kpi-val">${cohortStats.qualityPct}%</div>
              <div class="kpi-sub">${cohortStats.qualityCount} of ${cohortStats.totalMarked} marked candidates</div>
            </div>
            <div class="kpi-card" style="border-left: 3px solid #3b82f6;">
              <div class="kpi-label">Overall Pass Rate (&ge;50%)</div>
              <div class="kpi-val">${cohortStats.passPct}%</div>
              <div class="kpi-sub">${cohortStats.passCount} of ${cohortStats.totalMarked} candidates</div>
            </div>
            <div class="kpi-card" style="border-left: 3px solid #f43f5e;">
              <div class="kpi-label">Pupils-at-Risk (&lt;50%)</div>
              <div class="kpi-val" style="color:#be123c;">${cohortStats.parPct}%</div>
              <div class="kpi-sub">${cohortStats.parCount} pupils across cohort</div>
            </div>
          </div>

          <h2>1. Executive Cohort Statistics & Item Analysis</h2>
          <table>
            <thead>
              <tr><th>Statistical Metric</th><th>Cohort Value</th><th>Diagnostic Evaluation</th></tr>
            </thead>
            <tbody>
              <tr><td>Total Candidature</td><td><strong>${cohortStats.totalCandidature}</strong> pupils</td><td>Total registered cohort size</td></tr>
              <tr><td>Completed Marked Scripts</td><td><strong>${cohortStats.totalMarked}</strong> (${Math.round((cohortStats.totalMarked / (cohortStats.totalCandidature || 1)) * 100)}%)</td><td>Marking completion progress</td></tr>
              <tr><td>Median Score</td><td><strong>${cohortStats.median}</strong> / ${config.totalMax}</td><td>Midpoint score of cohort distribution</td></tr>
              <tr><td>Standard Deviation (Spread)</td><td><strong>${cohortStats.stdDev}</strong></td><td>Measurement of student score dispersion</td></tr>
              <tr><td>Score Range (Minimum - Maximum)</td><td>${cohortStats.min} - ${cohortStats.max}</td><td>Extreme score span across cohort</td></tr>
            </tbody>
          </table>

          <h2>2. Form Class Comparative Breakdown</h2>
          <table>
            <thead>
              <tr>
                <th>Form Class</th>
                <th style="text-align:center;">Marked</th>
                <th style="text-align:center;">Class Mean</th>
                <th style="text-align:center;">Content</th>
                <th style="text-align:center;">Lang</th>
                <th style="text-align:center;">Pass %</th>
                <th style="text-align:center;">Quality %</th>
                <th style="text-align:center;">PAR Count</th>
              </tr>
            </thead>
            <tbody>
              ${formBreakdown.map(c => `
                <tr>
                  <td><strong>${c.groupName}</strong></td>
                  <td style="text-align:center;">${c.marked} / ${c.total}</td>
                  <td style="text-align:center;"><strong>${c.mean}</strong></td>
                  <td style="text-align:center;">${c.contentMean}</td>
                  <td style="text-align:center;">${c.langMean}</td>
                  <td style="text-align:center;">${c.passPct}%</td>
                  <td style="text-align:center;">${c.qualityPct}%</td>
                  <td style="text-align:center; color:${c.parCount > 0 ? '#b91c1c' : 'inherit'};">${c.parCount}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <h2>3. Mother Tongue Banded Class Comparative Breakdown</h2>
          <table>
            <thead>
              <tr>
                <th>MT Banded Class</th>
                <th style="text-align:center;">Marked</th>
                <th style="text-align:center;">Class Mean</th>
                <th style="text-align:center;">Content</th>
                <th style="text-align:center;">Lang</th>
                <th style="text-align:center;">Pass %</th>
                <th style="text-align:center;">Quality %</th>
                <th style="text-align:center;">PAR Count</th>
              </tr>
            </thead>
            <tbody>
              ${mtBreakdown.map(c => `
                <tr>
                  <td><strong>${c.groupName}</strong></td>
                  <td style="text-align:center;">${c.marked} / ${c.total}</td>
                  <td style="text-align:center;"><strong>${c.mean}</strong></td>
                  <td style="text-align:center;">${c.contentMean}</td>
                  <td style="text-align:center;">${c.langMean}</td>
                  <td style="text-align:center;">${c.passPct}%</td>
                  <td style="text-align:center;">${c.qualityPct}%</td>
                  <td style="text-align:center; color:${c.parCount > 0 ? '#b91c1c' : 'inherit'};">${c.parCount}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <h2>4. Marker Calibration & Inter-Rater Reliability</h2>
          <table>
            <thead>
              <tr>
                <th>Marker Code</th>
                <th>Marker Name</th>
                <th style="text-align:center;">Scripts Marked</th>
                <th style="text-align:center;">Marker Mean</th>
                <th style="text-align:center;">Cohort Diff (&Delta;)</th>
                <th style="text-align:center;">Severity Index</th>
                <th style="text-align:center;">Sample Checked</th>
              </tr>
            </thead>
            <tbody>
              ${markerReliability.map(r => `
                <tr>
                  <td><strong>${r.markerCode}</strong></td>
                  <td>${r.markerName}</td>
                  <td style="text-align:center;">${r.scriptCount}</td>
                  <td style="text-align:center;"><strong>${r.mean}</strong></td>
                  <td style="text-align:center; font-weight:bold; color:${r.deltaFromCohort > 0 ? '#047857' : (r.deltaFromCohort < 0 ? '#b91c1c' : 'inherit')};">${r.deltaFromCohort > 0 ? '+' : ''}${r.deltaFromCohort}</td>
                  <td style="text-align:center;">${r.calibrationStatus}</td>
                  <td style="text-align:center;">${r.sampleCheckedCount} scripts</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <h2>5. Moderation Audit Trail (Sample-Checked Scripts)</h2>
          <table>
            <thead>
              <tr>
                <th>Script ID</th>
                <th>Pupil Name</th>
                <th>Class</th>
                <th style="text-align:center;">Marker</th>
                <th style="text-align:center;">Moderator</th>
                <th style="text-align:center;">Initial</th>
                <th style="text-align:center;">Final</th>
                <th style="text-align:center;">&Delta;</th>
                <th>Moderation Reason & Remarks</th>
              </tr>
            </thead>
            <tbody>
              ${moderatedStudents.length > 0 ? moderatedStudents.map(s => {
                const displayName = s.chineseName ? `${s.name} (${s.chineseName})` : s.name;
                const orig = s.initialScore || (s.moderation && s.moderation.originalScore);
                const delta = s.moderation.delta;
                return `
                  <tr>
                    <td><strong>${s.scriptId}</strong></td>
                    <td>${displayName}</td>
                    <td>${s.formClass}</td>
                    <td style="text-align:center;">${s.markerCode || '-'}</td>
                    <td style="text-align:center;">${s.moderation.moderatorCode || 'MOD'}</td>
                    <td style="text-align:center;">${orig ? orig.total : '-'}</td>
                    <td style="text-align:center;"><strong>${s.score.total}</strong></td>
                    <td style="text-align:center; font-weight:bold; color:${delta > 0 ? '#047857' : (delta < 0 ? '#b91c1c' : '#64748b')};">${delta > 0 ? `+${delta}` : delta}</td>
                    <td style="font-size:7.5pt;">${s.moderation.reason || 'Audit Sample'}${s.moderation.remarks ? ` - <em>"${s.moderation.remarks}"</em>` : ''}</td>
                  </tr>
                `;
              }).join('') : '<tr><td colspan="9" style="text-align:center; color:#64748b; font-style:italic;">No scripts moderated in this sample yet.</td></tr>'}
            </tbody>
          </table>

          <h2>6. Department Quality Review & Action Plan</h2>
          <div style="font-size: 8pt; color:#334155; line-height: 1.4;">
            <p>1. <strong>Pupils-at-Risk (PAR) Interventions:</strong> Students scoring below 50% (${cohortStats.parCount} pupils) will be enrolled in targeted modular pull-out remediation focusing on pictorial clue sequencing and basic sentence patterns.</p>
            <p>2. <strong>Bridging to Quality Pass:</strong> Competent students in Band 2 (${cohortStats.bandCounts.band2} pupils) will be provided with exemplar writing excerpts showcasing psychological description, idioms, and tension buildup.</p>
            <p>3. <strong>Marker Reliability Standardisation:</strong> Marking discrepancies identified during sample checking were moderated and calibrated to maintain grading parity across all marking teams.</p>
          </div>

          <div class="footer-sign">
            <table style="border:none; margin-top:20px; font-size:8pt;">
              <tr style="border:none;">
                <td style="border:none; width:50%;">
                  ___________________________<br/>
                  <strong>Prepared by: Teacher Leader / Exam Lead</strong><br/>
                  Date: ${dateStr}
                </td>
                <td style="border:none; width:50%;">
                  ___________________________<br/>
                  <strong>Endorsed by: Head of Department (HOD)</strong><br/>
                  Mother Tongue / English Language<br/>
                  Date: 
                </td>
              </tr>
            </table>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Trigger Formatted PDF / Print Dialog via Dedicated Window / Iframe
   */
  printPdfReport(scopeOptions = { scope: 'cohort', reportType: 'hod' }) {
    const state = db.getState();
    const htmlContent = this.generatePrintableHtml(state.students, state.config, state.markers, scopeOptions);

    // Attempt opening a dedicated print window
    const printWin = window.open('', '_blank', 'width=1000,height=800,menubar=no,toolbar=no,location=no,status=no');
    if (printWin) {
      printWin.document.open();
      printWin.document.write(htmlContent);
      printWin.document.close();
      printWin.focus();
      setTimeout(() => {
        printWin.print();
      }, 500);
    } else {
      // Fallback: If popup blocker intercepts, use hidden iframe to trigger print
      let iframe = document.getElementById('secsPrintIframe');
      if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.id = 'secsPrintIframe';
        iframe.style.position = 'fixed';
        iframe.style.right = '0';
        iframe.style.bottom = '0';
        iframe.style.width = '0';
        iframe.style.height = '0';
        iframe.style.border = '0';
        document.body.appendChild(iframe);
      }
      const doc = iframe.contentWindow.document;
      doc.open();
      doc.write(htmlContent);
      doc.close();
      iframe.contentWindow.focus();
      setTimeout(() => {
        iframe.contentWindow.print();
      }, 500);
    }
  }

  /**
   * Share Summary to Email / Clipboard (Supports Cohort or Class Scope)
   */
  shareSummary(students, config, scopeOptions = { scope: 'cohort', reportType: 'hod' }) {
    if (scopeOptions.scope === 'class' && scopeOptions.className) {
      const classKey = scopeOptions.classType || 'formClass';
      const targetStudents = students.filter(s => s[classKey] === scopeOptions.className);
      const classStats = analytics.computeCohortStats(targetStudents, config);
      const cohortStats = analytics.computeCohortStats(students, config);
      const feedback = analytics.computeClassFeedbackAnalysis(targetStudents, config);
      const deltaMean = Math.round((classStats.mean - cohortStats.mean) * 10) / 10;

      const topStrength = feedback.strengths[0] ? `${feedback.strengths[0].tag} (${feedback.strengths[0].pct}%)` : 'Consistent writing';
      const topGap = feedback.learningGaps[0] ? `${feedback.learningGaps[0].tag} (${feedback.learningGaps[0].pct}%)` : 'None prominent';

      const subject = encodeURIComponent(`[SECS Class Summary] ${scopeOptions.className} - ${config.examTitle}`);
      const bodyText = 
`Dear Colleague,

Here is the Paper 1 examination diagnostic summary for class ${scopeOptions.className}:

=== CLASS SUMMARY: ${scopeOptions.className} ===
Examination: ${config.examTitle}
Class Candidature: ${classStats.totalCandidature} pupils
Marked Scripts: ${classStats.totalMarked} / ${classStats.totalCandidature} (${Math.round((classStats.totalMarked / (classStats.totalCandidature || 1)) * 100)}%)
Class Mean: ${classStats.mean} / ${config.totalMax} (Cohort Diff: ${deltaMean >= 0 ? '+' : ''}${deltaMean})
Median Score: ${classStats.median}
Quality Pass Rate (>= 80%): ${classStats.qualityPct}% (${classStats.qualityCount} pupils)
Pass Rate (>= 50%): ${classStats.passPct}% (${classStats.passCount} pupils)
Pupils-at-Risk (PAR < 50%): ${classStats.parPct}% (${classStats.parCount} pupils)

=== QUALITATIVE FEEDBACK HIGHLIGHTS ===
Top Class Strength: ${topStrength}
Key Area for Growth: ${topGap}

Note: Both Initial Marks and Final Moderated Marks are recorded in SECS.
Full Class Diagnostic Report (.doc) and Student Marks Roster (.xlsx) with detailed marker comments are available for download.

Best regards,
Head of Department / Teacher Leader
`;

      const mailtoUrl = `mailto:?subject=${subject}&body=${encodeURIComponent(bodyText)}`;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(bodyText).then(() => {
          alert(`Class summary for ${scopeOptions.className} copied to clipboard!\nOpening email client...`);
          window.location.href = mailtoUrl;
        }).catch(() => {
          window.location.href = mailtoUrl;
        });
      } else {
        window.location.href = mailtoUrl;
      }

    } else {
      // Cohort summary
      const stats = analytics.computeCohortStats(students, config);
      const subject = encodeURIComponent(`[SECS Exam Summary] ${config.examTitle}`);
      const bodyText = 
`Dear HOD and Department Colleagues,

Here is the consolidated marking and item analysis summary for ${config.examTitle}:

=== EXAMINATION SUMMARY ===
Level & Subject: ${config.level} - ${config.subject}
Total Candidature: ${stats.totalCandidature}
Scripts Marked: ${stats.totalMarked} / ${stats.totalCandidature} (${Math.round((stats.totalMarked / (stats.totalCandidature || 1)) * 100)}%)
Cohort Mean: ${stats.mean} / ${config.totalMax} (Content: ${stats.contentMean}, Language: ${stats.langMean})
Median Score: ${stats.median}
Standard Deviation: ${stats.stdDev}
Pass Rate (>= 50%): ${stats.passPct}% (${stats.passCount} students)
Quality Pass Rate (>= 80%): ${stats.qualityPct}% (${stats.qualityCount} students)
Pupils-at-Risk (PAR < 50%): ${stats.parPct}% (${stats.parCount} students)

Dual mark tracking (Initial vs Moderated marks), Marker Calibration, and Qualitative Feedback Reports are ready for download in Excel and Word format via the SECS local portal.

Best regards,
Exam Control System
`;

      const mailtoUrl = `mailto:?subject=${subject}&body=${encodeURIComponent(bodyText)}`;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(bodyText).then(() => {
          alert('Executive summary report copied to clipboard!\nOpening your email application...');
          window.location.href = mailtoUrl;
        }).catch(() => {
          window.location.href = mailtoUrl;
        });
      } else {
        window.location.href = mailtoUrl;
      }
    }
  }

  /**
   * Export Full Database JSON File
   */
  downloadDatabaseJSON() {
    const jsonStr = db.exportJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SECS_Exam_Database_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

const exporter = new ExportService();
window.exporter = exporter;
