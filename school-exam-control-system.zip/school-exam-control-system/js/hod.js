/**
 * SECS - Head of Department (HOD) Admin Hub & Moderation Engine
 */

class HodController {
  constructor() {
    this.activeTab = 'tabExamStudio';
    this.formClassFilter = 'ALL';
    this.mtClassFilter = 'ALL';
    this.markerFilter = 'ALL';
    this.bandFilter = 'ALL';
    this.sortBy = 'totalDesc';
    this.searchQuery = '';
    this.moderatingStudentId = null;
    this.sampleCheckFilter = 'all'; // 'all' | 'borderlinePass' | 'borderlineQuality' | 'outliers' | 'random10'
    this.exportScope = 'cohort'; // 'cohort' | 'class'
    this.exportSelectedClass = '';
    this.exportSelectedClassType = 'formClass';
  }

  init() {
    try {
      const savedTab = sessionStorage.getItem('SECS_HOD_ACTIVE_TAB');
      if (savedTab && ['tabExamStudio', 'tabRegisterPaper', 'tabConsolidation', 'tabModeration', 'tabAnalytics', 'tabSettings', 'tabExport'].includes(savedTab)) {
        this.activeTab = savedTab;
      }
    } catch (e) {}
    this.renderExamSelector();
    this.initAutoSaveBeacon();
    this.bindEvents();
    this.renderLockControls();
    this.renderExecutivePaperDeck();
    this.switchTab(this.activeTab);
    this.populateFilterDropdowns();
  }

  bindEvents() {
    // Exam Selector
    const examSelect = document.getElementById('globalExamSelect');
    if (examSelect) {
      examSelect.addEventListener('change', (e) => this.handleExamSwitch(e.target.value));
    }

    // Manage Exams Modal triggers
    const manageExamsBtn = document.getElementById('btnOpenManageExams');
    if (manageExamsBtn) {
      manageExamsBtn.addEventListener('click', () => this.openManageExamsModal());
    }

    const closeManageExamsBtn = document.getElementById('btnCloseManageExamsModal');
    if (closeManageExamsBtn) {
      closeManageExamsBtn.addEventListener('click', () => this.closeManageExamsModal());
    }

    const createExamForm = document.getElementById('createNewExamForm');
    if (createExamForm) {
      createExamForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.submitCreateNewExam();
      });
    }

    // Logout Confirmation Modal triggers
    const cancelLogoutBtn = document.getElementById('btnLogoutCancel');
    if (cancelLogoutBtn) {
      cancelLogoutBtn.addEventListener('click', () => this.closeLogoutConfirmModal());
    }

    const confirmLogoutBtn = document.getElementById('btnLogoutConfirm');
    if (confirmLogoutBtn) {
      confirmLogoutBtn.addEventListener('click', () => this.confirmLogout());
    }

    const downloadExitBackupBtn = document.getElementById('btnDownloadExitBackup');
    if (downloadExitBackupBtn) {
      downloadExitBackupBtn.addEventListener('click', () => {
        if (typeof exporter !== 'undefined' && exporter.downloadDatabaseJSON) {
          exporter.downloadDatabaseJSON();
        }
      });
    }

    // Navigation tabs
    const navButtons = document.querySelectorAll('.hod-nav-btn');
    navButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetTab = btn.getAttribute('data-tab');
        this.switchTab(targetTab);
      });
    });

    // Search input
    const search = document.getElementById('hodSearchInput');
    if (search) {
      search.addEventListener('input', (e) => {
        this.searchQuery = e.target.value.toLowerCase().trim();
        this.renderConsolidationTable();
      });
    }

    // Filter dropdowns
    const formSelect = document.getElementById('hodFormClassFilter');
    const mtSelect = document.getElementById('hodMtClassFilter');
    const markerSelect = document.getElementById('hodMarkerFilter');
    const bandSelect = document.getElementById('hodBandFilter');
    const sortSelect = document.getElementById('hodSortBySelect');

    if (formSelect) formSelect.addEventListener('change', (e) => { this.formClassFilter = e.target.value; this.renderConsolidationTable(); });
    if (mtSelect) mtSelect.addEventListener('change', (e) => { this.mtClassFilter = e.target.value; this.renderConsolidationTable(); });
    if (markerSelect) markerSelect.addEventListener('change', (e) => { this.markerFilter = e.target.value; this.renderConsolidationTable(); });
    if (bandSelect) bandSelect.addEventListener('change', (e) => { this.bandFilter = e.target.value; this.renderConsolidationTable(); });
    if (sortSelect) sortSelect.addEventListener('change', (e) => { this.sortBy = e.target.value; this.renderConsolidationTable(); });

    // Moderation Inputs listener for real-time Delta
    const modContent = document.getElementById('modHODContentInput');
    const modLang = document.getElementById('modHODLangInput');
    if (modContent && modLang) {
      modContent.addEventListener('input', () => this.handleModerationScoreChange());
      modLang.addEventListener('input', () => this.handleModerationScoreChange());
    }

    // Moderation smart filter pills
    const samplePills = document.querySelectorAll('.sample-filter-pill');
    samplePills.forEach(pill => {
      pill.addEventListener('click', () => {
        samplePills.forEach(p => p.classList.remove('bg-sky-700', 'text-white'));
        pill.classList.add('bg-sky-700', 'text-white');
        this.sampleCheckFilter = pill.getAttribute('data-filter');
        this.renderModerationTable();
      });
    });

    // CSV Roster Upload
    const modalFileInput = document.getElementById('modalCsvFileInput');
    if (modalFileInput) {
      modalFileInput.addEventListener('change', () => {});
    }

    // Shared Folder Live-Sync Update Listener
    window.addEventListener('secs:sync:updated', (e) => {
      this.renderOverviewStats();
      this.renderLockControls();
      if (this.activeTab === 'tabExamStudio' || this.activeTab === 'tabPapers' || this.activeTab === 'tabRoster') {
        this.renderPapersHub();
        this.renderActivePaperWorkspaceHeader();
      } else if (this.activeTab === 'tabConsolidation') {
        this.populateFilterDropdowns();
        this.renderConsolidationTable();
        this.renderLiveSyncWidgets();
      } else if (this.activeTab === 'tabModeration') {
        this.renderModerationTable();
      } else if (this.activeTab === 'tabAnalytics') {
        this.renderAnalyticsTab();
      }
    });
  }

  switchTab(tabId) {
    // Alias routing for unified Exam Studio & Cohort Manager
    if (tabId === 'tabPapers' || tabId === 'tabRoster') {
      tabId = 'tabExamStudio';
    }
    if (tabId === 'tabCalibration') {
      tabId = 'tabSettings';
    }
    this.activeTab = tabId;
    try { sessionStorage.setItem('SECS_HOD_ACTIVE_TAB', tabId); } catch (e) {}

    // Update Nav Button Styles
    const navButtons = document.querySelectorAll('.hod-nav-btn');
    navButtons.forEach(btn => {
      if (btn.getAttribute('data-tab') === tabId) {
        btn.classList.add('border-sky-600', 'text-sky-600', 'bg-sky-50/50');
        btn.classList.remove('border-transparent', 'text-slate-600', 'hover:text-slate-800');
      } else {
        btn.classList.remove('border-sky-600', 'text-sky-600', 'bg-sky-50/50');
        btn.classList.add('border-transparent', 'text-slate-600', 'hover:text-slate-800');
      }
    });

    // Hide all tab panes
    const panes = document.querySelectorAll('.hod-tab-pane');
    panes.forEach(pane => pane.classList.add('hidden'));

    // Show target tab pane
    const activePane = document.getElementById(tabId);
    if (activePane) activePane.classList.remove('hidden');

    this.renderActiveTab();
  }

  renderActiveTab() {
    this.renderLockControls();
    this.renderExecutivePaperDeck();
    this.renderOverviewStats();
    if (this.activeTab === 'tabRegisterPaper') {
      this.renderRegisterPaperTab();
    } else if (this.activeTab === 'tabExamStudio' || this.activeTab === 'tabPapers' || this.activeTab === 'tabRoster') {
      this.renderPapersHub();
      this.renderActivePaperWorkspaceHeader();
      this.renderExamSetupQuickBar();
      this.renderClassManagementSection();
      this.renderRosterTable();
      this.renderMarkersList();
    } else if (this.activeTab === 'tabConsolidation') {
      this.populateFilterDropdowns();
      this.renderConsolidationTable();
      this.renderLiveSyncWidgets();
    } else if (this.activeTab === 'tabModeration') {
      this.renderModerationTable();
    } else if (this.activeTab === 'tabAnalytics') {
      this.renderAnalyticsTab();
    } else if (this.activeTab === 'tabSettings' || this.activeTab === 'tabCalibration') {
      this.renderSettingsForm();
    } else if (this.activeTab === 'tabExport') {
      this.populateExportClassDropdown();
      this.handleExportScopeChange();
    }
  }

  renderOverviewStats() {
    const state = db.getState();
    const stats = analytics.computeCohortStats(state.students, state.config);

    const setText = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text;
    };

    setText('statCandidature', stats.totalCandidature);
    setText('statMarkedProgress', `${stats.totalMarked} / ${stats.totalCandidature} (${Math.round((stats.totalMarked / (stats.totalCandidature || 1)) * 100)}%)`);
    setText('statMeanScore', `${stats.mean} / ${state.config.totalMax}`);
    setText('statMedianScore', stats.median);
    setText('statPassRate', `${stats.passPct}% (${stats.passCount})`);
    setText('statQualityPassRate', `${stats.qualityPct}% (${stats.qualityCount})`);
    setText('statParCount', `${stats.parCount} (${stats.parPct}%)`);
    setText('statModeratedCount', `${stats.totalModerated} scripts`);
  }

  renderLiveSyncWidgets() {
    const container = document.getElementById('hodLiveSyncWidgetsContainer');
    if (!container) return;

    if (typeof syncService === 'undefined' || !syncService.isConnected()) {
      container.innerHTML = `
        <div class="mb-4 p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900 shadow-2xs">
          <div class="flex items-center gap-2.5">
            <span class="text-xl">📁</span>
            <div>
              <span class="font-bold">Operating in Local Standalone Mode</span>
              <p class="text-[11px] text-amber-800">To enable real-time score updates from markers on different laptops, link your School Shared Folder.</p>
            </div>
          </div>
          <button type="button" onclick="syncService.connectSharedFolder()" class="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs shadow-xs cursor-pointer transition-colors shrink-0">
            Link Shared Folder
          </button>
        </div>
      `;
      return;
    }

    const markers = syncService.activeMarkers || {};
    const markerKeys = Object.keys(markers);
    const feed = syncService.activityFeed || [];

    container.innerHTML = `
      <div class="mb-4 grid grid-cols-1 lg:grid-cols-3 gap-3">
        <!-- Active Markers Pulse Card -->
        <div class="p-3.5 bg-white border border-slate-200 rounded-xl shadow-2xs flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
              <span class="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Active Connected Markers</span>
              </span>
              <span class="text-[11px] font-bold text-slate-500">${markerKeys.length} active</span>
            </div>
            <div class="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
              ${markerKeys.length === 0 ? '<span class="text-xs text-slate-400 italic">Waiting for markers to submit marks...</span>' : 
                markerKeys.map(code => {
                  const m = markers[code];
                  return `
                    <div class="px-2 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-[11px] font-mono font-medium flex items-center gap-1">
                      <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      <strong>${code}</strong>: ${m.count} scripts
                    </div>
                  `;
                }).join('')
              }
            </div>
          </div>
          <div class="pt-2 border-t border-slate-100 mt-2 flex items-center justify-between text-[11px] text-slate-500">
            <span>Folder: <strong class="text-slate-700">${syncService.folderName}</strong></span>
            <button type="button" onclick="syncService.pollOnce()" class="text-sky-600 hover:text-sky-800 font-bold cursor-pointer">🔄 Refresh Now</button>
          </div>
        </div>

        <!-- Live Activity Stream Ticker -->
        <div class="lg:col-span-2 p-3.5 bg-white border border-slate-200 rounded-xl shadow-2xs">
          <div class="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
            <span class="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span>⚡ Live Activity Stream</span>
            </span>
            <span class="text-[11px] text-slate-500 font-medium">Auto-polls shared folder every 2s (Instant Live Sync)</span>
          </div>
          <div class="space-y-1.5 max-h-24 overflow-y-auto pr-1">
            ${feed.length === 0 ? '<span class="text-xs text-slate-400 italic">No incoming script activities yet this session.</span>' : 
              feed.slice(0, 6).map(item => `
                <div class="flex items-center justify-between text-xs py-1 px-2 rounded-lg bg-slate-50 border border-slate-100">
                  <div class="flex items-center gap-2">
                    <span class="text-[10px] font-mono text-slate-400">${item.time}</span>
                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold ${item.type === 'moderation' ? 'bg-purple-100 text-purple-800' : 'bg-sky-100 text-sky-800'}">${item.markerCode}</span>
                    <span class="text-slate-700 text-[11px]">${item.text}</span>
                  </div>
                  <span class="text-[10px] text-emerald-600 font-bold shrink-0">✓ Synced</span>
                </div>
              `).join('')
            }
          </div>
        </div>
      </div>
    `;
  }

  populateFilterDropdowns() {
    const state = db.getState();
    const formSelect = document.getElementById('hodFormClassFilter');
    const mtSelect = document.getElementById('hodMtClassFilter');
    const markerSelect = document.getElementById('hodMarkerFilter');

    const totalCohort = state.students.length;
    const markedCohort = state.students.filter(s => s.score && s.score.total !== null).length;

    if (formSelect) {
      const forms = Array.from(new Set(state.students.map(s => s.formClass))).sort();
      formSelect.innerHTML = `<option value="ALL">All Form Classes [${markedCohort}/${totalCohort} marked]</option>` + 
        forms.map(f => {
          const fStudents = state.students.filter(s => s.formClass === f);
          const fMarked = fStudents.filter(s => s.score && s.score.total !== null).length;
          return `<option value="${f}">${f} [${fMarked}/${fStudents.length} marked]</option>`;
        }).join('');
      formSelect.value = this.formClassFilter;
    }

    if (mtSelect) {
      const mts = Array.from(new Set(state.students.map(s => s.mtClass))).sort();
      mtSelect.innerHTML = `<option value="ALL">All MT Classes [${markedCohort}/${totalCohort} marked]</option>` + 
        mts.map(m => {
          const mStudents = state.students.filter(s => s.mtClass === m);
          const mMarked = mStudents.filter(s => s.score && s.score.total !== null).length;
          return `<option value="${m}">${m} [${mMarked}/${mStudents.length} marked]</option>`;
        }).join('');
      mtSelect.value = this.mtClassFilter;
    }

    if (markerSelect) {
      markerSelect.innerHTML = `<option value="ALL">All Markers [${markedCohort}/${totalCohort} marked]</option>` + 
        state.markers.map(m => {
          const mMarked = state.students.filter(s => s.markerCode === m.code && s.score && s.score.total !== null).length;
          return `<option value="${m.code}">${m.code} - ${m.name} (${mMarked} marked)</option>`;
        }).join('');
      markerSelect.value = this.markerFilter;
    }
  }

  getFilteredStudents() {
    const state = db.getState();
    const isBlind = state.config.blindMode;

    return state.students.filter(s => {
      if (this.formClassFilter !== 'ALL' && s.formClass !== this.formClassFilter) return false;
      if (this.mtClassFilter !== 'ALL' && s.mtClass !== this.mtClassFilter) return false;
      if (this.markerFilter !== 'ALL' && s.markerCode !== this.markerFilter) return false;

      // Band filter
      if (this.bandFilter === 'UNMARKED' && s.status !== 'unmarked') return false;
      if (this.bandFilter === 'MODERATED' && s.status !== 'moderated') return false;
      if (this.bandFilter === 'QUALITY' && (!s.score.pct || s.score.pct < state.config.qualityCutoffPct)) return false;
      if (this.bandFilter === 'PASS' && (!s.score.pct || s.score.pct < state.config.passCutoffPct || s.score.pct >= state.config.qualityCutoffPct)) return false;
      if (this.bandFilter === 'PAR' && (s.score.pct === null || s.score.pct >= state.config.passCutoffPct)) return false;

      // Search Query
      if (this.searchQuery) {
        const q = this.searchQuery;
        const matchName = !isBlind && s.name.toLowerCase().includes(q);
        const matchChinese = !isBlind && s.chineseName && s.chineseName.toLowerCase().includes(q);
        const matchScript = s.scriptId.toLowerCase().includes(q);
        const matchReg = String(s.regNo) === q;
        const matchForm = s.formClass.toLowerCase().includes(q);
        const matchMT = s.mtClass.toLowerCase().includes(q);
        return matchName || matchChinese || matchScript || matchReg || matchForm || matchMT;
      }

      return true;
    });
  }

  renderConsolidationTable() {
    const tbody = document.getElementById('hodConsolidationTableBody');
    const rowCountBadge = document.getElementById('hodFilteredRowCount');
    if (!tbody) return;

    const state = db.getState();
    const list = this.getFilteredStudents();

    // Sort list
    list.sort((a, b) => {
      const aTotal = a.score.total !== null ? a.score.total : -1;
      const bTotal = b.score.total !== null ? b.score.total : -1;

      if (this.sortBy === 'totalDesc') return bTotal - aTotal;
      if (this.sortBy === 'totalAsc') return aTotal - bTotal;
      if (this.sortBy === 'formClass') {
        if (a.formClass !== b.formClass) return a.formClass.localeCompare(b.formClass);
        return a.regNo - b.regNo;
      }
      if (this.sortBy === 'mtClass') {
        if (a.mtClass !== b.mtClass) return a.mtClass.localeCompare(b.mtClass);
        return a.regNo - b.regNo;
      }
      if (this.sortBy === 'name') return a.name.localeCompare(b.name);
      if (this.sortBy === 'scriptId') return a.scriptId.localeCompare(b.scriptId);
      return 0;
    });

    // Update live consolidation progress banner
    const bannerText = document.getElementById('hodBannerProgressText');
    const bannerUnmarked = document.getElementById('hodBannerUnmarkedCount');
    const bannerModerated = document.getElementById('hodBannerModeratedCount');
    const bannerClassIndicator = document.getElementById('hodBannerClassIndicator');

    const totalCohort = state.students.length;
    const markedCohort = state.students.filter(s => s.score && s.score.total !== null).length;
    const cohortPct = totalCohort > 0 ? Math.round((markedCohort / totalCohort) * 1000) / 10 : 0;

    const isClassFiltered = this.formClassFilter !== 'ALL' || this.mtClassFilter !== 'ALL';
    let targetGroup = state.students;
    let groupLabel = 'Cohort';

    if (this.formClassFilter !== 'ALL') {
      targetGroup = state.students.filter(s => s.formClass === this.formClassFilter);
      groupLabel = `Class [${this.formClassFilter}]`;
    } else if (this.mtClassFilter !== 'ALL') {
      targetGroup = state.students.filter(s => s.mtClass === this.mtClassFilter);
      groupLabel = `MT Class [${this.mtClassFilter}]`;
    }

    const totalTarget = targetGroup.length;
    const markedTarget = targetGroup.filter(s => s.score && s.score.total !== null).length;
    const targetPct = totalTarget > 0 ? Math.round((markedTarget / totalTarget) * 1000) / 10 : 0;
    const unmarkedTarget = totalTarget - markedTarget;
    const moderatedTarget = targetGroup.filter(s => s.status === 'moderated').length;

    if (bannerText) {
      if (isClassFiltered) {
        bannerText.innerHTML = `${groupLabel} Progress: <strong class="text-sky-700">${markedTarget} / ${totalTarget} Marked (${targetPct}%)</strong> <span class="text-slate-500 font-normal text-xs">| Cohort Total: ${markedCohort}/${totalCohort} (${cohortPct}%)</span>`;
      } else {
        bannerText.innerHTML = `Cohort Progress: <strong class="text-sky-700">${markedCohort} / ${totalCohort} Marked (${cohortPct}%)</strong>`;
      }
    }
    if (bannerUnmarked) bannerUnmarked.textContent = `${unmarkedTarget} scripts`;
    if (bannerModerated) bannerModerated.textContent = `${moderatedTarget} scripts`;
    if (bannerClassIndicator) {
      if (isClassFiltered) {
        bannerClassIndicator.classList.remove('hidden');
        bannerClassIndicator.textContent = groupLabel;
      } else {
        bannerClassIndicator.classList.add('hidden');
      }
    }

    if (rowCountBadge) rowCountBadge.textContent = `${list.length} scripts found`;

    if (list.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="10" class="p-8 text-center text-sm text-slate-400">
            No student records match the selected filters.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = list.map(s => {
      const isMarked = s.score && s.score.total !== null;
      const isBlind = state.config.blindMode;
      const displayName = isBlind 
        ? `[Candidate ${s.scriptId}]` 
        : (s.chineseName ? `${s.name} <span class="text-slate-500 font-normal">(${s.chineseName})</span>` : s.name);

      let statusBadge = '';
      if (s.status === 'moderated') {
        statusBadge = `<span class="px-2 py-0.5 text-xs font-semibold rounded bg-purple-100 text-purple-800">Moderated (Δ ${s.moderation.delta > 0 ? '+' : ''}${s.moderation.delta})</span>`;
      } else if (s.status === 'marked') {
        statusBadge = `<span class="px-2 py-0.5 text-xs font-semibold rounded bg-emerald-100 text-emerald-800">Marked</span>`;
      } else {
        statusBadge = `<span class="px-2 py-0.5 text-xs font-semibold rounded bg-amber-100 text-amber-800">Unmarked</span>`;
      }

      let bandHighlight = '';
      if (isMarked) {
        if (s.score.pct >= state.config.qualityCutoffPct) {
          bandHighlight = 'text-emerald-700 font-bold';
        } else if (s.score.pct < state.config.passCutoffPct) {
          bandHighlight = 'text-rose-600 font-bold';
        }
      }

      const isModScript = s.status === 'moderated' || (s.moderation && s.moderation.moderated);
      let markerColHtml = `<div class="font-mono font-semibold text-slate-700">${s.markerCode || '-'}</div>`;
      if (isModScript) {
        const modCode = (s.moderation && s.moderation.moderatorCode)
          ? s.moderation.moderatorCode
          : (s.moderation && s.moderation.moderatedBy ? (s.moderation.moderatedBy.match(/\(([^)]+)\)/)?.[1] || s.moderation.moderatedBy) : 'MOD');
        markerColHtml += `
          <div class="mt-0.5">
            <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200" title="Moderated by ${s.moderation?.moderatedBy || modCode}">
              Mod: ${modCode}
            </span>
          </div>`;
      }

      return `
        <tr class="hover:bg-slate-50 border-b border-slate-100 text-xs text-slate-700 transition-colors">
          <td class="px-3 py-2.5 font-mono text-slate-500 font-bold">${s.scriptId}</td>
          <td class="px-3 py-2.5 font-semibold text-slate-900">${displayName}</td>
          <td class="px-3 py-2.5 text-slate-600">${s.formClass} (#${s.regNo})</td>
          <td class="px-3 py-2.5 text-slate-600 font-medium">${s.mtClass}</td>
          <td class="px-3 py-2.5">${markerColHtml}</td>
          <td class="px-3 py-2.5 text-center font-medium">
            ${isMarked ? `
              <div>${s.score.content}</div>
              ${s.status === 'moderated' && (s.initialScore || s.moderation?.originalScore) ? `
                <span class="text-[10px] text-slate-400 block font-normal">Orig: ${(s.initialScore || s.moderation?.originalScore).content}</span>
              ` : ''}
            ` : '-'}
          </td>
          <td class="px-3 py-2.5 text-center font-medium">
            ${isMarked ? `
              <div>${s.score.language}</div>
              ${s.status === 'moderated' && (s.initialScore || s.moderation?.originalScore) ? `
                <span class="text-[10px] text-slate-400 block font-normal">Orig: ${(s.initialScore || s.moderation?.originalScore).language}</span>
              ` : ''}
            ` : '-'}
          </td>
          <td class="px-3 py-2.5 text-center font-bold text-sm ${bandHighlight}">
            ${isMarked ? `
              <div>${s.score.total} <span class="text-[11px] font-normal text-slate-400">(${s.score.pct}%)</span></div>
              ${s.status === 'moderated' && (s.initialScore || s.moderation?.originalScore) ? `
                <div class="text-[10px] text-amber-800 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded font-mono font-normal mt-0.5 inline-block">
                  Orig: ${(s.initialScore || s.moderation?.originalScore).total} (${s.moderation.delta > 0 ? '+' : ''}${s.moderation.delta})
                </div>
              ` : ''}
            ` : '-'}
          </td>
          <td class="px-3 py-2.5">${statusBadge}</td>
          <td class="px-3 py-2.5 text-right">
            ${isMarked ? `
              <button onclick="hodApp.openModerationModal('${s.id}')" 
                      class="px-2 py-1 text-xs bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 rounded font-medium cursor-pointer">
                Moderate / Audit
              </button>
            ` : `
              <span class="text-slate-400 text-xs">Waiting</span>
            `}
          </td>
        </tr>
      `;
    }).join('');
  }

  renderModerationTable() {
    const tbody = document.getElementById('hodModerationTableBody');
    if (!tbody) return;

    const state = db.getState();
    const marked = state.students.filter(s => s.score && s.score.total !== null);

    let filtered = marked;

    if (this.sampleCheckFilter === 'borderlinePass') {
      // 48% to 52%
      filtered = marked.filter(s => s.score.pct >= 46 && s.score.pct <= 54);
    } else if (this.sampleCheckFilter === 'borderlineQuality') {
      // 78% to 82%
      filtered = marked.filter(s => s.score.pct >= 76 && s.score.pct <= 84);
    } else if (this.sampleCheckFilter === 'outliers') {
      // Discrepancy between content and language mark
      filtered = marked.filter(s => Math.abs(s.score.content - s.score.language) >= (state.config.contentMax * 0.4));
    } else if (this.sampleCheckFilter === 'random10') {
      // Sample 10% deterministically
      filtered = marked.filter((_, idx) => idx % 10 === 0);
    }

    const countBadge = document.getElementById('hodSampleFilterCount');
    if (countBadge) countBadge.textContent = `${filtered.length} candidate scripts flagged for sample check`;

    if (filtered.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="9" class="p-8 text-center text-sm text-slate-400">
            No scripts match this sample check criteria. Try selecting "All Marked Scripts".
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = filtered.map(s => {
      const isMod = s.moderation && s.moderation.moderated;
      const orig = s.initialScore || (s.moderation && s.moderation.originalScore);
      let deltaBadge = '<span class="text-slate-400">-</span>';

      if (isMod) {
        const delta = s.moderation.delta;
        if (delta === 0) {
          deltaBadge = '<span class="px-2 py-0.5 text-xs rounded bg-slate-100 text-slate-700 font-bold">Δ 0 (Agreed)</span>';
        } else if (delta > 0) {
          deltaBadge = `<span class="px-2 py-0.5 text-xs rounded bg-emerald-100 text-emerald-800 font-bold">Δ +${delta}</span>`;
        } else {
          deltaBadge = `<span class="px-2 py-0.5 text-xs rounded bg-rose-100 text-rose-800 font-bold">Δ ${delta}</span>`;
        }
      }

      const displayName = s.chineseName ? `${s.name} <span class="text-slate-500 font-normal">(${s.chineseName})</span>` : s.name;

      let markerModHtml = `<div class="font-bold text-slate-700">${s.markerCode || '-'}</div>`;
      if (isMod) {
        const modCode = (s.moderation && s.moderation.moderatorCode)
          ? s.moderation.moderatorCode
          : (s.moderation && s.moderation.moderatedBy ? (s.moderation.moderatedBy.match(/\(([^)]+)\)/)?.[1] || s.moderation.moderatedBy) : 'MOD');
        markerModHtml += `
          <div class="mt-0.5">
            <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200" title="Moderated by ${s.moderation?.moderatedBy || modCode}">
              Mod: ${modCode}
            </span>
          </div>`;
      }

      return `
        <tr class="hover:bg-slate-50 border-b border-slate-100 text-xs text-slate-700">
          <td class="px-3 py-2.5 font-mono font-bold text-slate-600">${s.scriptId}</td>
          <td class="px-3 py-2.5 font-medium">${displayName}</td>
          <td class="px-3 py-2.5">${s.formClass}</td>
          <td class="px-3 py-2.5 font-mono">${markerModHtml}</td>
          <td class="px-3 py-2.5 text-center font-medium">
            <div>${s.score.content} / ${state.config.contentMax}</div>
            ${isMod && orig ? `<span class="text-[10px] text-slate-400 block font-normal">Orig: ${orig.content}</span>` : ''}
          </td>
          <td class="px-3 py-2.5 text-center font-medium">
            <div>${s.score.language} / ${state.config.languageMax}</div>
            ${isMod && orig ? `<span class="text-[10px] text-slate-400 block font-normal">Orig: ${orig.language}</span>` : ''}
          </td>
          <td class="px-3 py-2.5 text-center font-bold text-sky-700">
            <div>${s.score.total} (${s.score.pct}%)</div>
            ${isMod && orig ? `
              <span class="text-[10px] text-amber-800 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded font-mono font-normal inline-block mt-0.5">
                Orig: ${orig.total}
              </span>
            ` : ''}
          </td>
          <td class="px-3 py-2.5 text-center">${deltaBadge}</td>
          <td class="px-3 py-2.5 text-right">
            <button onclick="hodApp.openModerationModal('${s.id}')"
                    class="px-2.5 py-1 text-xs bg-indigo-600 text-white hover:bg-indigo-700 rounded font-medium cursor-pointer shadow-xs">
              ${isMod ? 'Re-Audit' : 'Sample Check'}
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  openModerationModal(studentId) {
    this.moderatingStudentId = studentId;
    const state = db.getState();
    const s = state.students.find(x => x.id === studentId);
    if (!s) return;

    const modal = document.getElementById('hodModerationModal');
    if (!modal) return;

    document.getElementById('modModalScriptId').textContent = s.scriptId;
    document.getElementById('modModalStudentName').textContent = s.chineseName ? `${s.name} (${s.chineseName})` : s.name;
    document.getElementById('modModalClassInfo').textContent = `${s.formClass} (#${s.regNo}) | MT: ${s.mtClass}`;
    document.getElementById('modModalMarkerCode').textContent = s.markerCode || 'N/A';

    const modBadge = document.getElementById('modModalModeratorBadge');
    if (modBadge) {
      if (s.moderation && s.moderation.moderated) {
        const mCode = s.moderation.moderatorCode || (s.moderation.moderatedBy ? (s.moderation.moderatedBy.match(/\(([^)]+)\)/)?.[1] || s.moderation.moderatedBy) : 'HOD');
        modBadge.textContent = `Moderated by: ${mCode}`;
        modBadge.classList.remove('hidden');
      } else {
        modBadge.classList.add('hidden');
      }
    }

    // Original Marks
    document.getElementById('modOrigContent').textContent = s.score.content;
    document.getElementById('modOrigLang').textContent = s.score.language;
    document.getElementById('modOrigTotal').textContent = s.score.total;
    document.getElementById('modOrigPct').textContent = `${s.score.pct}%`;
    document.getElementById('modOrigTags').textContent = (s.tags || []).join(', ') || 'No tags recorded';
    document.getElementById('modOrigRemark').textContent = s.remark || 'No marker remarks.';

    // Setup HOD input defaults
    const modContent = document.getElementById('modHODContentInput');
    const modLang = document.getElementById('modHODLangInput');
    const modRemark = document.getElementById('modHODRemarkInput');

    modContent.max = state.config.contentMax;
    modContent.min = state.config.contentMin;
    modLang.max = state.config.languageMax;
    modLang.min = state.config.languageMin;

    if (s.moderation && s.moderation.moderated) {
      modContent.value = s.moderation.hodContent;
      modLang.value = s.moderation.hodLanguage;
      modRemark.value = s.moderation.hodRemark || '';
    } else {
      modContent.value = s.score.content;
      modLang.value = s.score.language;
      modRemark.value = '';
    }

    this.handleModerationScoreChange();
    modal.classList.remove('hidden');
  }

  closeModerationModal() {
    this.moderatingStudentId = null;
    const modal = document.getElementById('hodModerationModal');
    if (modal) modal.classList.add('hidden');
  }

  handleModerationScoreChange() {
    const state = db.getState();
    const s = state.students.find(x => x.id === this.moderatingStudentId);
    if (!s) return;

    const modContent = document.getElementById('modHODContentInput');
    const modLang = document.getElementById('modHODLangInput');
    const totalEl = document.getElementById('modHODTotalPreview');
    const deltaEl = document.getElementById('modHODDeltaPreview');

    const c = Number(modContent.value);
    const l = Number(modLang.value);

    if (isNaN(c) || isNaN(l)) {
      totalEl.textContent = '-';
      deltaEl.textContent = '-';
      return;
    }

    const newTotal = c + l;
    const initialTotal = s.score.total || 0;
    const delta = newTotal - initialTotal;

    totalEl.textContent = `${newTotal} / ${state.config.totalMax}`;

    if (delta === 0) {
      deltaEl.innerHTML = `<span class="text-slate-600 font-bold">0 (No change)</span>`;
    } else if (delta > 0) {
      deltaEl.innerHTML = `<span class="text-emerald-600 font-bold">+${delta} marks (Score increased)</span>`;
    } else {
      deltaEl.innerHTML = `<span class="text-rose-600 font-bold">${delta} marks (Score lowered)</span>`;
    }
  }

  submitModeration() {
    if (!this.moderatingStudentId) return;

    const state = db.getState();
    const modContent = document.getElementById('modHODContentInput');
    const modLang = document.getElementById('modHODLangInput');
    const modRemark = document.getElementById('modHODRemarkInput');

    const c = Number(modContent.value);
    const l = Number(modLang.value);

    if (isNaN(c) || c < state.config.contentMin || c > state.config.contentMax) {
      alert(`Content mark must be within ${state.config.contentMin} and ${state.config.contentMax}.`);
      return;
    }

    if (isNaN(l) || l < state.config.languageMin || l > state.config.languageMax) {
      alert(`Language mark must be within ${state.config.languageMin} and ${state.config.languageMax}.`);
      return;
    }

    const moderatorName = (typeof auth !== 'undefined' && auth.session && auth.session.markerName)
      ? `${auth.session.markerName} (${auth.session.markerCode || 'HOD'})`
      : 'HOD';

    const res = db.saveModeration(this.moderatingStudentId, c, l, modRemark.value.trim(), moderatorName);
    if (res.success) {
      this.closeModerationModal();
      this.renderActiveTab();
      markerApp.showToast(`Moderation finalized for ${res.student.name} (Final: ${c + l}/${state.config.totalMax})!`);
    }
  }

  renderAnalyticsTab() {
    const state = db.getState();
    const stats = analytics.computeCohortStats(state.students, state.config);
    const mtBreakdown = analytics.computeGroupBreakdown(state.students, 'mtClass', state.config);
    const formBreakdown = analytics.computeGroupBreakdown(state.students, 'formClass', state.config);
    const markerReliability = analytics.computeMarkerReliability(state.students, state.markers, stats.mean, state.config);

    // Render Band Counts
    const b1 = document.getElementById('bandCount1');
    const b2 = document.getElementById('bandCount2');
    const b3 = document.getElementById('bandCount3');
    const b4 = document.getElementById('bandCount4');
    if (b1) b1.textContent = stats.bandCounts.band1;
    if (b2) b2.textContent = stats.bandCounts.band2;
    if (b3) b3.textContent = stats.bandCounts.band3;
    if (b4) b4.textContent = stats.bandCounts.band4;

    // MT Class Table
    const mtTbody = document.getElementById('analyticsMtTableBody');
    if (mtTbody) {
      mtTbody.innerHTML = mtBreakdown.map(m => `
        <tr class="border-b border-slate-100 hover:bg-slate-50 text-xs">
          <td class="px-3 py-2 font-semibold text-slate-800">${m.groupName}</td>
          <td class="px-3 py-2 text-center">${m.totalCount}</td>
          <td class="px-3 py-2 text-center">${m.markedCount}</td>
          <td class="px-3 py-2 text-center font-bold text-sky-700">${m.mean}</td>
          <td class="px-3 py-2 text-center text-emerald-700 font-semibold">${m.qualityPct}%</td>
          <td class="px-3 py-2 text-center font-medium">${m.passPct}%</td>
          <td class="px-3 py-2 text-center text-rose-600 font-bold">${m.parCount}</td>
        </tr>
      `).join('');
    }

    // Form Class Table
    const formTbody = document.getElementById('analyticsFormTableBody');
    if (formTbody) {
      formTbody.innerHTML = formBreakdown.map(f => `
        <tr class="border-b border-slate-100 hover:bg-slate-50 text-xs">
          <td class="px-3 py-2 font-semibold text-slate-800">${f.groupName}</td>
          <td class="px-3 py-2 text-center">${f.totalCount}</td>
          <td class="px-3 py-2 text-center">${f.markedCount}</td>
          <td class="px-3 py-2 text-center font-bold text-sky-700">${f.mean}</td>
          <td class="px-3 py-2 text-center text-emerald-700 font-semibold">${f.qualityPct}%</td>
          <td class="px-3 py-2 text-center font-medium">${f.passPct}%</td>
          <td class="px-3 py-2 text-center text-rose-600 font-bold">${f.parCount}</td>
        </tr>
      `).join('');
    }

    // Marker Calibration Table
    const markerTbody = document.getElementById('analyticsMarkerTableBody');
    if (markerTbody) {
      markerTbody.innerHTML = markerReliability.map(m => {
        let statusBadge = '<span class="px-2 py-0.5 rounded text-xs bg-slate-100 text-slate-600">Pending</span>';
        if (m.calibrationStatus === 'Calibrated') {
          statusBadge = '<span class="px-2 py-0.5 rounded text-xs bg-emerald-100 text-emerald-800 font-bold">✓ Calibrated</span>';
        } else if (m.calibrationStatus.includes('Lenient')) {
          statusBadge = '<span class="px-2 py-0.5 rounded text-xs bg-amber-100 text-amber-800 font-bold">▲ Lenient</span>';
        } else if (m.calibrationStatus.includes('Strict')) {
          statusBadge = '<span class="px-2 py-0.5 rounded text-xs bg-rose-100 text-rose-800 font-bold">▼ Strict</span>';
        }

        return `
          <tr class="border-b border-slate-100 hover:bg-slate-50 text-xs">
            <td class="px-3 py-2 font-mono font-bold text-slate-700">${m.markerCode}</td>
            <td class="px-3 py-2 font-medium text-slate-900">${m.markerName}</td>
            <td class="px-3 py-2 text-center font-semibold">${m.scriptCount}</td>
            <td class="px-3 py-2 text-center font-bold text-sky-700">${m.mean}</td>
            <td class="px-3 py-2 text-center font-mono">${m.deltaFromCohort > 0 ? '+' : ''}${m.deltaFromCohort}</td>
            <td class="px-3 py-2 text-center">${statusBadge}</td>
            <td class="px-3 py-2 text-center">${m.sampleCheckedCount} scripts (Δ: ${m.avgModerationDelta})</td>
          </tr>
        `;
      }).join('');
    }
  }

  renderExamSetupQuickBar() {
    const state = db.getState();
    const config = state.config;
    const lvl = document.getElementById('rosterSetupLevel');
    const subj = document.getElementById('rosterSetupSubject');
    const title = document.getElementById('rosterSetupTitle');
    const preset = document.getElementById('rosterSetupPreset');

    if (lvl) lvl.value = config.level || '';
    if (subj) subj.value = config.subject || '';
    if (title) title.value = config.examTitle || '';
    if (preset) preset.value = config.presetId || 'CUSTOM';
  }

  applyPresetFromRoster(presetId) {
    const preset = SECS_CONFIG.PRESETS[presetId];
    if (preset) {
      const lvl = document.getElementById('rosterSetupLevel');
      const subj = document.getElementById('rosterSetupSubject');
      if (lvl) lvl.value = preset.level;
      if (subj) subj.value = preset.subject;
    }
  }

  saveCohortDetails() {
    const lvl = (document.getElementById('rosterSetupLevel').value || '').trim();
    const subj = (document.getElementById('rosterSetupSubject').value || '').trim();
    const title = (document.getElementById('rosterSetupTitle').value || '').trim();
    const presetId = document.getElementById('rosterSetupPreset').value;

    const updateObj = {
      level: lvl || 'Primary 4',
      subject: subj || 'Mother Tongue',
      examTitle: title || `${lvl} ${subj} Examination`,
      presetId: presetId
    };

    const preset = SECS_CONFIG.PRESETS[presetId];
    if (preset) {
      updateObj.contentMax = preset.contentMax;
      updateObj.languageMax = preset.languageMax;
      updateObj.passCutoffPct = preset.passCutoffPct;
      updateObj.qualityCutoffPct = preset.qualityCutoffPct;
    }

    db.updateConfig(updateObj);

    const examHeader = document.getElementById('globalExamTitleHeader');
    if (examHeader) examHeader.textContent = db.getState().config.examTitle;

    markerApp.renderMarkerHeader();
    this.renderSettingsForm();
    this.renderOverviewStats();
    this.autoPublishActiveExamIfConnected();
    this.renderActivePaperWorkspaceHeader();
    this.renderPapersHub();
    markerApp.showToast('Examination cohort details and rubrics saved!');
  }

  renderRosterTable() {
    const tbody = document.getElementById('rosterMasterTableBody');
    const summaryEl = document.getElementById('rosterCountSummary');
    if (!tbody) return;

    const state = db.getState();
    const activeExam = db.getActiveExam();

    if (activeExam && activeExam.isArchived) {
      if (summaryEl) summaryEl.textContent = 'Archived Paper (Read-Only Historical Vault)';
      tbody.innerHTML = `
        <tr>
          <td colspan="7" class="p-8 text-center text-sm text-slate-500 bg-slate-50">
            <div class="max-w-md mx-auto space-y-2">
              <span class="text-3xl block">🗃️</span>
              <div class="font-bold text-slate-800">This Examination Paper has been Archived</div>
              <p class="text-xs text-slate-500">Archived papers are kept in the historical vault and hidden from active roster workflows to avoid confusion. To view, edit, or mark this cohort roster, please restore the paper from the <strong>Papers Hub (Archived Papers tab)</strong>.</p>
              <button onclick="hodApp.switchPapersHubSubTab('tabSubArchivedPapers')" class="mt-2 px-3.5 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-semibold cursor-pointer">
                Go to Archived Papers Vault
              </button>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    let students = [...state.students];

    // Read filter by class and search
    const classFilter = document.getElementById('rosterClassFilter')?.value || 'ALL';
    const searchQuery = (document.getElementById('rosterSearchInput')?.value || '').toLowerCase().trim();

    if (classFilter.startsWith('FORM:')) {
      const fc = classFilter.substring(5);
      students = students.filter(s => s.formClass === fc);
    } else if (classFilter.startsWith('MT:')) {
      const mc = classFilter.substring(3);
      students = students.filter(s => s.mtClass === mc);
    }

    if (searchQuery) {
      students = students.filter(s => 
        (s.name && s.name.toLowerCase().includes(searchQuery)) ||
        (s.chineseName && s.chineseName.toLowerCase().includes(searchQuery)) ||
        (s.scriptId && s.scriptId.toLowerCase().includes(searchQuery)) ||
        (s.formClass && s.formClass.toLowerCase().includes(searchQuery)) ||
        (s.mtClass && s.mtClass.toLowerCase().includes(searchQuery)) ||
        String(s.regNo) === searchQuery
      );
    }

    const formClasses = new Set(state.students.map(s => s.formClass).filter(Boolean));
    const mtClasses = new Set(state.students.map(s => s.mtClass).filter(Boolean));

    if (summaryEl) {
      if (students.length !== state.students.length) {
        summaryEl.textContent = `Showing ${students.length} of ${state.students.length} pupils (${formClasses.size} Form Classes & ${mtClasses.size} MT Classes)`;
      } else {
        summaryEl.textContent = `${students.length} pupils loaded across ${formClasses.size} Form Classes & ${mtClasses.size} MT Classes`;
      }
    }

    if (students.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" class="p-8 text-center text-sm text-slate-400">
            No pupils found matching the active filter.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = students.map(s => `
      <tr class="border-b border-slate-100 hover:bg-slate-50 text-xs transition-colors">
        <td class="px-3 py-2.5 font-mono text-slate-500 font-semibold">${s.scriptId}</td>
        <td class="px-3 py-2.5 font-medium text-slate-900">
          ${s.name}
          ${s.chineseName ? `<span class="ml-1 text-slate-500 font-normal">(${s.chineseName})</span>` : ''}
        </td>
        <td class="px-3 py-2.5 text-slate-600 font-medium">${s.formClass}</td>
        <td class="px-3 py-2.5 text-slate-600 font-medium">${s.mtClass}</td>
        <td class="px-3 py-2.5 text-center text-slate-500">#${s.regNo}</td>
        <td class="px-3 py-2.5 text-center">
          <span class="px-2 py-0.5 rounded text-[11px] font-semibold ${s.status === 'unmarked' ? 'bg-amber-100 text-amber-800' : (s.status === 'moderated' ? 'bg-purple-100 text-purple-800' : 'bg-emerald-100 text-emerald-800')}">
            ${s.status.toUpperCase()}
          </span>
        </td>
        <td class="px-3 py-2.5 text-right space-x-1 whitespace-nowrap">
          <button onclick="hodApp.openEditStudentModal('${s.id}')" class="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold cursor-pointer" title="Edit student details">
            ✏️
          </button>
          <button onclick="hodApp.deleteStudent('${s.id}')" class="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded text-xs font-semibold cursor-pointer" title="Delete student">
            🗑️
          </button>
        </td>
      </tr>
    `).join('');
  }

  openAddStudentModal() {
    const modal = document.getElementById('addStudentModal');
    if (modal) {
      document.getElementById('addStdName').value = '';
      const cEl = document.getElementById('addStdChineseName');
      if (cEl) cEl.value = '';
      document.getElementById('addStdFormClass').value = '';
      document.getElementById('addStdMtClass').value = '';
      document.getElementById('addStdRegNo').value = '';
      modal.classList.remove('hidden');
      document.getElementById('addStdName').focus();
    }
  }

  closeAddStudentModal() {
    const modal = document.getElementById('addStudentModal');
    if (modal) modal.classList.add('hidden');
  }

  submitAddStudent() {
    const name = document.getElementById('addStdName').value.trim();
    const chineseName = (document.getElementById('addStdChineseName')?.value || '').trim();
    const formClass = document.getElementById('addStdFormClass').value.trim();
    const mtClass = document.getElementById('addStdMtClass').value.trim();
    const regNo = document.getElementById('addStdRegNo').value.trim();

    if (!name || !formClass || !mtClass) {
      alert('Please fill in all student fields.');
      return;
    }

    const res = db.addStudent({ name, chineseName, formClass, mtClass, regNo });
    if (res.success) {
      this.closeAddStudentModal();
      this.populateFilterDropdowns();
      this.renderRosterTable();
      this.renderOverviewStats();
      this.autoPublishActiveExamIfConnected();
      this.renderActivePaperWorkspaceHeader();
      this.renderPapersHub();
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
      markerApp.showToast(`Student ${name} added to roster!`);
    }
  }

  openEditStudentModal(studentId) {
    const s = db.getState().students.find(x => x.id === studentId);
    if (!s) return;

    const modal = document.getElementById('editStudentModal');
    if (modal) {
      document.getElementById('editStdId').value = s.id;
      document.getElementById('editStdScriptIdBadge').textContent = s.scriptId;
      document.getElementById('editStdName').value = s.name;
      const cEl = document.getElementById('editStdChineseName');
      if (cEl) cEl.value = s.chineseName || '';
      document.getElementById('editStdFormClass').value = s.formClass;
      document.getElementById('editStdMtClass').value = s.mtClass;
      document.getElementById('editStdRegNo').value = s.regNo;
      modal.classList.remove('hidden');
      document.getElementById('editStdName').focus();
    }
  }

  closeEditStudentModal() {
    const modal = document.getElementById('editStudentModal');
    if (modal) modal.classList.add('hidden');
  }

  submitEditStudent() {
    const studentId = document.getElementById('editStdId').value;
    const name = document.getElementById('editStdName').value.trim();
    const chineseName = (document.getElementById('editStdChineseName')?.value || '').trim();
    const formClass = document.getElementById('editStdFormClass').value.trim();
    const mtClass = document.getElementById('editStdMtClass').value.trim();
    const regNo = document.getElementById('editStdRegNo').value.trim();

    const res = db.updateStudent(studentId, { name, chineseName, formClass, mtClass, regNo });
    if (res.success) {
      this.closeEditStudentModal();
      this.populateFilterDropdowns();
      this.renderRosterTable();
      this.renderConsolidationTable();
      this.autoPublishActiveExamIfConnected();
      this.renderActivePaperWorkspaceHeader();
      this.renderPapersHub();
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
      markerApp.showToast(`Updated details for ${name}!`);
    }
  }

  deleteStudent(studentId) {
    const s = db.getState().students.find(x => x.id === studentId);
    if (!s) return;

    if (confirm(`Are you sure you want to remove ${s.name} (${s.formClass}) from the roster?`)) {
      db.deleteStudent(studentId);
      this.populateFilterDropdowns();
      this.renderRosterTable();
      this.renderConsolidationTable();
      this.renderOverviewStats();
      this.autoPublishActiveExamIfConnected();
      this.renderActivePaperWorkspaceHeader();
      this.renderPapersHub();
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
      markerApp.showToast(`Student ${s.name} removed.`);
    }
  }

  confirmClearRoster() {
    const count = db.getState().students.length;
    if (count === 0) {
      alert('Roster is already empty.');
      return;
    }

    if (confirm(`⚠️ WARNING: Are you sure you want to remove ALL ${count} students from the current roster?\n\nThis will clear all registered students and their marks.`)) {
      db.clearAllStudents();
      this.populateFilterDropdowns();
      this.renderRosterTable();
      this.renderConsolidationTable();
      this.renderOverviewStats();
      this.autoPublishActiveExamIfConnected();
      this.renderActivePaperWorkspaceHeader();
      this.renderPapersHub();
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
      markerApp.clearActiveStudentForm();
      markerApp.showToast('Entire student roster has been cleared.');
    }
  }

  downloadCsvTemplate() {
    const templateContent = 
`Register Number,Student Name,Chinese Name,Form Class,Mother Tongue Class,Gender
1,Tan Wei Ting,陈韦廷,Humility 1 (Primary 4.1),4MT-1,F
2,Lim Jun Hao,林俊豪,Humility 1 (Primary 4.1),4MT-1,M
3,Muhammad Danial,,Humility 1 (Primary 4.1),4MT-3,M
4,Nurul Izzah,,Humility 1 (Primary 4.1),4MT-3,F
5,Chua En Xi,蔡恩希,Humility 1 (Primary 4.1),4MT-1,F
1,Lucas Ong Ze,王泽恩,Humility 2 (Primary 4.2),4MT-1,M
2,Megan Low Si,刘思慧,Humility 2 (Primary 4.2),4MT-2,F
3,Ahmad Farhan,,Humility 2 (Primary 4.2),4MT-3,M
4,Farah Nabilah,,Humility 2 (Primary 4.2),4MT-3,F
5,Benjamin Tan,陈志杰,Humility 2 (Primary 4.2),4MT-1,M
1,Darren Lim Jun,林俊毅,Humility 3 (Primary 4.3),4MT-2,M
2,Sherlyn Tan Hui,陈慧玲,Humility 3 (Primary 4.3),4MT-1,F
1,Aaron Wong Jia,黄家豪,Humility 4 (Primary 4.4),4MT-1,M
2,Charmaine Seah,谢敏仪,Humility 4 (Primary 4.4),4MT-2,F
`;
    // Prepend UTF-8 BOM (\uFEFF) so Microsoft Excel on Windows automatically detects UTF-8
    const blob = new Blob(['\uFEFF' + templateContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'SECS_Student_Roster_Template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  openImportModal() {
    const modal = document.getElementById('importCsvModal');
    if (modal) {
      document.getElementById('modalCsvFileInput').value = '';
      modal.classList.remove('hidden');
    }
  }

  closeImportModal() {
    const modal = document.getElementById('importCsvModal');
    if (modal) modal.classList.add('hidden');
  }

  executeCsvImport() {
    const fileInput = document.getElementById('modalCsvFileInput');
    const file = fileInput.files[0];
    if (!file) {
      alert('Please choose a CSV or Excel file to upload.');
      return;
    }

    const modeRadios = document.querySelectorAll('input[name="csvImportMode"]');
    let selectedMode = 'append';
    modeRadios.forEach(r => { if (r.checked) selectedMode = r.value; });

    if (selectedMode === 'replace') {
      const existingCount = db.getState().students.length;
      if (existingCount > 0 && !confirm(`⚠️ Confirmation: You selected "Replace Entire Roster".\nAll current ${existingCount} students will be cleared and replaced with this new file. Continue?`)) {
        return;
      }
    }

    const fileName = (file.name || '').toLowerCase();
    const reader = new FileReader();

    if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
      // Direct Excel Binary Upload via SheetJS (Guaranteed 100% native Chinese character support)
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const csvText = XLSX.utils.sheet_to_csv(worksheet);
          this.parseAndImportCSV(csvText, selectedMode);
          this.closeImportModal();
        } catch (err) {
          console.error('Excel parse error:', err);
          alert('Failed to read Excel file: ' + err.message);
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      // CSV File: Smart Encoding Detection (Handles UTF-8 with BOM, UTF-8 raw, GBK/CP936, Windows-1252)
      reader.onload = (e) => {
        try {
          const buffer = e.target.result;
          const bytes = new Uint8Array(buffer);
          let text = '';

          // 1. Check for UTF-8 BOM (0xEF, 0xBB, 0xBF)
          if (bytes.length >= 3 && bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) {
            text = new TextDecoder('utf-8').decode(bytes.subarray(3));
          } else {
            // 2. Attempt strict UTF-8
            try {
              text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
            } catch (utfErr) {
              // 3. Fallback to GBK / GB18030 (standard Chinese Windows ANSI export from Excel)
              try {
                text = new TextDecoder('gbk').decode(bytes);
              } catch (gbkErr) {
                text = new TextDecoder('windows-1252').decode(bytes);
              }
            }
          }

          // 4. Auto-repair any mojibake if UTF-8 was previously saved in ANSI (e.g. "é™ˆéŸ¦å»·")
          text = db.repairMojibake(text);

          this.parseAndImportCSV(text, selectedMode);
          this.closeImportModal();
        } catch (err) {
          console.error('CSV parse error:', err);
          alert('Failed to read CSV file: ' + err.message);
        }
      };
      reader.readAsArrayBuffer(file);
    }
  }

  resetDemoRoster() {
    if (confirm('🔄 Are you sure you want to reload the default bilingual demo roster?\n\nThis will restore all sample student records with English and Chinese names (e.g. 陈韦廷, 林俊豪).')) {
      db.resetToDemoState();
      this.populateFilterDropdowns();
      this.renderActiveTab();
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
      markerApp.clearActiveStudentForm();
      markerApp.showToast('✅ Default bilingual roster restored successfully.');
    }
  }

  parseAndImportCSV(csvText, mode = 'append') {
    const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length < 2) {
      alert('CSV file appears empty or missing headers.');
      return;
    }

    const parseCSVLine = (line) => {
      const result = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"' || char === "'") {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim().replace(/^["']|["']$/g, ''));
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim().replace(/^["']|["']$/g, ''));
      return result;
    };

    const headers = parseCSVLine(lines[0]).map(h => h.toLowerCase());
    const regIdx = headers.findIndex(h => h.includes('reg') || h.includes('index') || h.includes('no'));
    const chineseIdx = headers.findIndex(h => h.includes('chinese') || h.includes('华文') || h.includes('中文') || h.includes('cname') || h.includes('cl name'));
    const nameIdx = headers.findIndex(h => (h.includes('name') || h.includes('student')) && !h.includes('chinese') && !h.includes('华文') && !h.includes('中文'));
    const formIdx = headers.findIndex(h => (h.includes('form') || h.includes('class')) && !h.includes('mt') && !h.includes('mother'));
    const mtIdx = headers.findIndex(h => h.includes('mt') || h.includes('mother tongue') || h.includes('subject'));

    const parsedStudents = [];

    for (let i = 1; i < lines.length; i++) {
      const cols = parseCSVLine(lines[i]);
      if (cols.length >= 2) {
        let rawName = nameIdx !== -1 ? cols[nameIdx] : cols[1];
        let chineseName = chineseIdx !== -1 ? cols[chineseIdx] : '';

        // If no explicit Chinese column, check if rawName contains Chinese characters (e.g., "Tan Wei Ting (陈韦廷)" or "Tan Wei Ting 陈韦廷")
        if (!chineseName && rawName) {
          const cMatch = rawName.match(/[\u4e00-\u9fa5]+/g);
          if (cMatch) {
            chineseName = cMatch.join('');
            rawName = rawName.replace(/[\(（]?[\u4e00-\u9fa5]+[\)）]?/g, '').replace(/[\(\)（）]/g, '').replace(/\s+/g, ' ').trim();
          }
        }

        parsedStudents.push({
          name: rawName,
          chineseName: chineseName,
          formClass: formIdx !== -1 ? cols[formIdx] : cols[2] || '4A',
          mtClass: mtIdx !== -1 ? cols[mtIdx] : cols[3] || '4MT-1',
          regNo: regIdx !== -1 ? cols[regIdx] : cols[0] || i
        });
      }
    }

    if (parsedStudents.length > 0) {
      const added = db.importRoster(parsedStudents, mode);
      this.populateFilterDropdowns();
      this.renderActiveTab();
      this.autoPublishActiveExamIfConnected();
      this.renderActivePaperWorkspaceHeader();
      this.renderPapersHub();
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
      markerApp.showToast(`Successfully ${mode === 'replace' ? 'replaced roster with' : 'appended'} ${added} students!`);
    } else {
      alert('Could not parse any valid student rows from CSV.');
    }
  }

  renderMarkersList() {
    const listEl = document.getElementById('hodMarkersList');
    const badgeEl = document.getElementById('rosterMarkerCountBadge');
    if (!listEl) return;

    const state = db.getState();
    if (badgeEl) badgeEl.textContent = `${state.markers.length} markers active`;

    if (state.markers.length === 0) {
      listEl.innerHTML = `
        <div class="p-4 text-center text-xs text-slate-400">
          No markers registered. Click <strong>+ Add Marker</strong> to register exam markers.
        </div>
      `;
      return;
    }

    listEl.innerHTML = state.markers.map(m => {
      const count = state.students.filter(s => s.markerCode === m.code && s.score && s.score.total !== null).length;
      return `
        <div class="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
          <div class="flex items-center gap-2.5">
            <span class="px-2 py-1 bg-purple-100 text-purple-800 font-mono font-bold rounded-lg">${m.code}</span>
            <div>
              <span class="font-bold text-slate-900 block">${m.name}</span>
              <span class="text-[11px] text-slate-500">${count} scripts marked</span>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <label class="flex items-center gap-1.5 cursor-pointer bg-white px-2 py-1 rounded-md border border-slate-200 shadow-2xs hover:bg-purple-50 transition-colors" title="Grant or revoke Key Personnel moderation rights">
              <input type="checkbox" onchange="hodApp.toggleMarkerKP('${m.code}', this.checked)" ${m.isKP ? 'checked' : ''} class="text-purple-600 rounded cursor-pointer">
              <span class="text-[10px] font-bold ${m.isKP ? 'text-purple-700' : 'text-slate-500'}">KP Moderator</span>
            </label>
            <button onclick="hodApp.editMarker('${m.code}')" class="p-1.5 hover:bg-slate-200 rounded-lg text-slate-600 transition-colors cursor-pointer" title="Edit Marker Name">✏️</button>
            <button onclick="hodApp.deleteMarker('${m.code}')" class="p-1.5 hover:bg-rose-100 text-rose-600 rounded-lg transition-colors cursor-pointer" title="Remove Marker">🗑️</button>
          </div>
        </div>
      `;
    }).join('');

    this.renderPaperSecurityCard();
  }

  renderPaperSecurityCard() {
    const sec = db.getPaperSecurity();
    const markerInput = document.getElementById('paperMarkerPasscodeInput');
    const modInput = document.getElementById('paperModeratorPinInput');
    const badge = document.getElementById('paperSecurityStatusBadge');

    if (markerInput) markerInput.value = sec.markerPasscode || '1132';
    if (modInput) modInput.value = sec.moderatorPin || 'MOD88';
    if (badge) {
      badge.textContent = 'Enforced';
      badge.className = 'px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-emerald-50 text-emerald-700 border border-emerald-200';
    }
  }

  savePaperSecurity() {
    const markerInput = document.getElementById('paperMarkerPasscodeInput');
    const modInput = document.getElementById('paperModeratorPinInput');
    const markerPasscode = markerInput ? markerInput.value.trim() : '1132';
    const moderatorPin = modInput ? modInput.value.trim() : 'MOD88';

    if (!markerPasscode || !moderatorPin) {
      alert('Marker Passcode and KP Moderator PIN cannot be empty.');
      return;
    }

    const activeExam = db.getActiveExam();
    const res = db.updatePaperSecurity(activeExam.id, { markerPasscode, moderatorPin });
    if (res.success) {
      markerApp.showToast(`Saved security keys for "${activeExam.title}"! Marker: ${markerPasscode} | KP PIN: ${moderatorPin}`, 'success');
      this.renderPaperSecurityCard();
      this.renderPapersHub();
      if (typeof syncService !== 'undefined' && syncService.isConnected()) {
        syncService.publishSingleExam(activeExam.id);
      }
    } else {
      alert(`Could not save passcodes: ${res.error}`);
    }
  }

  generateRandomPaperPin() {
    const modInput = document.getElementById('paperModeratorPinInput');
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const newPin = `MOD${randomDigits}`;
    if (modInput) {
      modInput.value = newPin;
      markerApp.showToast(`Generated secure KP PIN: ${newPin}. Click "Save Paper Passcodes" to apply.`, 'info');
    }
  }

  toggleMarkerKP(code, isChecked) {
    db.setMarkerKP(code, isChecked);
    markerApp.showToast(`Updated KP rights for ${code}: ${isChecked ? 'Granted' : 'Revoked'}`);
    this.renderMarkersList();
  }

  openAddMarkerModal() {
    const modal = document.getElementById('addMarkerModal');
    if (modal) {
      const state = db.getState();
      const nextCode = `M${String(state.markers.length + 1).padStart(2, '0')}`;
      document.getElementById('addMarkerCode').value = nextCode;
      document.getElementById('addMarkerName').value = '';
      modal.classList.remove('hidden');
      document.getElementById('addMarkerName').focus();
    }
  }

  closeAddMarkerModal() {
    const modal = document.getElementById('addMarkerModal');
    if (modal) modal.classList.add('hidden');
  }

  submitAddMarker() {
    const code = document.getElementById('addMarkerCode').value.trim().toUpperCase();
    const name = document.getElementById('addMarkerName').value.trim();

    if (!code || !name) {
      alert('Please fill in both Marker Code and Teacher Name.');
      return;
    }

    const res = db.addMarker(code, name);
    if (res.success) {
      this.closeAddMarkerModal();
      this.populateFilterDropdowns();
      this.renderMarkersList();
      markerApp.showToast(`Marker ${code} (${name}) registered!`);
    } else {
      alert(res.error);
    }
  }

  editMarker(code) {
    const marker = db.getState().markers.find(m => m.code === code);
    if (!marker) return;

    const newName = prompt(`Edit Teacher Name for Marker ${code}:`, marker.name);
    if (newName && newName.trim() !== '') {
      db.updateMarker(code, newName.trim());
      this.populateFilterDropdowns();
      this.renderMarkersList();
      this.renderConsolidationTable();
      markerApp.showToast(`Marker ${code} updated to ${newName.trim()}!`);
    }
  }

  deleteMarker(code) {
    const state = db.getState();
    const marker = state.markers.find(m => m.code === code);
    if (!marker) return;

    const markedCount = state.students.filter(s => s.markerCode === code && s.score && s.score.total !== null).length;
    let confirmMsg = `Are you sure you want to remove Marker ${code} (${marker.name})?`;
    if (markedCount > 0) {
      confirmMsg = `⚠️ Marker ${code} has already marked ${markedCount} scripts.\nRemoving this marker will keep the student marks but clear the marker assignment.\n\nProceed with removal?`;
    }

    if (confirm(confirmMsg)) {
      db.deleteMarker(code);
      this.populateFilterDropdowns();
      this.renderMarkersList();
      this.renderConsolidationTable();
      markerApp.showToast(`Marker ${code} removed.`);
    }
  }

  confirmClearMarkers() {
    const count = db.getState().markers.length;
    if (count === 0) return;

    if (confirm(`⚠️ Are you sure you want to remove all ${count} markers?`)) {
      db.getState().markers.slice().forEach(m => db.deleteMarker(m.code));
      this.populateFilterDropdowns();
      this.renderMarkersList();
      this.renderConsolidationTable();
      markerApp.showToast('All markers cleared.');
    }
  }

  renderSettingsForm() {
    const state = db.getState();
    const config = state.config;

    document.getElementById('cfgExamTitle').value = config.examTitle;
    document.getElementById('cfgLevel').value = config.level;
    document.getElementById('cfgSubject').value = config.subject;
    document.getElementById('cfgPresetSelector').value = config.presetId || 'CUSTOM';
    document.getElementById('cfgContentMax').value = config.contentMax;
    document.getElementById('cfgLanguageMax').value = config.languageMax;
    document.getElementById('cfgPassPct').value = config.passCutoffPct;
    document.getElementById('cfgQualityPct').value = config.qualityCutoffPct;
    document.getElementById('cfgBlindModeToggle').checked = !!config.blindMode;
  }

  applyPreset(presetId) {
    const preset = SECS_CONFIG.PRESETS[presetId];
    if (preset) {
      document.getElementById('cfgContentMax').value = preset.contentMax;
      document.getElementById('cfgLanguageMax').value = preset.languageMax;
      document.getElementById('cfgLevel').value = preset.level;
      document.getElementById('cfgSubject').value = preset.subject;
    }
  }

  saveSettings() {
    const title = document.getElementById('cfgExamTitle').value.trim();
    const level = document.getElementById('cfgLevel').value.trim();
    const subject = document.getElementById('cfgSubject').value.trim();
    const presetId = document.getElementById('cfgPresetSelector').value;
    const contentMax = Number(document.getElementById('cfgContentMax').value);
    const languageMax = Number(document.getElementById('cfgLanguageMax').value);
    const passPct = Number(document.getElementById('cfgPassPct').value);
    const qualityPct = Number(document.getElementById('cfgQualityPct').value);
    const blindMode = document.getElementById('cfgBlindModeToggle').checked;

    db.updateConfig({
      examTitle: title,
      level,
      subject,
      presetId,
      contentMax,
      languageMax,
      passCutoffPct: passPct,
      qualityCutoffPct: qualityPct,
      blindMode
    });

    markerApp.renderMarkerHeader();
    this.renderActiveTab();
    markerApp.showToast('Examination rubrics and settings updated successfully!');
  }

  restoreDefaultDemoData() {
    if (confirm('Reset entire system database to default realistic demo cohort? Any unsaved custom entries will be reset.')) {
      db.resetDemo();
      this.populateFilterDropdowns();
      this.renderActiveTab();
      markerApp.renderMarkerHeader();
      markerApp.renderStudentList();
      markerApp.renderRecentMarkedTable();
      markerApp.showToast('Database reset to realistic P4 Mother Tongue demo dataset.');
    }
  }

  populateExportClassDropdown() {
    const select = document.getElementById('exportClassSelect');
    if (!select) return;

    const state = db.getState();
    const students = state.students;

    const formClasses = [...new Set(students.map(s => s.formClass).filter(Boolean))].sort();
    const mtClasses = [...new Set(students.map(s => s.mtClass).filter(Boolean))].sort();

    let html = '';
    if (formClasses.length > 0) {
      html += `<optgroup label="Form Classes">`;
      formClasses.forEach(fc => {
        const count = students.filter(s => s.formClass === fc).length;
        html += `<option value="formClass:${fc}">${fc} (${count} students)</option>`;
      });
      html += `</optgroup>`;
    }

    if (mtClasses.length > 0) {
      html += `<optgroup label="Mother Tongue Classes (Banded)">`;
      mtClasses.forEach(mc => {
        const count = students.filter(s => s.mtClass === mc).length;
        html += `<option value="mtClass:${mc}">${mc} (${count} students)</option>`;
      });
      html += `</optgroup>`;
    }

    if (formClasses.length === 0 && mtClasses.length === 0) {
      html = `<option value="">No classes found in roster</option>`;
    }

    select.innerHTML = html;
  }

  handleExportScopeChange() {
    const radioCohort = document.getElementById('exportScopeCohort');
    const isCohort = radioCohort ? radioCohort.checked : true;
    this.exportScope = isCohort ? 'cohort' : 'class';

    const container = document.getElementById('exportClassSelectContainer');
    const cohortBadge = document.getElementById('exportCohortSummary');
    const labelCohort = document.getElementById('labelScopeCohort');
    const labelClass = document.getElementById('labelScopeClass');
    const select = document.getElementById('exportClassSelect');
    const summary = document.getElementById('exportScopeSummary');

    // Card titles and buttons
    const excelDesc = document.getElementById('exportExcelDesc');
    const wordDesc = document.getElementById('exportWordDesc');
    const pdfDesc = document.getElementById('exportPdfDesc');
    const excelTitle = document.getElementById('exportExcelTitle');
    const wordTitle = document.getElementById('exportWordTitle');
    const pdfTitle = document.getElementById('exportPdfTitle');
    const btnExcelText = document.getElementById('btnExportExcelText');
    const btnWordText = document.getElementById('btnExportWordText');
    const btnPdfText = document.getElementById('btnPrintPdfText');

    const isClassTeacher = (this.reportType === 'classTeacher');

    if (isCohort) {
      if (container) container.classList.add('hidden');
      if (cohortBadge) cohortBadge.classList.remove('hidden');
      if (labelCohort) {
        labelCohort.classList.add('bg-white', 'shadow-xs');
        labelClass.classList.remove('bg-white', 'shadow-xs');
      }

      if (isClassTeacher) {
        if (excelTitle) excelTitle.textContent = 'All Classes Diagnostic (.xlsx)';
        if (excelDesc) excelDesc.textContent = 'Simplified spreadsheet for form & subject teachers: pupil marks (content, language, total), moderation delta, feedback tags, and class vs cohort benchmarks.';
        if (btnExcelText) btnExcelText.textContent = 'Download All Classes Diagnostic (.xlsx)';

        if (wordTitle) wordTitle.textContent = 'All Classes Diagnostic Report (.doc)';
        if (wordDesc) wordDesc.textContent = 'Pre-formatted Word document with cohort benchmarking, writing strength & error gap analysis, and pupil diagnostic marks.';
        if (btnWordText) btnWordText.textContent = 'Download All Classes Diagnostic (.doc)';

        if (pdfTitle) pdfTitle.textContent = 'Print / Save All Classes Diagnostic (PDF)';
        if (pdfDesc) pdfDesc.textContent = 'Print-ready diagnostic brief formatted for form teachers, classroom data analysis, and pedagogical review.';
        if (btnPdfText) btnPdfText.textContent = 'Print / Save All Classes Diagnostic (PDF)';
      } else {
        if (excelTitle) excelTitle.textContent = 'Comprehensive HOD Workbook (.xlsx)';
        if (excelDesc) excelDesc.textContent = 'Multi-sheet workbook containing Master Consolidated Marks, Item Analysis, Class Breakdowns, Moderation Audit, and Marker Calibration.';
        if (btnExcelText) btnExcelText.textContent = 'Download Cohort Excel';

        if (wordTitle) wordTitle.textContent = 'Department Review (.doc)';
        if (wordDesc) wordDesc.textContent = 'Pre-formatted Word Document for post-examination review minutes, statistical tables, and HOD signature block.';
        if (btnWordText) btnWordText.textContent = 'Download Cohort Word Report';

        if (pdfTitle) pdfTitle.textContent = 'Print / PDF Summary';
        if (pdfDesc) pdfDesc.textContent = 'Print-ready executive summary sheet formatted for school management and archiving.';
        if (btnPdfText) btnPdfText.textContent = 'Print Cohort Summary';
      }

    } else {
      if (container) container.classList.remove('hidden');
      if (cohortBadge) cohortBadge.classList.add('hidden');
      if (labelClass) {
        labelClass.classList.add('bg-white', 'shadow-xs');
        labelCohort.classList.remove('bg-white', 'shadow-xs');
      }

      const val = select ? select.value : '';
      if (val && val.includes(':')) {
        const parts = val.split(':');
        this.exportSelectedClassType = parts[0];
        this.exportSelectedClass = parts[1];
      } else {
        this.exportSelectedClass = '';
      }

      const state = db.getState();
      const targetStudents = state.students.filter(s => s[this.exportSelectedClassType] === this.exportSelectedClass);
      const classStats = analytics.computeCohortStats(targetStudents, state.config);
      const cohortStats = analytics.computeCohortStats(state.students, state.config);
      const deltaMean = Math.round((classStats.mean - cohortStats.mean) * 10) / 10;

      if (summary) {
        summary.innerHTML = `
          <div class="flex items-center justify-between">
            <span class="font-bold text-sky-950">${this.exportSelectedClass} (${this.exportSelectedClassType === 'formClass' ? 'Form Class' : 'MT Class'})</span>
            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${classStats.totalMarked === classStats.totalCandidature ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
              ${classStats.totalMarked}/${classStats.totalCandidature} Marked
            </span>
          </div>
          <div class="mt-1 text-[11px] text-sky-800 flex flex-wrap gap-x-3">
            <span>Mean: <strong>${classStats.mean}</strong> (${deltaMean >= 0 ? '+' : ''}${deltaMean} vs cohort)</span>
            <span>Pass: <strong>${classStats.passPct}%</strong></span>
            <span>Quality: <strong>${classStats.qualityPct}%</strong></span>
            <span>PAR: <strong class="${classStats.parCount > 0 ? 'text-rose-700' : ''}">${classStats.parCount}</strong></span>
          </div>
        `;
      }

      if (isClassTeacher) {
        if (excelTitle) excelTitle.textContent = `${this.exportSelectedClass} Diagnostic Spreadsheet (.xlsx)`;
        if (excelDesc) excelDesc.textContent = `Simplified spreadsheet for ${this.exportSelectedClass}: pupil marks (Content, Language, Total), moderation delta, feedback tags, and class vs cohort benchmarks.`;
        if (btnExcelText) btnExcelText.textContent = `Download ${this.exportSelectedClass} Diagnostic (.xlsx)`;

        if (wordTitle) wordTitle.textContent = `${this.exportSelectedClass} Diagnostic Report (.doc)`;
        if (wordDesc) wordDesc.textContent = `Full class-level diagnostic report with writing strengths, error gap analysis, pupil-by-pupil marks roster, and pedagogical action plan.`;
        if (btnWordText) btnWordText.textContent = `Download ${this.exportSelectedClass} Diagnostic (.doc)`;

        if (pdfTitle) pdfTitle.textContent = `Print / Save ${this.exportSelectedClass} Diagnostic (PDF)`;
        if (pdfDesc) pdfDesc.textContent = `Print-formatted diagnostic sheet specifically for ${this.exportSelectedClass} teachers, classroom analysis, and parent conferencing.`;
        if (btnPdfText) btnPdfText.textContent = `Print / Save ${this.exportSelectedClass} Diagnostic (PDF)`;
      } else {
        if (excelTitle) excelTitle.textContent = `${this.exportSelectedClass} Marks & Feedback (.xlsx)`;
        if (excelDesc) excelDesc.textContent = `Includes Class Marks Roster, Class vs Cohort Diagnostics, Moderation Audit, and Marker Reliability.`;
        if (btnExcelText) btnExcelText.textContent = `Download ${this.exportSelectedClass} Excel`;

        if (wordTitle) wordTitle.textContent = `${this.exportSelectedClass} Diagnostic Report (.doc)`;
        if (wordDesc) wordDesc.textContent = `Full class-level audit review with Qualitative Feedback Analysis, moderation audit, and official signature block.`;
        if (btnWordText) btnWordText.textContent = `Download ${this.exportSelectedClass} Word Report`;

        if (pdfTitle) pdfTitle.textContent = `${this.exportSelectedClass} Print / PDF`;
        if (pdfDesc) pdfDesc.textContent = `Print-formatted diagnostic sheet specifically for ${this.exportSelectedClass} teachers and HOD audit.`;
        if (btnPdfText) btnPdfText.textContent = `Print ${this.exportSelectedClass} Summary`;
      }
    }
  }

  handleReportTypeChange() {
    const radioClassTeacher = document.getElementById('reportTypeClassTeacher');
    const isClassTeacher = radioClassTeacher ? radioClassTeacher.checked : false;
    this.reportType = isClassTeacher ? 'classTeacher' : 'hod';

    const noticeEl = document.getElementById('classTeacherReportNotice');
    const sectionsContainer = document.getElementById('hodReportSectionsContainer');
    const labelClassTeacher = document.getElementById('labelReportTypeClassTeacher');
    const labelHOD = document.getElementById('labelReportTypeHOD');

    if (isClassTeacher) {
      if (noticeEl) noticeEl.classList.remove('hidden');
      if (sectionsContainer) sectionsContainer.classList.add('hidden');
      if (labelClassTeacher) {
        labelClassTeacher.classList.add('bg-white', 'shadow-xs');
        labelHOD.classList.remove('bg-white', 'shadow-xs');
      }
    } else {
      if (noticeEl) noticeEl.classList.add('hidden');
      if (sectionsContainer) sectionsContainer.classList.remove('hidden');
      if (labelHOD) {
        labelHOD.classList.add('bg-white', 'shadow-xs');
        labelClassTeacher.classList.remove('bg-white', 'shadow-xs');
      }
    }

    this.handleExportScopeChange();
  }

  toggleAllReportSections(select) {
    const ids = ['chkSecExecutive', 'chkSecDescriptive', 'chkSecClassComp', 'chkSecBands', 'chkSecTags', 'chkSecModeration', 'chkSecCalibration', 'chkSecRoster'];
    ids.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.checked = !!select;
    });
  }

  getSelectedSections() {
    return {
      executive: document.getElementById('chkSecExecutive')?.checked ?? true,
      descriptive: document.getElementById('chkSecDescriptive')?.checked ?? true,
      classComp: document.getElementById('chkSecClassComp')?.checked ?? true,
      bands: document.getElementById('chkSecBands')?.checked ?? true,
      tags: document.getElementById('chkSecTags')?.checked ?? true,
      moderation: document.getElementById('chkSecModeration')?.checked ?? true,
      calibration: document.getElementById('chkSecCalibration')?.checked ?? true,
      roster: document.getElementById('chkSecRoster')?.checked ?? true
    };
  }

  toggleMarkingLock() {
    const activeExam = db.getActiveExam();
    if (activeExam) {
      this.toggleLockForExam(activeExam.id);
    }
  }

  async toggleLockForExam(examId) {
    if (!auth || !auth.isHOD()) {
      alert('Access Denied: Only HOD can freeze or reopen examination papers.');
      return;
    }

    const exams = db.getExamsList();
    const target = exams.find(e => e.id === examId) || db.getActiveExam();
    if (!target) return;

    const isCurrentlyLocked = !!(target.markingLocked || target.isLocked);
    const actionPrompt = isCurrentlyLocked
      ? `🔓 UNLOCK MARKING FOR "${target.title}"?\n\nThis will allow markers to resume scoring and amending marks for this specific examination paper.\n\nProceed to reopen?`
      : `🔒 FREEZE MARKING FOR "${target.title}"?\n\nThis will put marking for "${target.title}" into READ-ONLY mode for markers.\nOther active examination papers will NOT be affected.\nMarkers can still view scripts, but scoring is disabled.\n\nProceed to freeze?`;

    if (confirm(actionPrompt)) {
      const newLockState = db.toggleMarkingLockForExam(target.id);
      this.renderLockControls();
      this.renderExecutivePaperDeck();
      this.renderPapersHub();
      this.renderActivePaperWorkspaceHeader();

      // Automatically broadcast updated lock state to Shared Folder
      if (typeof syncService !== 'undefined' && syncService.isConnected()) {
        await syncService.publishSingleExam(target.id);
      }

      if (typeof markerApp !== 'undefined') {
        markerApp.renderMarkerHeader();
        if (markerApp.selectedStudentId) {
          markerApp.selectStudent(markerApp.selectedStudentId);
        }
      }
      markerApp.showToast(newLockState 
        ? `🔒 "${target.title}" marking is now FROZEN (Read-Only).` 
        : `🟢 "${target.title}" marking is now OPEN for edits.`
      );
    }
  }

  autoPublishActiveExamIfConnected() {
    if (typeof syncService !== 'undefined' && syncService.isConnected()) {
      const activeExam = db.getActiveExam();
      if (activeExam) {
        syncService.publishSingleExam(activeExam.id);
      }
    }
  }

  renderLockControls() {
    const isLocked = !!db.getState().config.markingLocked;
    const badge = document.getElementById('hodLockStatusBadge');
    const statusText = document.getElementById('hodLockStatusText');
    const btn = document.getElementById('hodToggleLockBtn');
    const btnText = document.getElementById('hodToggleLockBtnText');
    const controlsContainer = document.getElementById('hodLockControls');

    if (controlsContainer) {
      if (typeof auth !== 'undefined' && auth.session && auth.session.role === 'hod') {
        controlsContainer.classList.remove('hidden');
        controlsContainer.classList.add('flex');
      } else {
        controlsContainer.classList.add('hidden');
        controlsContainer.classList.remove('flex');
      }
    }

    if (isLocked) {
      if (badge) badge.className = 'px-2.5 py-1 text-xs font-bold rounded-lg border bg-amber-50 text-amber-800 border-amber-300 flex items-center gap-1.5';
      if (statusText) statusText.textContent = 'Marking Frozen (Read-Only)';
      if (btn) btn.className = 'px-2.5 py-1 text-xs font-bold rounded-lg border border-sky-600 bg-sky-600 hover:bg-sky-700 text-white cursor-pointer shadow-2xs transition-colors flex items-center gap-1';
      if (btnText) btnText.textContent = '🔓 Unlock Marking';
    } else {
      if (badge) badge.className = 'px-2.5 py-1 text-xs font-bold rounded-lg border bg-emerald-50 text-emerald-700 border-emerald-200 flex items-center gap-1.5';
      if (statusText) statusText.textContent = 'Marking Active';
      if (btn) btn.className = 'px-2.5 py-1 text-xs font-bold rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer shadow-2xs transition-colors flex items-center gap-1';
      if (btnText) btnText.textContent = '🔒 Lock Marking';
    }
  }

  getExportScopeOptions() {
    return {
      reportType: this.reportType || 'hod',
      scope: this.exportScope || 'cohort',
      classType: this.exportSelectedClassType || 'formClass',
      className: this.exportSelectedClass || '',
      sections: this.getSelectedSections()
    };
  }

  triggerExportExcel() {
    const state = db.getState();
    const scopeOptions = this.getExportScopeOptions();
    if (scopeOptions.scope === 'class' && !scopeOptions.className) {
      alert('Please select a target class first.');
      return;
    }
    exporter.exportToExcel(state.students, state.config, state.markers, scopeOptions);
  }

  triggerExportWord() {
    const state = db.getState();
    const scopeOptions = this.getExportScopeOptions();
    if (scopeOptions.scope === 'class' && !scopeOptions.className) {
      alert('Please select a target class first.');
      return;
    }
    exporter.exportToWord(state.students, state.config, state.markers, scopeOptions);
  }

  triggerPrintPdf() {
    const scopeOptions = this.getExportScopeOptions();
    if (scopeOptions.scope === 'class' && !scopeOptions.className) {
      alert('Please select a target class first.');
      return;
    }
    exporter.printPdfReport(scopeOptions);
  }

  triggerShareEmail() {
    const state = db.getState();
    const scopeOptions = this.getExportScopeOptions();
    exporter.shareSummary(state.students, state.config, scopeOptions);
  }
  // =========================================================================
  // MULTI-EXAM REGISTRY & COHORT MANAGEMENT
  // =========================================================================
  renderExamSelector() {
    if (typeof app !== 'undefined' && app.renderGlobalExamSelector) {
      app.renderGlobalExamSelector();
      return;
    }
    const selector = document.getElementById('globalExamSelect');
    const exams = db.getExamsList();
    const active = db.getActiveExam();

    if (selector) {
      selector.innerHTML = exams.map(e => `
        <option value="${e.id}" ${e.id === active.id ? 'selected' : ''}>
          ${e.level} - ${e.subject} (${e.totalStudents} pupils, ${e.markedCount} marked)
        </option>
      `).join('');
    }
  }

  handleExamSwitch(examId) {
    if (!examId) return;
    db.switchExam(examId);
    this.renderExamSelector();
    this.populateFilterDropdowns();
    this.renderLockControls();
    this.renderActiveTab();
    this.renderOverviewStats();
    markerApp.populateClassFilters();
    markerApp.renderStudentList();
    markerApp.renderMarkerHeader();
    markerApp.renderClassProgressBar();
    markerApp.renderRecentMarkedTable();
    markerApp.showToast(`Switched active exam to: ${db.getActiveExam().title}`);
  }

  openManageExamsModal() {
    if (!auth || !auth.isHOD()) {
      if (typeof app !== 'undefined' && app.showToast) {
        app.showToast('Access Denied: Only HOD can configure Examination Papers & Cohorts.', 'error');
      } else {
        alert('Access Denied: Only HOD can configure Examination Papers & Cohorts.');
      }
      return;
    }
    const modal = document.getElementById('manageExamsModal');
    if (!modal) return;
    this.renderManageExamsTable();
    this.populateCopyMarkersDropdown();
    this.populateCopyRosterDropdown();
    modal.classList.remove('hidden');
  }

  closeManageExamsModal() {
    const modal = document.getElementById('manageExamsModal');
    if (modal) modal.classList.add('hidden');
  }

  renderManageExamsTable() {
    const tbody = document.getElementById('manageExamsTableBody');
    if (!tbody) return;

    const exams = db.getExamsList();
    const active = db.getActiveExam();

    tbody.innerHTML = exams.map(e => {
      const isActive = e.id === active.id;
      let statusBadge = '';
      if (isActive) {
        statusBadge = `<span class="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">✓ Active Exam</span>`;
      } else if (e.isArchived) {
        statusBadge = `<span class="px-2.5 py-1 rounded-full bg-purple-100 text-purple-800 font-bold text-[11px]">📦 Archived</span>`;
      } else {
        statusBadge = `<button onclick="hodApp.handleExamSwitch('${e.id}'); hodApp.renderManageExamsTable();" class="px-2.5 py-1 bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold text-xs rounded-lg border border-sky-200 cursor-pointer shadow-2xs">Switch To</button>`;
      }

      return `
        <tr class="${isActive ? 'bg-sky-50/50 font-medium' : 'hover:bg-slate-50'} border-b border-slate-100 text-xs">
          <td class="p-3">
            <span class="font-bold text-slate-800 block text-sm">${e.title}</span>
            <div class="text-[11px] text-slate-500 mt-0.5">${e.level} | ${e.subject} | ${e.paper}</div>
          </td>
          <td class="p-3 font-mono text-center font-bold text-slate-700">${e.totalStudents}</td>
          <td class="p-3 text-center">
            <span class="font-bold font-mono text-sky-700">${e.markedCount} / ${e.totalStudents}</span>
            <span class="text-[11px] text-slate-400 block">${e.progressPct}%</span>
          </td>
          <td class="p-3 font-mono text-center">${e.markersCount}</td>
          <td class="p-3 text-center">${statusBadge}</td>
          <td class="p-3 text-right space-x-1 whitespace-nowrap">
            <button onclick="hodApp.openEditExamModal('${e.id}')" class="p-1.5 hover:bg-slate-200 rounded text-slate-600 cursor-pointer" title="Edit Paper Metadata & Rubrics">✏️</button>
            <button onclick="${e.isArchived ? `hodApp.unarchiveExam('${e.id}')` : `hodApp.archiveExam('${e.id}')`}" class="p-1.5 hover:bg-amber-100 text-amber-700 rounded cursor-pointer" title="${e.isArchived ? 'Restore Paper to Active' : 'Archive Paper'}">${e.isArchived ? '🔄' : '📦'}</button>
            <button onclick="hodApp.duplicateExam('${e.id}')" class="p-1.5 hover:bg-slate-200 rounded text-slate-600 cursor-pointer" title="Duplicate / Clone Exam Setup">📋</button>
            ${exams.length > 1 ? `<button onclick="hodApp.deleteExam('${e.id}')" class="p-1.5 hover:bg-rose-100 text-rose-600 rounded cursor-pointer" title="Delete Exam">🗑️</button>` : ''}
          </td>
        </tr>
      `;
    }).join('');
  }

  // =========================================================================
  // EXECUTIVE PAPER CONTROL DECK & PAPERS ARCHIVAL VAULT
  // =========================================================================
  renderExecutivePaperDeck() {
    const active = db.getActiveExam();
    if (!active) return;
    const isLocked = !!active.config.markingLocked;
    const isArchived = !!active.isArchived;

    const levelBadge = document.getElementById('deckLevelBadge');
    const subjectBadge = document.getElementById('deckSubjectBadge');
    const componentBadge = document.getElementById('deckComponentBadge');
    const statusBadge = document.getElementById('deckStatusBadge');
    const examTitle = document.getElementById('deckExamTitle');
    const rubricMaxLabel = document.getElementById('deckRubricMaxLabel');
    const pupilsCount = document.getElementById('deckPupilsCount');
    const markedPct = document.getElementById('deckMarkedPct');
    const lockBtnText = document.getElementById('deckToggleLockBtnText');
    const archiveBtnText = document.getElementById('deckArchiveBtnText');

    if (levelBadge) levelBadge.textContent = active.config.level || 'Primary Level';
    if (subjectBadge) subjectBadge.textContent = active.config.subject || 'Mother Tongue';
    if (componentBadge) componentBadge.textContent = active.config.paper || 'Paper 1';
    if (examTitle) examTitle.textContent = active.title || 'Paper 1 (Writing)';
    if (rubricMaxLabel) rubricMaxLabel.textContent = `${active.config.totalMax} Max (${active.config.contentMax}C + ${active.config.languageMax || active.config.langMax || 8}L)`;

    const totalStudents = active.students ? active.students.length : 0;
    const markedCount = active.students ? active.students.filter(s => s.score && s.score.total !== null).length : 0;
    const pct = totalStudents > 0 ? Math.round((markedCount / totalStudents) * 100) : 0;

    if (pupilsCount) pupilsCount.textContent = `${totalStudents} pupils`;
    if (markedPct) markedPct.textContent = `${markedCount} / ${totalStudents} (${pct}%)`;

    if (statusBadge) {
      if (isArchived) {
        statusBadge.className = 'px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-500/30 text-purple-200 border border-purple-400/40';
        statusBadge.textContent = '📦 Archived Paper';
      } else if (isLocked) {
        statusBadge.className = 'px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30';
        statusBadge.textContent = '🔒 Marking Frozen';
      } else {
        statusBadge.className = 'px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30';
        statusBadge.textContent = '🟢 Active Marking';
      }
    }

    if (lockBtnText) {
      lockBtnText.textContent = isLocked ? '🔓 Unlock Marking' : '🔒 Lock Marking';
    }

    if (archiveBtnText) {
      archiveBtnText.textContent = isArchived ? '🔄 Restore Paper' : '📦 Archive Paper';
    }
  }

  renderRegisterPaperTab() {
    this.populateCopyMarkersDropdownForHub();
    this.populateCopyRosterDropdownForHub();
    const titleInput = document.getElementById('hubNewExamTitle');
    if (titleInput && !titleInput.value) {
      titleInput.placeholder = 'e.g. 2026 Primary 4 Mid-Year Exam: Mother Tongue Paper 1';
    }
  }

  switchPapersHubSubtab(subtab) {
    if (subtab === 'create') {
      this.switchTab('tabRegisterPaper');
      return;
    }
    this.papersHubSubtab = subtab;
    const activeSection = document.getElementById('papersHubActiveSection');
    const archivedSection = document.getElementById('papersHubArchivedSection');

    const btnActive = document.getElementById('subtabActivePapersBtn');
    const btnArchived = document.getElementById('subtabArchivedPapersBtn');

    if (btnActive) {
      btnActive.className = subtab === 'active' 
        ? 'px-3 py-1.5 rounded-lg bg-white shadow-xs text-sky-700 font-bold transition-all cursor-pointer'
        : 'px-3 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition-all cursor-pointer';
    }
    if (btnArchived) {
      btnArchived.className = subtab === 'archived'
        ? 'px-3 py-1.5 rounded-lg bg-white shadow-xs text-purple-700 font-bold transition-all cursor-pointer'
        : 'px-3 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition-all cursor-pointer';
    }

    if (activeSection) activeSection.classList.toggle('hidden', subtab !== 'active');
    if (archivedSection) archivedSection.classList.toggle('hidden', subtab !== 'archived');
  }

  populateCopyMarkersDropdownForHub() {
    const sel = document.getElementById('hubNewExamCopyMarkersSelect');
    if (!sel) return;
    const exams = db.getExamsList();
    sel.innerHTML = '<option value="">-- Use Default 4 Markers (M01-M04) --</option>' + 
      exams.map(e => `<option value="${e.id}">Copy marker team from: ${e.title} (${e.markersCount} markers)</option>`).join('');
  }

  populateCopyRosterDropdownForHub() {
    const sel = document.getElementById('hubNewExamCopyRosterSelect');
    if (!sel) return;
    const exams = db.getExamsList();
    sel.innerHTML = '<option value="">-- Start with Empty Roster (Add or upload later) --</option>' + 
      exams.map(e => `<option value="${e.id}">Copy roster from: ${e.title} (${e.totalStudents} pupils)</option>`).join('');
  }

  submitCreateNewExamFromHub() {
    if (!auth || !auth.isHOD()) {
      if (typeof app !== 'undefined' && app.showToast) {
        app.showToast('Access Denied: Only HOD can register new examination papers.', 'error');
      } else {
        alert('Access Denied: Only HOD can register new examination papers.');
      }
      return;
    }

    const titleInput = document.getElementById('hubNewExamTitle');
    const levelInput = document.getElementById('hubNewExamLevel');
    const subjectInput = document.getElementById('hubNewExamSubject');
    const paperInput = document.getElementById('hubNewExamPaper');
    const presetSelect = document.getElementById('hubNewExamPreset');
    const copySelect = document.getElementById('hubNewExamCopyMarkersSelect');
    const copyRosterSelect = document.getElementById('hubNewExamCopyRosterSelect');

    const title = titleInput ? titleInput.value.trim() : '';
    const level = levelInput ? levelInput.value.trim() : 'Primary 5';
    const subject = subjectInput ? subjectInput.value.trim() : 'Mother Tongue';
    const paper = paperInput ? paperInput.value.trim() : 'Paper 1 (Writing)';
    const presetId = presetSelect ? presetSelect.value : 'P3_P4_MT';
    const copyFrom = copySelect ? copySelect.value : '';
    const copyRosterFrom = copyRosterSelect ? copyRosterSelect.value : '';

    if (!title) {
      alert('Please enter an Examination Title.');
      if (titleInput) titleInput.focus();
      return;
    }

    const newExam = db.createExam({
      title,
      level,
      subject,
      paper,
      presetId,
      copyMarkersFrom: copyFrom,
      copyRosterFrom: copyRosterFrom
    });

    // Switch to Exam Studio to view & manage the newly created paper
    this.switchTab('tabExamStudio');
    this.switchPapersHubSubtab('active');
    this.renderExamSelector();
    this.populateFilterDropdowns();
    this.renderLockControls();
    this.renderExecutivePaperDeck();
    this.renderPapersHub();
    this.renderActiveTab();
    this.renderOverviewStats();
    if (typeof markerApp !== 'undefined') {
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
      markerApp.renderMarkerHeader();
      markerApp.renderClassProgressBar();
      markerApp.renderRecentMarkedTable();
    }
    if (typeof app !== 'undefined' && app.showToast) {
      app.showToast(`🎉 Successfully registered new paper: ${newExam.title}!`, 'success');
    }

    const autoPublish = document.getElementById('hubNewExamAutoPublish');
    const shouldAutoPub = autoPublish ? autoPublish.checked : true;

    if (shouldAutoPub && typeof syncService !== 'undefined' && syncService.isConnected()) {
      syncService.publishSingleExam(newExam.id);
    } else if (typeof syncService !== 'undefined' && syncService.isConnected()) {
      syncService.publishExamMaster();
    }

    if (titleInput) titleInput.value = '';
  }

  renderPapersHub() {
    const exams = db.getExamsList();
    const activeExam = db.getActiveExam();
    const activeExams = exams.filter(e => !e.isArchived);
    const archivedExams = exams.filter(e => !!e.isArchived);

    const activeCountEl = document.getElementById('papersHubActiveCount');
    const archivedCountEl = document.getElementById('papersHubArchivedCount');
    if (activeCountEl) activeCountEl.textContent = activeExams.length;
    if (archivedCountEl) archivedCountEl.textContent = archivedExams.length;

    // Update Cohort Sync Summary Pill in Exam Studio Header
    const summaryPill = document.getElementById('studioCohortSyncSummaryPill');
    const summaryText = document.getElementById('studioCohortSyncSummaryText');
    if (summaryText) {
      if (typeof syncService === 'undefined' || !syncService.isConnected()) {
        summaryText.textContent = '📁 Shared Folder Not Linked';
        if (summaryPill) {
          summaryPill.className = 'px-3 py-1.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs font-semibold text-amber-300 flex items-center gap-1.5';
        }
      } else {
        const publishedCount = activeExams.filter(e => syncService.getPaperPublishStatus(e.id).isPublished).length;
        if (publishedCount === activeExams.length && activeExams.length > 0) {
          summaryText.textContent = `🟢 All ${publishedCount} Papers Published to Shared Drive`;
          if (summaryPill) {
            summaryPill.className = 'px-3 py-1.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs font-semibold text-emerald-300 flex items-center gap-1.5';
          }
        } else {
          summaryText.textContent = `⚠️ ${publishedCount} of ${activeExams.length} Papers Published (${activeExams.length - publishedCount} Draft)`;
          if (summaryPill) {
            summaryPill.className = 'px-3 py-1.5 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs font-semibold text-amber-300 flex items-center gap-1.5';
          }
        }
      }
    }

    // Render active papers list
    const activeContainer = document.getElementById('activePapersList');
    if (activeContainer) {
      if (activeExams.length === 0) {
        activeContainer.innerHTML = `
          <div class="col-span-full p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300">
            <div class="text-3xl mb-2">📁</div>
            <h5 class="text-sm font-bold text-slate-700">No Active Papers</h5>
            <p class="text-xs text-slate-500 mt-1">Register a new examination paper to start marking.</p>
            <button onclick="hodApp.switchPapersHubSubtab('create')" class="mt-3 px-4 py-2 bg-sky-600 text-white font-bold rounded-xl text-xs cursor-pointer">
              + Register New Paper
            </button>
          </div>
        `;
      } else {
        activeContainer.innerHTML = activeExams.map(e => {
          const isSelected = e.id === activeExam.id;
          const isExamLocked = !!(e.markingLocked || e.isLocked || (e.config && e.config.markingLocked));

          const pubStatus = (typeof syncService !== 'undefined') 
            ? syncService.getPaperPublishStatus(e.id) 
            : { isConnected: false, isPublished: false };

          // 1. Marking Lock Status Badge
          let lockBadge = '';
          if (isExamLocked) {
            lockBadge = `<span class="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-extrabold flex items-center gap-1" title="Marking is currently frozen in Read-Only mode"><span>🔒</span> Frozen</span>`;
          } else {
            lockBadge = `<span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold flex items-center gap-1" title="Marking is active and open for scoring"><span>🟢</span> Active</span>`;
          }

          // 2. Shared Folder Publication Badge
          let publishBadge = '';
          if (!pubStatus.isConnected) {
            publishBadge = `<span class="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-300 text-[10px] font-bold" title="Link Shared Folder to enable multi-device sync">📁 Local Only</span>`;
          } else if (pubStatus.isPublished) {
            publishBadge = `<span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold flex items-center gap-1" title="Published to Shared Folder - Ready for markers"><span>🟢</span> Published</span>`;
          } else {
            publishBadge = `<span class="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300 text-[10px] font-bold flex items-center gap-1" title="Draft paper not yet pushed to Shared Folder"><span>⚠️</span> Draft</span>`;
          }

          // 3. Studio Selection Badge
          const openBadge = isSelected
            ? `<span class="px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 border border-sky-300 text-[10px] font-bold">✓ Studio Active</span>`
            : '';

          // 4. Synchronized Status Banner Callout
          let syncBannerHtml = '';
          if (!pubStatus.isPublished) {
            syncBannerHtml = `
              <div class="text-[10px] font-semibold text-slate-700 bg-slate-100/90 border border-slate-300 rounded-lg px-2.5 py-1.5 mb-3 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><span>⚠️</span> <strong>Draft (Unreleased)</strong> • Not on Shared Folder</span>
                <button onclick="hodApp.publishExamById('${e.id}')" class="text-[10px] font-bold text-purple-700 underline hover:text-purple-900 cursor-pointer">Publish Now</button>
              </div>
            `;
          } else if (isExamLocked) {
            syncBannerHtml = `
              <div class="text-[10px] font-semibold text-amber-900 bg-amber-50 border border-amber-300 rounded-lg px-2.5 py-1.5 mb-3 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><span>🔒</span> <strong>Marking Frozen (Read-Only)</strong> • Locked for markers</span>
                <span class="text-[9px] text-amber-800">${pubStatus.publishedAt ? new Date(pubStatus.publishedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Synced'}</span>
              </div>
            `;
          } else {
            syncBannerHtml = `
              <div class="text-[10px] font-semibold text-emerald-900 bg-emerald-50 border border-emerald-300 rounded-lg px-2.5 py-1.5 mb-3 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><span>🟢</span> <strong>Active Marking</strong> • Ready for markers on Shared Folder</span>
                <span class="text-[9px] text-emerald-700">${pubStatus.publishedAt ? new Date(pubStatus.publishedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Ready'}</span>
              </div>
            `;
          }

          // 5. Action Buttons
          const publishBtnHtml = pubStatus.isPublished
            ? `<button onclick="hodApp.publishExamById('${e.id}')" class="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold transition-colors cursor-pointer border border-emerald-200" title="Re-sync roster and rubric to Shared Folder">🔄 Re-Sync</button>`
            : `<button onclick="hodApp.publishExamById('${e.id}')" class="px-2 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs flex items-center gap-1" title="Publish this paper to Shared Folder so markers can select it"><span>📤</span> Publish</button>`;

          const lockBtnHtml = isExamLocked
            ? `<button onclick="hodApp.toggleLockForExam('${e.id}')" class="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg text-xs font-bold transition-colors cursor-pointer border border-amber-300 flex items-center gap-1" title="Unfreeze / Reopen marking for this paper"><span>🔓</span> Open</button>`
            : `<button onclick="hodApp.toggleLockForExam('${e.id}')" class="px-2 py-1 bg-slate-100 hover:bg-amber-50 text-slate-700 hover:text-amber-800 rounded-lg text-xs font-bold transition-colors cursor-pointer border border-slate-300 flex items-center gap-1" title="Freeze marking (Read-Only) for this paper"><span>🔒</span> Freeze</button>`;

          return `
            <div class="paper-card bg-white rounded-2xl p-5 border ${isSelected ? 'border-sky-500 ring-2 ring-sky-100' : 'border-slate-200'} shadow-xs flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between gap-2 mb-2 flex-wrap">
                  <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">${e.level} • ${e.subject}</span>
                  <div class="flex items-center gap-1 flex-wrap">
                    ${openBadge}
                    ${publishBadge}
                    ${lockBadge}
                  </div>
                </div>
                <h4 class="text-sm font-extrabold text-slate-900 leading-snug line-clamp-2">${e.title}</h4>
                <div class="text-[11px] text-slate-500 mt-1 mb-2.5">${e.paper}</div>

                ${syncBannerHtml}

                <div class="grid grid-cols-3 gap-2 my-3 p-2.5 bg-slate-50 rounded-xl text-center text-xs">
                  <div>
                    <span class="text-[10px] text-slate-400 block uppercase font-medium">Pupils</span>
                    <strong class="font-mono text-slate-800 text-sm">${e.totalStudents}</strong>
                  </div>
                  <div>
                    <span class="text-[10px] text-slate-400 block uppercase font-medium">Marked</span>
                    <strong class="font-mono text-sky-700 text-sm">${e.markedCount}</strong>
                  </div>
                  <div>
                    <span class="text-[10px] text-slate-400 block uppercase font-medium">Progress</span>
                    <strong class="font-mono text-emerald-600 text-sm">${e.progressPct}%</strong>
                  </div>
                </div>

                <div class="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden mb-2">
                  <div class="bg-sky-600 h-1.5 rounded-full" style="width: ${e.progressPct}%"></div>
                </div>

                <!-- Paper Access Security Passcodes Callout -->
                <div class="my-2.5 p-2 bg-purple-50/60 rounded-xl border border-purple-100 flex items-center justify-between text-[11px] gap-2">
                  <div class="flex items-center gap-1.5 truncate">
                    <span class="text-slate-500 font-medium">🔑 Marker:</span>
                    <code class="font-bold text-slate-800 bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono">${(db.getPaperSecurity(e.id)).markerPasscode || '1132'}</code>
                  </div>
                  <div class="flex items-center gap-1.5 shrink-0">
                    <span class="text-purple-700 font-medium">🛡️ KP PIN:</span>
                    <code class="font-bold text-purple-900 bg-purple-100 px-1.5 py-0.5 rounded border border-purple-200 font-mono">${(db.getPaperSecurity(e.id)).moderatorPin || 'MOD88'}</code>
                  </div>
                </div>
              </div>

              <div class="pt-3 border-t border-slate-100 flex items-center justify-between gap-1 flex-wrap">
                <div class="flex items-center gap-1.5 flex-wrap">
                  ${!isSelected ? `
                    <button onclick="hodApp.handleExamSwitch('${e.id}')" class="px-2.5 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs">
                      Switch To
                    </button>
                  ` : `
                    <span class="px-2.5 py-1.5 text-xs font-bold text-sky-700">Active</span>
                  `}
                  ${publishBtnHtml}
                  ${lockBtnHtml}
                  <button onclick="hodApp.openEditExamModal('${e.id}')" class="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600 cursor-pointer" title="Edit Paper Metadata & Rubrics">
                    ✏️
                  </button>
                  <button onclick="hodApp.archiveExam('${e.id}')" class="p-1.5 hover:bg-amber-50 text-amber-700 rounded-lg cursor-pointer" title="Archive this Paper (Move to Archived Papers)">
                    📦
                  </button>
                </div>
                <div class="flex items-center gap-1">
                  <button onclick="hodApp.duplicateExam('${e.id}')" class="p-1.5 hover:bg-slate-100 rounded text-slate-500 cursor-pointer" title="Duplicate / Clone Paper">📋</button>
                  ${exams.length > 1 ? `
                    <button onclick="hodApp.deleteExam('${e.id}')" class="p-1.5 hover:bg-rose-50 text-rose-600 rounded cursor-pointer" title="Delete Paper">🗑️</button>
                  ` : ''}
                </div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // Render archived papers list
    const archivedContainer = document.getElementById('archivedPapersList');
    if (archivedContainer) {
      if (archivedExams.length === 0) {
        archivedContainer.innerHTML = `
          <div class="col-span-full p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300">
            <div class="text-3xl mb-2">📦</div>
            <h5 class="text-sm font-bold text-slate-700">No Archived Papers</h5>
            <p class="text-xs text-slate-500 mt-1">When an exam period has passed, you can archive papers here to keep your active workspace uncluttered.</p>
          </div>
        `;
      } else {
        archivedContainer.innerHTML = archivedExams.map(e => {
          const dateStr = e.archivedAt ? new Date(e.archivedAt).toLocaleDateString('en-SG', { year: 'numeric', month: 'short', day: 'numeric' }) : 'Past Exam';
          return `
            <div class="paper-card bg-slate-50/70 rounded-2xl p-5 border border-slate-300 shadow-xs flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between gap-2 mb-2">
                  <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">${e.level} • ${e.subject}</span>
                  <span class="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-bold">📦 Archived (${dateStr})</span>
                </div>
                <h4 class="text-sm font-extrabold text-slate-900 leading-snug line-clamp-2">${e.title}</h4>
                <div class="text-[11px] text-slate-500 mt-1">${e.paper}</div>

                <div class="grid grid-cols-3 gap-2 my-4 p-2.5 bg-white rounded-xl text-center text-xs border border-slate-200">
                  <div>
                    <span class="text-[10px] text-slate-400 block uppercase font-medium">Pupils</span>
                    <strong class="font-mono text-slate-800 text-sm">${e.totalStudents}</strong>
                  </div>
                  <div>
                    <span class="text-[10px] text-slate-400 block uppercase font-medium">Marked</span>
                    <strong class="font-mono text-slate-800 text-sm">${e.markedCount}</strong>
                  </div>
                  <div>
                    <span class="text-[10px] text-slate-400 block uppercase font-medium">Final Rate</span>
                    <strong class="font-mono text-purple-700 text-sm">${e.progressPct}%</strong>
                  </div>
                </div>
              </div>

              <div class="pt-3 border-t border-slate-200 flex items-center justify-between gap-2 flex-wrap">
                <button onclick="hodApp.unarchiveExam('${e.id}')" class="px-3 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-2xs flex items-center gap-1">
                  <span>🔄 Restore to Active</span>
                </button>
                <div class="flex items-center gap-1">
                  <button onclick="hodApp.openEditExamModal('${e.id}')" class="p-1.5 hover:bg-slate-200 rounded text-slate-600 cursor-pointer" title="Edit Metadata">✏️</button>
                  <button onclick="hodApp.deleteExam('${e.id}')" class="p-1.5 hover:bg-rose-100 text-rose-600 rounded cursor-pointer" title="Permanently Delete">🗑️</button>
                </div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    this.renderActivePaperWorkspaceHeader();
  }

  // =========================================================================
  // ACTIVE PAPER SHARED FOLDER STATUS CARD & DIRECT PUBLISH ACTIONS
  // =========================================================================
  renderActivePaperWorkspaceHeader() {
    const card = document.getElementById('activePaperSyncStatusCard');
    if (!card) return;

    const activeExam = db.getActiveExam();
    if (!activeExam) return;

    const iconEl = document.getElementById('activePaperSyncIcon');
    const badgeEl = document.getElementById('activePaperSyncBadge');
    const folderEl = document.getElementById('activePaperSyncFolder');
    const titleEl = document.getElementById('activePaperSyncTitle');
    const subEl = document.getElementById('activePaperSyncSub');
    const btnEl = document.getElementById('btnPublishActivePaper');
    const freezeBtnEl = document.getElementById('btnToggleFreezeActivePaper');

    const isLocked = !!(activeExam.markingLocked || (activeExam.config && activeExam.config.markingLocked));

    if (titleEl) titleEl.textContent = activeExam.title || 'Untitled Assessment';

    if (activeExam.isArchived) {
      card.className = 'rounded-2xl p-4 sm:p-5 border transition-all shadow-xs bg-slate-100 border-slate-300 space-y-3.5';
      if (iconEl) { iconEl.textContent = '🗃️'; iconEl.className = 'w-11 h-11 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center text-xl shrink-0 shadow-2xs'; }
      if (badgeEl) { badgeEl.textContent = '🗃️ Paper Archived • Hidden from Active Roster'; badgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-800 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap shadow-2xs'; }
      if (folderEl) folderEl.textContent = 'Preserved in Archived Papers Vault';
      if (subEl) {
        subEl.textContent = 'This paper has been archived and hidden from active roster workflows. To make changes or mark scripts, please restore it.';
        subEl.className = 'text-xs text-slate-600 font-medium mt-0.5';
      }
      if (freezeBtnEl) freezeBtnEl.classList.add('hidden');
      if (btnEl) {
        btnEl.className = 'px-3.5 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap';
        btnEl.innerHTML = '<span>↩️ Restore Paper</span>';
        btnEl.onclick = () => this.restoreExam(activeExam.id);
      }
      return;
    }

    if (freezeBtnEl) {
      if (isLocked) {
        freezeBtnEl.className = 'px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap';
        freezeBtnEl.innerHTML = '<span>🔓 Unlock Marking</span>';
        freezeBtnEl.title = 'Reopen marking for this paper so markers can score';
      } else {
        freezeBtnEl.className = 'px-3.5 py-2 bg-slate-700 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap';
        freezeBtnEl.innerHTML = '<span>🔒 Freeze Marking</span>';
        freezeBtnEl.title = 'Freeze marking for this paper into Read-Only mode';
      }
    }

    const bottomBar = document.getElementById('activePaperSyncBottomBar');

    if (typeof syncService === 'undefined' || !syncService.isConnected()) {
      card.className = isLocked 
        ? 'rounded-2xl p-4 sm:p-5 border transition-all shadow-xs bg-amber-50/95 border-amber-300 space-y-3.5' 
        : 'rounded-2xl p-4 sm:p-5 border transition-all shadow-xs bg-amber-50/90 border-amber-200 space-y-3.5';
      if (bottomBar) bottomBar.className = 'pt-3 border-t border-amber-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs';
      if (iconEl) { iconEl.textContent = isLocked ? '🔒' : '📁'; iconEl.className = 'w-11 h-11 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl shrink-0 shadow-2xs'; }
      if (badgeEl) { badgeEl.textContent = isLocked ? '🔒 Marking Frozen • Local Only' : '📁 Shared Folder Not Linked'; badgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full bg-amber-200 text-amber-950 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap shadow-2xs'; }
      if (folderEl) folderEl.textContent = 'Operating locally on this laptop';
      if (subEl) {
        subEl.textContent = 'Markers on other laptops cannot see this paper until you link your School Shared Folder.';
        subEl.className = 'text-xs text-amber-800 font-medium mt-0.5';
      }
      if (btnEl) {
        btnEl.className = 'px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap';
        btnEl.innerHTML = '<span>📁 Link Shared Folder</span>';
        btnEl.onclick = () => syncService.connectSharedFolder();
      }
      return;
    }

    const pubStatus = syncService.getPaperPublishStatus(activeExam.id);
    const folderName = syncService.folderName || (syncService.folderHandle && syncService.folderHandle.name) || (syncService.syncDirHandle && syncService.syncDirHandle.name) || (syncService.dirHandle && syncService.dirHandle.name) || 'School Shared Drive';
    if (folderEl) folderEl.textContent = `Folder: ${folderName}`;

    let dateText = 'Recently';
    if (pubStatus.publishedAt) {
      try {
        const d = new Date(pubStatus.publishedAt);
        dateText = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      } catch(e) {}
    }

    if (pubStatus.isPublished) {
      if (isLocked) {
        card.className = 'rounded-2xl p-4 sm:p-5 border transition-all shadow-xs bg-amber-50/95 border-amber-300 space-y-3.5';
        if (bottomBar) bottomBar.className = 'pt-3 border-t border-amber-300/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs';
        if (iconEl) { iconEl.textContent = '🔒'; iconEl.className = 'w-11 h-11 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center text-xl shrink-0 shadow-2xs'; }
        if (badgeEl) { badgeEl.textContent = '🔒 Marking Frozen (Read-Only) • On Shared Folder'; badgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full bg-amber-200 text-amber-950 text-[10px] font-extrabold uppercase tracking-wider border border-amber-300 whitespace-nowrap shadow-2xs'; }
        if (subEl) {
          subEl.textContent = `Marking frozen by HOD • Last published: ${dateText} • ${pubStatus.totalStudents} pupils locked in read-only mode`;
          subEl.className = 'text-xs text-amber-900 font-medium mt-0.5';
        }
      } else {
        card.className = 'rounded-2xl p-4 sm:p-5 border transition-all shadow-xs bg-emerald-50/90 border-emerald-200 space-y-3.5';
        if (bottomBar) bottomBar.className = 'pt-3 border-t border-emerald-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs';
        if (iconEl) { iconEl.textContent = '🟢'; iconEl.className = 'w-11 h-11 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-xl shrink-0 shadow-2xs'; }
        if (badgeEl) { badgeEl.textContent = '🟢 Active Marking • Published to Shared Folder'; badgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full bg-emerald-200 text-emerald-950 text-[10px] font-bold uppercase tracking-wider border border-emerald-300 whitespace-nowrap shadow-2xs'; }
        if (subEl) {
          subEl.textContent = `Marking active for scoring • Last published: ${dateText} • ${pubStatus.totalStudents} pupils ready for markers`;
          subEl.className = 'text-xs text-emerald-800 font-medium mt-0.5';
        }
      }
      if (btnEl) {
        btnEl.className = 'px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap';
        btnEl.innerHTML = '<span>🔄 Re-Publish / Update</span>';
        btnEl.onclick = () => this.publishActiveExam();
      }
    } else {
      card.className = 'rounded-2xl p-4 sm:p-5 border transition-all shadow-xs bg-amber-50/90 border-amber-200 space-y-3.5';
      if (bottomBar) bottomBar.className = 'pt-3 border-t border-amber-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs';
      if (iconEl) { iconEl.textContent = '⚠️'; iconEl.className = 'w-11 h-11 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl shrink-0 shadow-2xs'; }
      if (badgeEl) { badgeEl.textContent = isLocked ? '🔒 Marking Frozen • Local Draft' : '⚠️ Local Draft (Not Yet Published)'; badgeEl.className = 'inline-flex items-center px-2.5 py-0.5 rounded-full bg-amber-200 text-amber-950 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap shadow-2xs'; }
      if (subEl) {
        subEl.textContent = `Markers on other laptops cannot see or select this paper until you click "Publish to Shared Folder".`;
        subEl.className = 'text-xs text-amber-800 font-medium mt-0.5';
      }
      if (btnEl) {
        btnEl.className = 'px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap';
        btnEl.innerHTML = '<span>📤 Publish to Shared Folder</span>';
        btnEl.onclick = () => this.publishActiveExam();
      }
    }
  }

  async publishExamById(examId) {
    if (typeof syncService === 'undefined') return;
    if (!syncService.isConnected()) {
      const ok = await syncService.connectSharedFolder();
      if (!ok) return;
    }
    const res = await syncService.publishSingleExam(examId);
    if (res && res.success) {
      this.renderPapersHub();
      this.renderActivePaperWorkspaceHeader();
      if (typeof markerApp !== 'undefined') {
        markerApp.showToast(`Published to Shared Folder!`, 'success');
      }
    } else {
      alert(`Publish failed: ${(res && res.error) || 'Unknown error'}`);
    }
  }

  async publishActiveExam() {
    const active = db.getActiveExam();
    if (active) {
      await this.publishExamById(active.id);
    }
  }

  async publishAllActiveExams() {
    if (typeof syncService === 'undefined') return;
    if (!syncService.isConnected()) {
      const ok = await syncService.connectSharedFolder();
      if (!ok) return;
    }
    const res = await syncService.publishAllExams();
    if (res && res.success) {
      this.renderPapersHub();
      this.renderActivePaperWorkspaceHeader();
      if (typeof markerApp !== 'undefined') {
        markerApp.showToast(`All active papers published to Shared Folder!`, 'success');
      }
    } else {
      alert(`Publish all failed: ${(res && res.error) || 'Unknown error'}`);
    }
  }

  // =========================================================================
  // ARCHIVING & UNARCHIVING METHODS
  // =========================================================================
  toggleArchiveActiveExam() {
    const active = db.getActiveExam();
    if (!active) return;
    if (active.isArchived) {
      this.unarchiveExam(active.id);
    } else {
      this.archiveExam(active.id);
    }
  }

  archiveExam(examId) {
    const exams = db.getExamsList();
    const target = exams.find(e => e.id === examId);
    if (!target) return;

    if (confirm(`📦 ARCHIVE EXAM PAPER?\n\n"${target.title}" will be moved to Archived Papers.\n- Marking will be automatically frozen (read-only).\n- Candidates and marks are preserved safely.\n- You can restore it to Active at any time.\n\nProceed to archive?`)) {
      const res = db.archiveExam(examId);
      if (res.success) {
        this.renderExamSelector();
        this.renderExecutivePaperDeck();
        this.renderPapersHub();
        this.renderManageExamsTable();
        this.renderLockControls();
        this.renderActiveTab();
        this.renderOverviewStats();
        if (typeof markerApp !== 'undefined') {
          markerApp.populateClassFilters();
          markerApp.renderStudentList();
          markerApp.renderMarkerHeader();
        }
        markerApp.showToast(`Archived paper: ${target.title}`);
      } else {
        alert(res.error);
      }
    }
  }

  unarchiveExam(examId) {
    const exams = db.getExamsList();
    const target = exams.find(e => e.id === examId);
    if (!target) return;

    if (confirm(`🔄 RESTORE EXAM PAPER?\n\n"${target.title}" will be restored from Archived Papers to Active assessment papers and set as the current active paper.\n\nProceed?`)) {
      const res = db.unarchiveExam(examId);
      if (res.success) {
        this.renderExamSelector();
        this.renderExecutivePaperDeck();
        this.renderPapersHub();
        this.renderManageExamsTable();
        this.renderLockControls();
        this.renderActiveTab();
        this.renderOverviewStats();
        if (typeof markerApp !== 'undefined') {
          markerApp.populateClassFilters();
          markerApp.renderStudentList();
          markerApp.renderMarkerHeader();
        }
        markerApp.showToast(`Restored active paper: ${res.exam.title}`);
      } else {
        alert(res.error);
      }
    }
  }

  // =========================================================================
  // EDIT EXAM SETTINGS & RUBRIC MODAL
  // =========================================================================
  openEditActiveExamModal() {
    const active = db.getActiveExam();
    if (active) this.openEditExamModal(active.id);
  }

  openEditExamModal(examId) {
    const exams = db.getExamsList();
    const exam = exams.find(e => e.id === examId);
    if (!exam) return;

    const modal = document.getElementById('editExamDetailsModal');
    if (!modal) return;

    const state = db.loadExam(examId) || db.getState();
    const config = state.config || {};

    const targetIdInput = document.getElementById('editExamTargetId');
    const titleInput = document.getElementById('editExamTitle');
    const levelInput = document.getElementById('editExamLevel');
    const subjectInput = document.getElementById('editExamSubject');
    const paperInput = document.getElementById('editExamPaper');
    const presetSelect = document.getElementById('editExamPresetSelect');
    const contentMaxInput = document.getElementById('editExamContentMax');
    const langMaxInput = document.getElementById('editExamLangMax');
    const passPctInput = document.getElementById('editExamPassPct');
    const qualityPctInput = document.getElementById('editExamQualityPct');
    const blindModeInput = document.getElementById('editExamBlindMode');

    if (targetIdInput) targetIdInput.value = examId;
    if (titleInput) titleInput.value = exam.title || '';
    if (levelInput) levelInput.value = config.level || exam.level || '';
    if (subjectInput) subjectInput.value = config.subject || exam.subject || '';
    if (paperInput) paperInput.value = config.paper || exam.paper || '';
    if (presetSelect) presetSelect.value = '';
    if (contentMaxInput) contentMaxInput.value = config.contentMax ?? 7;
    if (langMaxInput) langMaxInput.value = config.langMax ?? 8;
    if (passPctInput) passPctInput.value = config.passCutoffPct ?? 50;
    if (qualityPctInput) qualityPctInput.value = config.qualityCutoffPct ?? 80;
    if (blindModeInput) blindModeInput.checked = !!config.blindMarking;

    modal.classList.remove('hidden');
  }

  closeEditExamModal() {
    const modal = document.getElementById('editExamDetailsModal');
    if (modal) modal.classList.add('hidden');
  }

  applyPresetToEditModal(presetId) {
    if (!presetId) return;
    const presets = {
      'P3_P4_MT': { content: 7, lang: 8 },
      'P5_P6_MT': { content: 20, lang: 20 },
      'ENG_P5_P6': { content: 20, lang: 20 }
    };
    const p = presets[presetId];
    if (p) {
      const cInput = document.getElementById('editExamContentMax');
      const lInput = document.getElementById('editExamLangMax');
      if (cInput) cInput.value = p.content;
      if (lInput) lInput.value = p.lang;
    }
  }

  submitEditExam() {
    const examId = document.getElementById('editExamTargetId')?.value;
    if (!examId) return;

    const title = document.getElementById('editExamTitle')?.value.trim();
    const level = document.getElementById('editExamLevel')?.value.trim();
    const subject = document.getElementById('editExamSubject')?.value.trim();
    const paper = document.getElementById('editExamPaper')?.value.trim();
    const contentMax = parseFloat(document.getElementById('editExamContentMax')?.value) || 7;
    const langMax = parseFloat(document.getElementById('editExamLangMax')?.value) || 8;
    const passCutoffPct = parseFloat(document.getElementById('editExamPassPct')?.value) || 50;
    const qualityCutoffPct = parseFloat(document.getElementById('editExamQualityPct')?.value) || 80;
    const blindMarking = !!document.getElementById('editExamBlindMode')?.checked;

    if (!title) {
      alert('Examination Title cannot be empty.');
      return;
    }

    const updates = {
      title,
      level,
      subject,
      paper,
      contentMax,
      langMax,
      passCutoffPct,
      qualityCutoffPct,
      blindMarking
    };

    const res = db.updateExamDetails(examId, updates);
    if (res.success) {
      this.closeEditExamModal();
      this.renderExamSelector();
      this.renderExecutivePaperDeck();
      this.renderPapersHub();
      this.renderManageExamsTable();
      this.renderActiveTab();
      this.renderOverviewStats();
      if (typeof markerApp !== 'undefined') {
        markerApp.renderMarkerHeader();
        markerApp.populateClassFilters();
        markerApp.renderStudentList();
      }
      markerApp.showToast(`Updated examination paper: ${res.exam.title}!`);
    } else {
      alert(res.error || 'Failed to update exam details.');
    }
  }

  // =========================================================================
  // CLASS & COHORT BUNDLE MANAGEMENT METHODS
  // =========================================================================
  renderClassManagementSection() {
    const summary = db.getClassesSummary();
    const grid = document.getElementById('classesSummaryGrid');
    const filterSelect = document.getElementById('rosterClassFilter');

    if (grid) {
      const allClassCards = [];

      // Form classes
      summary.formClasses.forEach(c => {
        const pct = c.totalStudents > 0 ? Math.round((c.markedCount / c.totalStudents) * 100) : 0;
        allClassCards.push(`
          <div class="class-pill-card p-3 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-white flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-1.5 py-0.5 rounded">Form Class</span>
                <span class="text-xs font-mono font-bold text-emerald-700">${c.markedCount}/${c.totalStudents} (${pct}%)</span>
              </div>
              <h5 class="text-sm font-extrabold text-slate-900">${c.className}</h5>
            </div>
            <div class="flex items-center justify-between gap-1 pt-2.5 mt-2 border-t border-slate-200/60 text-xs">
              <button onclick="hodApp.openAddStudentForClass('${c.className}', 'formClass')" class="text-sky-700 hover:text-sky-900 font-semibold cursor-pointer text-[11px]" title="Add pupil to this class">
                + Pupil
              </button>
              <div class="flex items-center gap-1">
                <button onclick="hodApp.renameClass('${c.className}', 'formClass')" class="p-1 hover:bg-slate-200 rounded text-slate-600 cursor-pointer text-xs" title="Rename Class">✏️</button>
                <button onclick="hodApp.deleteClass('${c.className}', 'formClass')" class="p-1 hover:bg-rose-100 text-rose-600 rounded cursor-pointer text-xs" title="Delete Class Bundle">🗑️</button>
              </div>
            </div>
          </div>
        `);
      });

      // MT classes
      summary.mtClasses.forEach(c => {
        const pct = c.totalStudents > 0 ? Math.round((c.markedCount / c.totalStudents) * 100) : 0;
        allClassCards.push(`
          <div class="class-pill-card p-3 rounded-xl border border-purple-200 bg-purple-50/40 hover:bg-white flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between mb-1">
                <span class="text-[10px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded">MT Class</span>
                <span class="text-xs font-mono font-bold text-purple-700">${c.markedCount}/${c.totalStudents} (${pct}%)</span>
              </div>
              <h5 class="text-sm font-extrabold text-slate-900">${c.className}</h5>
            </div>
            <div class="flex items-center justify-between gap-1 pt-2.5 mt-2 border-t border-purple-200/60 text-xs">
              <button onclick="hodApp.openAddStudentForClass('${c.className}', 'mtClass')" class="text-purple-700 hover:text-purple-900 font-semibold cursor-pointer text-[11px]" title="Add pupil to this MT class">
                + Pupil
              </button>
              <div class="flex items-center gap-1">
                <button onclick="hodApp.renameClass('${c.className}', 'mtClass')" class="p-1 hover:bg-purple-100 rounded text-purple-700 cursor-pointer text-xs" title="Rename MT Class">✏️</button>
                <button onclick="hodApp.deleteClass('${c.className}', 'mtClass')" class="p-1 hover:bg-rose-100 text-rose-600 rounded cursor-pointer text-xs" title="Delete MT Class Bundle">🗑️</button>
              </div>
            </div>
          </div>
        `);
      });

      if (allClassCards.length === 0) {
        grid.innerHTML = `<div class="col-span-full text-xs text-slate-500 py-3">No classes registered yet in this paper. Add students or upload a CSV roster to automatically create class bundles.</div>`;
      } else {
        grid.innerHTML = allClassCards.join('');
      }
    }

    // Populate roster filter select
    if (filterSelect) {
      const currentVal = filterSelect.value || 'ALL';
      filterSelect.innerHTML = `<option value="ALL">All Classes (Full Paper Roster)</option>` +
        `<optgroup label="Form Classes">` +
        summary.formClasses.map(c => `<option value="FORM:${c.className}">${c.className} (${c.totalStudents} pupils)</option>`).join('') +
        `</optgroup>` +
        `<optgroup label="Mother Tongue Classes">` +
        summary.mtClasses.map(c => `<option value="MT:${c.className}">${c.className} (${c.totalStudents} pupils)</option>`).join('') +
        `</optgroup>`;
      filterSelect.value = currentVal;
    }
  }

  openAddClassModal() {
    const modal = document.getElementById('addClassModal');
    if (modal) {
      document.getElementById('newClassNameInput').value = '';
      document.getElementById('newClassPupilCountInput').value = '0';
      modal.classList.remove('hidden');
      document.getElementById('newClassNameInput').focus();
    }
  }

  closeAddClassModal() {
    const modal = document.getElementById('addClassModal');
    if (modal) modal.classList.add('hidden');
  }

  submitAddNewClass() {
    const typeRadios = document.querySelectorAll('input[name="newClassTypeRadio"]');
    let classType = 'formClass';
    typeRadios.forEach(r => { if (r.checked) classType = r.value; });

    const className = document.getElementById('newClassNameInput')?.value.trim();
    const pupilCount = parseInt(document.getElementById('newClassPupilCountInput')?.value) || 0;

    if (!className) {
      alert('Please enter a class name.');
      return;
    }

    if (pupilCount > 0) {
      const state = db.getState();
      const existingInClass = state.students.filter(s => classType === 'formClass' ? s.formClass === className : s.mtClass === className).length;
      for (let i = 1; i <= pupilCount; i++) {
        const regNo = existingInClass + i;
        db.addStudent({
          name: `Student ${regNo}`,
          chineseName: '',
          formClass: classType === 'formClass' ? className : '4A',
          mtClass: classType === 'mtClass' ? className : '4MT-1',
          regNo: regNo
        });
      }
    }

    this.closeAddClassModal();
    this.renderClassManagementSection();
    this.populateFilterDropdowns();
    this.renderRosterTable();
    this.renderOverviewStats();
    if (typeof markerApp !== 'undefined') {
      markerApp.populateClassFilters();
      markerApp.renderStudentList();
    }
    markerApp.showToast(`Created class bundle "${className}" with ${pupilCount} pupils.`);
  }

  openAddStudentForClass(className, classType) {
    this.openAddStudentModal();
    if (classType === 'formClass') {
      const formEl = document.getElementById('addStdFormClass');
      if (formEl) formEl.value = className;
    } else {
      const mtEl = document.getElementById('addStdMtClass');
      if (mtEl) mtEl.value = className;
    }
  }

  renameClass(className, classType) {
    const typeLabel = classType === 'formClass' ? 'Form Class' : 'Mother Tongue Class';
    const newName = prompt(`Enter new name for ${typeLabel} "${className}":`, className);
    if (!newName || !newName.trim() || newName.trim() === className) return;

    const res = db.renameClassInExam(className, newName.trim(), classType);
    if (res.success) {
      this.renderClassManagementSection();
      this.populateFilterDropdowns();
      this.renderRosterTable();
      this.renderOverviewStats();
      this.autoPublishActiveExamIfConnected();
      this.renderActivePaperWorkspaceHeader();
      this.renderPapersHub();
      if (typeof markerApp !== 'undefined') {
        markerApp.populateClassFilters();
        markerApp.renderStudentList();
      }
      markerApp.showToast(`Renamed ${typeLabel} "${className}" to "${newName.trim()}" (${res.updatedCount} students updated).`);
    } else {
      alert(res.error);
    }
  }

  deleteClass(className, classType) {
    const typeLabel = classType === 'formClass' ? 'Form Class' : 'Mother Tongue Class';
    const state = db.getState();
    const studentsInClass = state.students.filter(s => classType === 'formClass' ? s.formClass === className : s.mtClass === className);

    if (confirm(`⚠️ DELETE CLASS BUNDLE?\n\nAre you sure you want to remove ${typeLabel} "${className}"?\nThis will remove ${studentsInClass.length} pupil script(s) belonging to this class from this paper.\n\nThis action cannot be undone.`)) {
      const res = db.deleteClassFromExam(className, classType);
      if (res.success) {
        this.renderClassManagementSection();
        this.populateFilterDropdowns();
        this.renderRosterTable();
        this.renderOverviewStats();
        this.autoPublishActiveExamIfConnected();
        this.renderActivePaperWorkspaceHeader();
        this.renderPapersHub();
        if (typeof markerApp !== 'undefined') {
          markerApp.populateClassFilters();
          markerApp.renderStudentList();
        }
        markerApp.showToast(`Removed ${typeLabel} "${className}" (${res.deletedCount} students removed).`);
      } else {
        alert(res.error);
      }
    }
  }

  handleRosterFilterChange() {
    this.renderRosterTable();
  }

  populateCopyMarkersDropdown() {
    const sel = document.getElementById('newExamCopyMarkersSelect');
    if (!sel) return;
    const exams = db.getExamsList();
    sel.innerHTML = '<option value="">-- Use Default 4 Markers (M01-M04) --</option>' + 
      exams.map(e => `<option value="${e.id}">Copy marker team from: ${e.title} (${e.markersCount} markers)</option>`).join('');
  }

  populateCopyRosterDropdown() {
    const sel = document.getElementById('newExamCopyRosterSelect');
    if (!sel) return;
    const exams = db.getExamsList();
    sel.innerHTML = '<option value="">-- Start with Empty Roster (Add or upload later) --</option>' + 
      exams.map(e => `<option value="${e.id}">Copy roster from: ${e.title} (${e.totalStudents} pupils)</option>`).join('');
  }

  submitCreateNewExam() {
    if (!auth || !auth.isHOD()) {
      if (typeof app !== 'undefined' && app.showToast) {
        app.showToast('Access Denied: Only HOD can register new examination papers.', 'error');
      } else {
        alert('Access Denied: Only HOD can register new examination papers.');
      }
      return;
    }

    const titleInput = document.getElementById('newExamTitle');
    const levelInput = document.getElementById('newExamLevel');
    const subjectInput = document.getElementById('newExamSubject');
    const paperInput = document.getElementById('newExamPaper');
    const presetSelect = document.getElementById('newExamPreset');
    const copySelect = document.getElementById('newExamCopyMarkersSelect');
    const copyRosterSelect = document.getElementById('newExamCopyRosterSelect');

    const title = titleInput ? titleInput.value.trim() : '';
    const level = levelInput ? levelInput.value.trim() : 'Primary 4';
    const subject = subjectInput ? subjectInput.value.trim() : 'Mother Tongue';
    const paper = paperInput ? paperInput.value.trim() : 'Paper 1 (Writing)';
    const presetId = presetSelect ? presetSelect.value : 'P3_P4_MT';
    const copyFrom = copySelect ? copySelect.value : '';
    const copyRosterFrom = copyRosterSelect ? copyRosterSelect.value : '';

    if (!title) {
      alert('Please enter an Examination Title.');
      if (titleInput) titleInput.focus();
      return;
    }

    const newExam = db.createExam({
      title,
      level,
      subject,
      paper,
      presetId,
      copyMarkersFrom: copyFrom,
      copyRosterFrom: copyRosterFrom
    });

    this.closeManageExamsModal();
    this.renderExamSelector();
    this.populateFilterDropdowns();
    this.renderLockControls();
    this.renderActiveTab();
    this.renderOverviewStats();
    markerApp.populateClassFilters();
    markerApp.renderStudentList();
    markerApp.renderMarkerHeader();
    markerApp.renderClassProgressBar();
    markerApp.renderRecentMarkedTable();
    markerApp.showToast(`Created & opened new exam: ${newExam.title}!`);

    if (typeof syncService !== 'undefined' && syncService.isConnected()) {
      syncService.publishExamMaster();
    }

    if (titleInput) titleInput.value = '';
  }

  async deleteExam(examId) {
    const exams = db.getExamsList();
    const target = exams.find(e => e.id === examId);
    if (!target) return;

    if (confirm(`⚠️ Are you sure you want to delete the exam paper:\n"${target.title}"?\n\nThis will permanently remove its student roster and marks.`)) {
      const res = db.deleteExam(examId);
      if (res.success) {
        // 1. Purge from Shared Folder manifest and file system if connected
        if (typeof syncService !== 'undefined' && syncService.isConnected()) {
          try {
            await syncService.deleteExamFromSharedFolder(examId);
          } catch (syncErr) {
            console.warn('[HOD] Failed to purge deleted exam from shared folder:', syncErr);
          }
        }

        // 2. Refresh Global Selector in navigation
        this.renderExamSelector();
        if (typeof app !== 'undefined' && app.renderGlobalExamSelector) {
          app.renderGlobalExamSelector();
        }

        // 3. Refresh Left Rail (Active and Archived Papers Hub lists)
        this.renderPapersHub();

        // 4. Refresh Dashboard Top Executive Deck
        this.renderExecutivePaperDeck();

        // 5. Refresh Active Workspace Header & Sync Card
        this.renderActivePaperWorkspaceHeader();

        // 6. Refresh Manage Exams Modal Table
        this.renderManageExamsTable();

        // 7. Refresh controls, filters, and cohort stats
        this.populateFilterDropdowns();
        this.renderLockControls();
        this.renderOverviewStats();

        // 8. Re-render Active Tab view (Roster, Consolidation, Moderation, etc.)
        this.renderActiveTab();

        // 9. Update Marker View components
        if (typeof markerApp !== 'undefined') {
          markerApp.populateClassFilters();
          markerApp.renderStudentList();
          markerApp.renderMarkerHeader();
          markerApp.renderClassProgressBar();
          markerApp.renderRecentMarkedTable();
        }

        if (typeof app !== 'undefined' && app.showToast) {
          app.showToast(`Deleted exam paper: ${target.title}`, 'info');
        } else if (typeof markerApp !== 'undefined') {
          markerApp.showToast(`Deleted exam paper: ${target.title}`);
        }
      } else {
        alert(res.error);
      }
    }
  }

  duplicateExam(examId) {
    const exams = db.getExamsList();
    const target = exams.find(e => e.id === examId);
    if (!target) return;

    const newTitle = prompt(`Enter title for cloned exam paper:`, `${target.title} (Clone)`);
    if (newTitle && newTitle.trim()) {
      const res = db.duplicateExam(examId, newTitle.trim());
      if (res.success) {
        this.renderExamSelector();
        if (typeof app !== 'undefined' && app.renderGlobalExamSelector) {
          app.renderGlobalExamSelector();
        }
        this.renderExecutivePaperDeck();
        this.renderPapersHub();
        this.renderActivePaperWorkspaceHeader();
        this.renderManageExamsTable();
        this.populateFilterDropdowns();
        this.renderLockControls();
        this.renderActiveTab();
        this.renderOverviewStats();
        if (typeof markerApp !== 'undefined') {
          markerApp.populateClassFilters();
          markerApp.renderStudentList();
          markerApp.renderMarkerHeader();
          markerApp.renderClassProgressBar();
          markerApp.renderRecentMarkedTable();
        }
        markerApp.showToast(`Cloned exam paper: ${res.exam.title}!`);
      } else {
        alert(res.error);
      }
    }
  }

  // =========================================================================
  // AUTO-SAVE BEACON & LOGOUT CONFIRMATION MODAL
  // =========================================================================
  initAutoSaveBeacon() {
    const beacon = document.getElementById('globalAutoSaveBeacon');
    const updateBeacon = (ts) => {
      if (!beacon) return;
      const date = ts ? new Date(ts) : new Date();
      const timeStr = date.toLocaleTimeString('en-SG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      beacon.innerHTML = `
        <span class="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
        <span class="font-medium">Auto-saved ${timeStr}</span>
      `;
    };

    db.onAutoSaved((ts) => updateBeacon(ts));
    const lastSaved = db.getLastSavedTimestamp();
    if (lastSaved) updateBeacon(lastSaved);
  }

  // =========================================================================
  // CROSS-PAPER ROSTER & CLASS BUNDLE COPY MODAL METHODS
  // =========================================================================
  openCopyRosterModal() {
    const modal = document.getElementById('copyRosterModal');
    if (!modal) return;

    const activeExam = db.getActiveExam();
    const targetNameEl = document.getElementById('copyRosterTargetExamName');
    if (targetNameEl && activeExam) {
      targetNameEl.textContent = `${activeExam.title} (${activeExam.level} • ${activeExam.paper}) [${activeExam.students.length} pupils currently]`;
    }

    const sourceSelect = document.getElementById('copyRosterSourceExamSelect');
    if (sourceSelect) {
      const exams = db.getExamsList();
      const otherExams = exams.filter(e => e.id !== activeExam.id);
      const listToDisplay = otherExams.length > 0 ? otherExams : exams;

      sourceSelect.innerHTML = listToDisplay.map(e => {
        const archivedTag = e.isArchived ? ' [Archived]' : '';
        return `<option value="${e.id}">${e.title} (${e.level} • ${e.totalStudents} pupils)${archivedTag}</option>`;
      }).join('');
    }

    this.handleCopyRosterSourceChange();
    modal.classList.remove('hidden');
  }

  closeCopyRosterModal() {
    const modal = document.getElementById('copyRosterModal');
    if (modal) modal.classList.add('hidden');
  }

  handleCopyRosterSourceChange() {
    const sourceSelect = document.getElementById('copyRosterSourceExamSelect');
    const classSelect = document.getElementById('copyRosterClassSelect');
    if (!sourceSelect || !classSelect) return;

    const sourceExamId = sourceSelect.value;
    if (!sourceExamId) {
      classSelect.innerHTML = '<option value="ALL">All Classes in Source Paper (Entire Roster)</option>';
      this.updateCopyRosterPreview();
      return;
    }

    const summary = db.getClassesSummary(sourceExamId);
    const sourceExam = db.getExamsList().find(e => e.id === sourceExamId);
    const totalPupils = sourceExam ? sourceExam.totalStudents : 0;

    let optionsHtml = `<option value="ALL">All Classes in Source Paper (${totalPupils} pupils)</option>`;

    if (summary.formClasses && summary.formClasses.length > 0) {
      optionsHtml += `<optgroup label="Form Classes">`;
      summary.formClasses.forEach(c => {
        const name = c.name || c.className;
        const total = c.totalStudents || c.total || 0;
        optionsHtml += `<option value="FORM:${name}">Form Class: ${name} (${total} pupils)</option>`;
      });
      optionsHtml += `</optgroup>`;
    }

    if (summary.mtClasses && summary.mtClasses.length > 0) {
      optionsHtml += `<optgroup label="Mother Tongue Classes">`;
      summary.mtClasses.forEach(c => {
        const name = c.name || c.className;
        const total = c.totalStudents || c.total || 0;
        optionsHtml += `<option value="MT:${name}">MT Class: ${name} (${total} pupils)</option>`;
      });
      optionsHtml += `</optgroup>`;
    }

    classSelect.innerHTML = optionsHtml;
    this.updateCopyRosterPreview();
  }

  updateCopyRosterPreview() {
    const sourceSelect = document.getElementById('copyRosterSourceExamSelect');
    const classSelect = document.getElementById('copyRosterClassSelect');
    const badge = document.getElementById('copyRosterCountBadge');
    if (!sourceSelect || !badge) return;

    const sourceExamId = sourceSelect.value;
    const classVal = classSelect ? classSelect.value : 'ALL';

    const rootState = db.getRootState();
    const sourceExam = (rootState && rootState.exams) ? rootState.exams.find(e => e.id === sourceExamId) : null;
    if (!sourceExam || !Array.isArray(sourceExam.students)) {
      badge.textContent = '0 pupils';
      return;
    }

    let count = sourceExam.students.length;
    if (classVal.startsWith('FORM:')) {
      const clsName = classVal.substring(5);
      count = sourceExam.students.filter(s => s.formClass === clsName).length;
    } else if (classVal.startsWith('MT:')) {
      const clsName = classVal.substring(3);
      count = sourceExam.students.filter(s => s.mtClass === clsName).length;
    }

    badge.textContent = `${count} pupils`;
  }

  submitCopyRoster() {
    const sourceSelect = document.getElementById('copyRosterSourceExamSelect');
    const classSelect = document.getElementById('copyRosterClassSelect');
    const modeRadio = document.querySelector('input[name="copyRosterModeRadio"]:checked');

    const sourceExamId = sourceSelect ? sourceSelect.value : null;
    const classVal = classSelect ? classSelect.value : 'ALL';
    const mode = modeRadio ? modeRadio.value : 'append';

    if (!sourceExamId) {
      alert('Please select a source examination paper.');
      return;
    }

    let filterType = 'ALL';
    let filterValue = 'ALL';
    if (classVal.startsWith('FORM:')) {
      filterType = 'formClass';
      filterValue = classVal.substring(5);
    } else if (classVal.startsWith('MT:')) {
      filterType = 'mtClass';
      filterValue = classVal.substring(3);
    }

    const res = db.copyRosterFromExam({
      sourceExamId,
      filterType,
      filterValue,
      mode
    });

    if (res.success) {
      this.closeCopyRosterModal();
      this.renderClassManagementSection();
      this.populateFilterDropdowns();
      this.renderRosterTable();
      this.renderConsolidationTable();
      this.renderExecutivePaperDeck();
      this.renderOverviewStats();
      this.autoPublishActiveExamIfConnected();
      this.renderActivePaperWorkspaceHeader();
      this.renderPapersHub();
      if (typeof markerApp !== 'undefined') {
        markerApp.populateClassFilters();
        markerApp.renderStudentList();
        markerApp.renderMarkerHeader();
      }
      markerApp.showToast(`Successfully copied ${res.count} pupils into ${db.getActiveExam().title}!`);
    } else {
      alert(res.error || 'Failed to copy roster.');
    }
  }

  openLogoutConfirmModal() {
    const modal = document.getElementById('hodLogoutConfirmModal');
    if (!modal) {
      if (confirm('Are you sure you want to log out of the Exam Control Hub?')) {
        auth.logout();
        if (typeof app !== 'undefined') app.showAuthModal();
      }
      return;
    }

    const exams = db.getExamsList();
    const totalStudents = exams.reduce((sum, e) => sum + e.totalStudents, 0);
    const totalMarked = exams.reduce((sum, e) => sum + e.markedCount, 0);
    const statsEl = document.getElementById('hodLogoutStatsSummary');

    if (statsEl) {
      statsEl.innerHTML = `
        <div class="grid grid-cols-3 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
          <div><div class="text-[10px] text-slate-500 uppercase font-semibold">Exams Configured</div><div class="font-bold text-slate-800 text-sm font-mono mt-0.5">${exams.length}</div></div>
          <div><div class="text-[10px] text-slate-500 uppercase font-semibold">Total Students</div><div class="font-bold text-slate-800 text-sm font-mono mt-0.5">${totalStudents}</div></div>
          <div><div class="text-[10px] text-slate-500 uppercase font-semibold">Marked Scripts</div><div class="font-bold text-emerald-700 text-sm font-mono mt-0.5">${totalMarked}</div></div>
        </div>
      `;
    }

    modal.classList.remove('hidden');
  }

  closeLogoutConfirmModal() {
    const modal = document.getElementById('hodLogoutConfirmModal');
    if (modal) modal.classList.add('hidden');
  }

  confirmLogout() {
    this.closeLogoutConfirmModal();
    auth.logout();
    if (typeof app !== 'undefined') app.showAuthModal();
  }
}

const hodApp = new HodController();
window.hodApp = hodApp;
