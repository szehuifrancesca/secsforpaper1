/**
 * SECS - Analytics, Item Analysis & Statistical Engine
 * Computes descriptive statistics, cohort breakdowns, and marker calibration metrics.
 */

class AnalyticsService {
  computeCohortStats(students, config) {
    const markedStudents = students.filter(s => s.score && s.score.total !== null);
    const totalCandidature = students.length;
    const totalMarked = markedStudents.length;
    const totalUnmarked = totalCandidature - totalMarked;
    const totalModerated = students.filter(s => s.status === 'moderated').length;

    if (totalMarked === 0) {
      return {
        totalCandidature,
        totalMarked: 0,
        totalUnmarked,
        totalModerated: 0,
        mean: 0,
        median: 0,
        stdDev: 0,
        min: 0,
        max: 0,
        passCount: 0,
        passPct: 0,
        qualityCount: 0,
        qualityPct: 0,
        parCount: 0,
        parPct: 0,
        bandCounts: { band1: 0, band2: 0, band3: 0, band4: 0 }
      };
    }

    const scores = markedStudents.map(s => s.score.total).sort((a, b) => a - b);
    const contentScores = markedStudents.map(s => s.score.content);
    const langScores = markedStudents.map(s => s.score.language);

    const sum = scores.reduce((acc, v) => acc + v, 0);
    const mean = Math.round((sum / totalMarked) * 10) / 10;

    const contentSum = contentScores.reduce((acc, v) => acc + v, 0);
    const contentMean = Math.round((contentSum / totalMarked) * 10) / 10;

    const langSum = langScores.reduce((acc, v) => acc + v, 0);
    const langMean = Math.round((langSum / totalMarked) * 10) / 10;

    // Median
    let median = 0;
    const mid = Math.floor(scores.length / 2);
    if (scores.length % 2 === 0) {
      median = (scores[mid - 1] + scores[mid]) / 2;
    } else {
      median = scores[mid];
    }
    median = Math.round(median * 10) / 10;

    // Min / Max
    const min = scores[0];
    const max = scores[scores.length - 1];

    // Standard Deviation
    const squareDiffs = scores.map(s => Math.pow(s - mean, 2));
    const avgSquareDiff = squareDiffs.reduce((acc, v) => acc + v, 0) / totalMarked;
    const stdDev = Math.round(Math.sqrt(avgSquareDiff) * 100) / 100;

    // Pass and Quality Pass thresholds
    const passThreshold = (config.passCutoffPct / 100) * config.totalMax;
    const qualityThreshold = (config.qualityCutoffPct / 100) * config.totalMax;

    const passCount = scores.filter(s => s >= passThreshold).length;
    const passPct = Math.round((passCount / totalMarked) * 1000) / 10;

    const qualityCount = scores.filter(s => s >= qualityThreshold).length;
    const qualityPct = Math.round((qualityCount / totalMarked) * 1000) / 10;

    const parCount = scores.filter(s => s < passThreshold).length;
    const parPct = Math.round((parCount / totalMarked) * 1000) / 10;

    // Bands: >=80% (Band 1), 65-79% (Band 2), 50-64% (Band 3), <50% (Band 4)
    const band1 = scores.filter(s => (s / config.totalMax) >= 0.80).length;
    const band2 = scores.filter(s => (s / config.totalMax) >= 0.65 && (s / config.totalMax) < 0.80).length;
    const band3 = scores.filter(s => (s / config.totalMax) >= 0.50 && (s / config.totalMax) < 0.65).length;
    const band4 = scores.filter(s => (s / config.totalMax) < 0.50).length;

    return {
      totalCandidature,
      totalMarked,
      totalUnmarked,
      totalModerated,
      mean,
      contentMean,
      langMean,
      median,
      stdDev,
      min,
      max,
      passThreshold,
      qualityThreshold,
      passCount,
      passPct,
      qualityCount,
      qualityPct,
      parCount,
      parPct,
      bandCounts: { band1, band2, band3, band4 }
    };
  }

  computeGroupBreakdown(students, groupKey, config) {
    const groups = {};

    students.forEach(s => {
      const gName = s[groupKey] || 'Unassigned';
      if (!groups[gName]) {
        groups[gName] = [];
      }
      groups[gName].push(s);
    });

    const results = Object.keys(groups).sort().map(groupName => {
      const list = groups[groupName];
      const marked = list.filter(s => s.score && s.score.total !== null);
      const totalCount = list.length;
      const markedCount = marked.length;

      if (markedCount === 0) {
        return {
          groupName,
          totalCount,
          markedCount,
          mean: 0,
          passPct: 0,
          qualityPct: 0,
          parCount: 0
        };
      }

      const scores = marked.map(s => s.score.total);
      const sum = scores.reduce((acc, v) => acc + v, 0);
      const mean = Math.round((sum / markedCount) * 10) / 10;

      const passThreshold = (config.passCutoffPct / 100) * config.totalMax;
      const qualityThreshold = (config.qualityCutoffPct / 100) * config.totalMax;

      const passCount = scores.filter(s => s >= passThreshold).length;
      const passPct = Math.round((passCount / markedCount) * 1000) / 10;

      const qualityCount = scores.filter(s => s >= qualityThreshold).length;
      const qualityPct = Math.round((qualityCount / markedCount) * 1000) / 10;

      const parCount = scores.filter(s => s < passThreshold).length;

      return {
        groupName,
        totalCount,
        markedCount,
        mean,
        passPct,
        qualityPct,
        parCount
      };
    });

    return results;
  }

  computeMarkerReliability(students, markers, cohortMean, config) {
    return markers.map(m => {
      const markerScripts = students.filter(s => s.markerCode === m.code && s.score && s.score.total !== null);
      const scriptCount = markerScripts.length;

      if (scriptCount === 0) {
        return {
          markerCode: m.code,
          markerName: m.name,
          scriptCount: 0,
          mean: 0,
          stdDev: 0,
          deltaFromCohort: 0,
          calibrationStatus: 'Pending',
          sampleCheckedCount: 0,
          avgModerationDelta: 0
        };
      }

      const scores = markerScripts.map(s => s.score.total);
      const sum = scores.reduce((acc, v) => acc + v, 0);
      const markerMean = Math.round((sum / scriptCount) * 10) / 10;

      // Std Dev
      const squareDiffs = scores.map(s => Math.pow(s - markerMean, 2));
      const avgSquareDiff = squareDiffs.reduce((acc, v) => acc + v, 0) / scriptCount;
      const stdDev = Math.round(Math.sqrt(avgSquareDiff) * 100) / 100;

      // Delta from Cohort
      const deltaFromCohort = Math.round((markerMean - cohortMean) * 10) / 10;

      // Severity Index based on % difference or mark spread
      let calibrationStatus = 'Calibrated';
      if (deltaFromCohort >= 1.5) {
        calibrationStatus = 'Lenient / High';
      } else if (deltaFromCohort <= -1.5) {
        calibrationStatus = 'Strict / Harsh';
      }

      // Moderation samples for this marker
      const moderated = markerScripts.filter(s => s.moderation && s.moderation.moderated);
      const sampleCheckedCount = moderated.length;
      let avgModerationDelta = 0;
      if (sampleCheckedCount > 0) {
        const modDeltaSum = moderated.reduce((acc, s) => acc + s.moderation.delta, 0);
        avgModerationDelta = Math.round((modDeltaSum / sampleCheckedCount) * 10) / 10;
      }

      return {
        markerCode: m.code,
        markerName: m.name,
        scriptCount,
        mean: markerMean,
        stdDev,
        deltaFromCohort,
        calibrationStatus,
        sampleCheckedCount,
        avgModerationDelta
      };
    });
  }

  computeClassFeedbackAnalysis(classStudents, config) {
    const marked = classStudents.filter(s => s.score && s.score.total !== null);
    const totalMarked = marked.length;
    
    // Tag frequencies
    const tagCounts = {};
    marked.forEach(s => {
      (s.tags || []).forEach(t => {
        tagCounts[t] = (tagCounts[t] || 0) + 1;
      });
    });

    // Lookup table for sentiment and category
    const fb = SECS_CONFIG.DEFAULT_FEEDBACK_TAGS;
    const allTags = fb.all || [
      ...(fb.strengths || []),
      ...(fb.mistakes || []),
      ...(fb.content?.strengths || []),
      ...(fb.content?.weaknesses || []),
      ...(fb.language?.strengths || []),
      ...(fb.language?.weaknesses || [])
    ];
    const tagMetaMap = {};
    allTags.forEach(t => {
      if (t && t.label) tagMetaMap[t.label] = t;
    });

    const strengths = [];
    const learningGaps = [];

    Object.keys(tagCounts).forEach(tagLabel => {
      const count = tagCounts[tagLabel];
      const pct = totalMarked > 0 ? Math.round((count / totalMarked) * 1000) / 10 : 0;
      const meta = tagMetaMap[tagLabel] || { sentiment: 'neutral' };
      
      const item = {
        tag: tagLabel,
        count,
        pct,
        sentiment: meta.sentiment
      };

      if (meta.sentiment === 'positive') {
        strengths.push(item);
      } else {
        learningGaps.push(item);
      }
    });

    // Sort descending by frequency count
    strengths.sort((a, b) => b.count - a.count);
    learningGaps.sort((a, b) => b.count - a.count);

    // Qualitative Remarks collection
    const remarks = marked
      .filter(s => s.remark && s.remark.trim().length > 0)
      .map(s => ({
        scriptId: s.scriptId,
        regNo: s.regNo,
        name: s.name,
        chineseName: s.chineseName || '',
        score: s.score.total,
        pct: s.score.pct,
        markerCode: s.markerCode || '-',
        tags: (s.tags || []).join(', '),
        remark: s.remark.trim()
      }));

    // Generate pedagogical action points based on top learning gaps
    const actionPoints = [];
    learningGaps.slice(0, 3).forEach(gap => {
      if (gap.tag.includes('Grammar') || gap.tag.includes('语法') || gap.tag.includes('语病')) {
        actionPoints.push(`Targeted sentence construction drills to address grammatical syntax errors (${gap.pct}% of class affected).`);
      } else if (gap.tag.includes('Vocabulary') || gap.tag.includes('词汇')) {
        actionPoints.push(`Expand thematic vocabulary lists and idiomatic expressions (成语/词汇) for composition writing.`);
      } else if (gap.tag.includes('Development') || gap.tag.includes('Elaboration') || gap.tag.includes('内容') || gap.tag.includes('细节')) {
        actionPoints.push(`Conduct structured paragraph elaboration workshops (sensory descriptions, character emotion, dialogue depth).`);
      } else if (gap.tag.includes('Punctuation') || gap.tag.includes('标点')) {
        actionPoints.push(`Reinforce punctuation rules and paragraph break conventions in weekly writing assignments.`);
      } else if (gap.tag.includes('Off-topic') || gap.tag.includes('偏题') || gap.tag.includes('Incomplete') || gap.tag.includes('未完')) {
        actionPoints.push(`Time management and plot outlining coaching (Introduction, Rising Action, Climax, Falling Action) within exam duration.`);
      } else {
        actionPoints.push(`Modular remediation targeting "${gap.tag}" for identified pupils.`);
      }
    });

    if (actionPoints.length === 0) {
      actionPoints.push("Continue current differentiated writing program; maintain strong performance in narrative development.");
    }

    return {
      totalMarked,
      strengths,
      learningGaps,
      remarks,
      actionPoints
    };
  }
}

const analytics = new AnalyticsService();
window.analytics = analytics;
