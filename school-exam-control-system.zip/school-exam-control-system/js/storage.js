/**
 * SECS - Local Storage & Data Persistence Engine
 * Supports Multi-Cohort / Multi-Paper Registry with full offline persistence.
 */

class StorageService {
  constructor() {
    this.storageKey = SECS_CONFIG.STORAGE_KEY;
    this.autoSaveListeners = [];
    this.rootState = null;
    this.init();
  }

  init() {
    const raw = localStorage.getItem(this.storageKey);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (parsed) {
          // Case A: Multi-Exam Registry format (v2.3+)
          if (parsed.exams && Array.isArray(parsed.exams) && parsed.exams.length > 0) {
            this.rootState = parsed;
            if (!this.rootState.activeExamId || !this.rootState.exams.find(e => e.id === this.rootState.activeExamId)) {
              this.rootState.activeExamId = this.rootState.exams[0].id;
            }
            let anyHealed = false;
            this.rootState.exams.forEach(exam => {
              if (this.healBilingualData(exam)) anyHealed = true;
            });
            if (anyHealed) this.save();
            return this.getActiveExam();
          }
          // Case B: Legacy Single-Exam format (v1.0 - v2.2) -> Auto-migrate to Multi-Exam
          else if (parsed.students && parsed.config) {
            this.healBilingualData(parsed);
            const defaultId = 'exam_default_p4_mt';
            const legacyExam = {
              id: defaultId,
              title: parsed.config.examTitle || '2026 Primary 4 Mid-Year Exam: Mother Tongue Paper 1',
              level: parsed.config.level || 'Primary 4',
              subject: parsed.config.subject || 'Mother Tongue (Chinese)',
              paper: 'Paper 1 (Writing)',
              academicYear: '2026',
              semester: 'Mid-Year',
              config: parsed.config,
              students: parsed.students,
              markers: (parsed.markers || []).map(m => ({ ...m, isKP: !!m.isKP })),
              feedbackTags: parsed.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS,
              createdAt: parsed.lastModified || new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            this.rootState = {
              version: '2.3',
              activeExamId: defaultId,
              lastSavedAt: new Date().toISOString(),
              exams: [legacyExam]
            };
            this.save();
            return this.getActiveExam();
          }
        }
      } catch (e) {
        console.error('Failed to parse existing data, loading demo seed', e);
      }
    }

    // Default initialization with demo data
    this.rootState = this.createInitialMultiExamState();
    this.save();
    return this.getActiveExam();
  }

  // Active Exam Accessors (Keeps 100% backward compatibility with existing db.getState() and db.state)
  getActiveExam() {
    if (!this.rootState || !Array.isArray(this.rootState.exams) || this.rootState.exams.length === 0) {
      this.rootState = this.createInitialMultiExamState();
    }
    let exam = this.rootState.exams.find(e => e.id === this.rootState.activeExamId);
    
    // For papers that have been archived, do not keep them active if unarchived papers exist
    if (!exam || exam.isArchived) {
      const activeUnarchived = this.rootState.exams.find(e => !e.isArchived);
      if (activeUnarchived) {
        exam = activeUnarchived;
        this.rootState.activeExamId = exam.id;
      } else if (!exam) {
        exam = this.rootState.exams[0];
        this.rootState.activeExamId = exam.id;
      }
    }
    return exam;
  }

  get state() {
    return this.getActiveExam();
  }

  set state(val) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) {
      this.rootState = { version: '2.3', activeExamId: val.id, lastSavedAt: new Date().toISOString(), exams: [val] };
      return;
    }
    const idx = this.rootState.exams.findIndex(e => e.id === val.id || e.id === this.rootState.activeExamId);
    if (idx !== -1) {
      this.rootState.exams[idx] = val;
    } else {
      this.rootState.exams.push(val);
      this.rootState.activeExamId = val.id;
    }
  }

  getState() {
    return this.getActiveExam();
  }

  getRootState() {
    return this.rootState;
  }

  // Multi-Exam Management API
  getExamsList() {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return [];
    return this.rootState.exams.map(e => {
      const students = e.students || [];
      const markedCount = students.filter(s => s.status === 'marked' || s.status === 'moderated').length;
      return {
        id: e.id,
        title: e.title || (e.config && e.config.examTitle) || 'Untitled Exam Paper',
        level: e.level || (e.config && e.config.level) || 'Primary 4',
        subject: e.subject || (e.config && e.config.subject) || 'Mother Tongue',
        paper: e.paper || 'Paper 1',
        academicYear: e.academicYear || '2026',
        semester: e.semester || 'Mid-Year',
        totalStudents: students.length,
        markedCount: markedCount,
        unmarkedCount: students.length - markedCount,
        progressPct: students.length > 0 ? Math.round((markedCount / students.length) * 100) : 0,
        markersCount: (e.markers || []).length,
        isLocked: !!(e.config && e.config.markingLocked),
        markingLocked: !!(e.config && e.config.markingLocked),
        markingLockedAt: (e.config && e.config.markingLockedAt) || null,
        isArchived: !!e.isArchived,
        archivedAt: e.archivedAt || null,
        lastPublishedAt: e.lastPublishedAt || null,
        config: e.config,
        updatedAt: e.updatedAt || e.createdAt || null
      };
    });
  }

  switchExam(examId) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return false;
    const exam = this.rootState.exams.find(e => e.id === examId);
    if (!exam) return false;
    this.rootState.activeExamId = examId;
    this.save();
    return exam;
  }

  createExam({ title, level, subject, paper, presetId, copyMarkersFrom, copyRosterFrom }) {
    const examId = `exam_${Date.now()}`;
    const preset = SECS_CONFIG.PRESETS[presetId] || SECS_CONFIG.PRESETS.P3_P4_MT;

    let markersToUse = [];
    if (copyMarkersFrom) {
      const sourceExam = this.rootState.exams.find(e => e.id === copyMarkersFrom);
      if (sourceExam && Array.isArray(sourceExam.markers)) {
        markersToUse = JSON.parse(JSON.stringify(sourceExam.markers));
      }
    }
    if (markersToUse.length === 0) {
      markersToUse = [
        { code: 'M01', name: 'Marker 1', isKP: true },
        { code: 'M02', name: 'Marker 2', isKP: false },
        { code: 'M03', name: 'Marker 3', isKP: false },
        { code: 'M04', name: 'Marker 4', isKP: false }
      ];
    }

    let initialStudents = [];
    if (copyRosterFrom) {
      const sourceExam = this.rootState.exams.find(e => e.id === copyRosterFrom);
      if (sourceExam && Array.isArray(sourceExam.students)) {
        initialStudents = sourceExam.students.map((s, idx) => {
          const scriptNum = String(idx + 1).padStart(3, '0');
          return {
            id: `STD-${Date.now()}-${scriptNum}`,
            scriptId: `SC-${scriptNum}`,
            name: s.name,
            chineseName: s.chineseName || '',
            formClass: s.formClass || '4-A',
            mtClass: s.mtClass || '4MT-1',
            regNo: s.regNo || (idx + 1),
            status: 'unmarked',
            markerCode: null,
            score: { content: null, language: null, total: null, pct: null },
            initialScore: null,
            tags: [],
            remark: '',
            markedAt: null,
            moderation: { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatorCode: null, moderatedBy: null, moderatedAt: null, originalScore: null }
          };
        });
      }
    }

    const cleanTitle = (title || `${level || 'Primary 4'} ${subject || 'Mother Tongue'} ${paper || 'Paper 1'}`).trim();

    const newExam = {
      id: examId,
      title: cleanTitle,
      level: (level || 'Primary 4').trim(),
      subject: (subject || 'Mother Tongue').trim(),
      paper: (paper || 'Paper 1 (Writing)').trim(),
      academicYear: '2026',
      semester: 'Mid-Year',
      isArchived: false,
      archivedAt: null,
      config: {
        examTitle: cleanTitle,
        level: (level || 'Primary 4').trim(),
        subject: (subject || 'Mother Tongue').trim(),
        presetId: presetId || 'P3_P4_MT',
        contentMax: preset.contentMax,
        contentMin: preset.contentMin || 0,
        languageMax: preset.languageMax,
        languageMin: preset.languageMin || 0,
        totalMax: preset.totalMax,
        passCutoffPct: preset.passCutoffPct || 50,
        qualityCutoffPct: preset.qualityCutoffPct || 80,
        blindMode: false,
        markingLocked: false,
        markingLockedAt: null
      },
      markers: markersToUse,
      students: initialStudents,
      feedbackTags: JSON.parse(JSON.stringify(SECS_CONFIG.DEFAULT_FEEDBACK_TAGS)),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.rootState.exams.push(newExam);
    this.rootState.activeExamId = examId;
    this.save();
    if (typeof app !== 'undefined' && app.renderGlobalExamSelector) {
      app.renderGlobalExamSelector();
    }
    return newExam;
  }

  archiveExam(examId) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return { success: false, error: 'Database uninitialized.' };
    const exam = this.rootState.exams.find(e => e.id === examId);
    if (!exam) return { success: false, error: 'Exam paper not found.' };

    exam.isArchived = true;
    exam.archivedAt = new Date().toISOString();
    if (exam.config) {
      exam.config.markingLocked = true;
      exam.config.markingLockedAt = exam.archivedAt;
    }
    exam.updatedAt = new Date().toISOString();

    // If active exam was archived, see if there is an unarchived exam to switch to
    if (this.rootState.activeExamId === examId) {
      const activeExam = this.rootState.exams.find(e => !e.isArchived && e.id !== examId);
      if (activeExam) {
        this.rootState.activeExamId = activeExam.id;
      }
    }

    this.save();
    return { success: true, exam };
  }

  unarchiveExam(examId) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return { success: false, error: 'Database uninitialized.' };
    const exam = this.rootState.exams.find(e => e.id === examId);
    if (!exam) return { success: false, error: 'Exam paper not found.' };

    exam.isArchived = false;
    exam.archivedAt = null;
    exam.updatedAt = new Date().toISOString();
    this.rootState.activeExamId = examId;
    this.save();
    return { success: true, exam };
  }

  updateExamDetails(examId, updates = {}) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return { success: false, error: 'Database uninitialized.' };
    const exam = this.rootState.exams.find(e => e.id === examId);
    if (!exam) return { success: false, error: 'Exam paper not found.' };

    if (updates.title) {
      exam.title = updates.title.trim();
      if (exam.config) exam.config.examTitle = exam.title;
    }
    if (updates.level) {
      exam.level = updates.level.trim();
      if (exam.config) exam.config.level = exam.level;
    }
    if (updates.subject) {
      exam.subject = updates.subject.trim();
      if (exam.config) exam.config.subject = exam.subject;
    }
    if (updates.paper) exam.paper = updates.paper.trim();
    if (updates.academicYear) exam.academicYear = updates.academicYear.trim();
    if (updates.semester) exam.semester = updates.semester.trim();

    if (exam.config) {
      if (updates.presetId) exam.config.presetId = updates.presetId;
      if (updates.contentMax !== undefined && !isNaN(Number(updates.contentMax))) {
        exam.config.contentMax = Number(updates.contentMax);
      }
      if (updates.languageMax !== undefined && !isNaN(Number(updates.languageMax))) {
        exam.config.languageMax = Number(updates.languageMax);
      }
      if (exam.config.contentMax !== undefined && exam.config.languageMax !== undefined) {
        exam.config.totalMax = exam.config.contentMax + exam.config.languageMax;
      }
      if (updates.passCutoffPct !== undefined && !isNaN(Number(updates.passCutoffPct))) {
        exam.config.passCutoffPct = Number(updates.passCutoffPct);
      }
      if (updates.qualityCutoffPct !== undefined && !isNaN(Number(updates.qualityCutoffPct))) {
        exam.config.qualityCutoffPct = Number(updates.qualityCutoffPct);
      }
      if (updates.blindMode !== undefined) exam.config.blindMode = !!updates.blindMode;
      if (updates.markingLocked !== undefined) exam.config.markingLocked = !!updates.markingLocked;
    }

    exam.updatedAt = new Date().toISOString();
    this.save();
    return { success: true, exam };
  }

  getClassesSummary(examId = null) {
    const exam = examId ? this.rootState.exams.find(e => e.id === examId) : this.getActiveExam();
    if (!exam || !Array.isArray(exam.students)) return { formClasses: [], mtClasses: [] };

    const formClassMap = {};
    const mtClassMap = {};

    exam.students.forEach(s => {
      if (s.formClass) {
        if (!formClassMap[s.formClass]) formClassMap[s.formClass] = { name: s.formClass, className: s.formClass, total: 0, totalStudents: 0, marked: 0, markedCount: 0 };
        formClassMap[s.formClass].total++;
        formClassMap[s.formClass].totalStudents++;
        if (s.status === 'marked' || s.status === 'moderated') {
          formClassMap[s.formClass].marked++;
          formClassMap[s.formClass].markedCount++;
        }
      }
      if (s.mtClass) {
        if (!mtClassMap[s.mtClass]) mtClassMap[s.mtClass] = { name: s.mtClass, className: s.mtClass, total: 0, totalStudents: 0, marked: 0, markedCount: 0 };
        mtClassMap[s.mtClass].total++;
        mtClassMap[s.mtClass].totalStudents++;
        if (s.status === 'marked' || s.status === 'moderated') {
          mtClassMap[s.mtClass].marked++;
          mtClassMap[s.mtClass].markedCount++;
        }
      }
    });

    return {
      formClasses: Object.values(formClassMap).sort((a, b) => a.name.localeCompare(b.name)),
      mtClasses: Object.values(mtClassMap).sort((a, b) => a.name.localeCompare(b.name))
    };
  }

  renameClassInExam(oldName, newName, classType = 'formClass', examId = null) {
    const exam = examId ? this.rootState.exams.find(e => e.id === examId) : this.getActiveExam();
    if (!exam || !Array.isArray(exam.students)) return { success: false, error: 'Exam not found.' };

    const cleanOld = oldName.trim();
    const cleanNew = newName.trim();
    if (!cleanNew) return { success: false, error: 'New class name cannot be empty.' };

    let count = 0;
    exam.students.forEach(s => {
      if (s[classType] === cleanOld) {
        s[classType] = cleanNew;
        count++;
      }
    });

    exam.updatedAt = new Date().toISOString();
    this.save();
    return { success: true, count, newName: cleanNew };
  }

  deleteClassFromExam(className, classType = 'formClass', examId = null) {
    const exam = examId ? this.rootState.exams.find(e => e.id === examId) : this.getActiveExam();
    if (!exam || !Array.isArray(exam.students)) return { success: false, error: 'Exam not found.' };

    const cleanName = className.trim();
    const initialCount = exam.students.length;
    exam.students = exam.students.filter(s => s[classType] !== cleanName);
    const removedCount = initialCount - exam.students.length;

    exam.updatedAt = new Date().toISOString();
    this.save();
    return { success: true, removedCount };
  }

  copyRosterFromExam({ sourceExamId, targetExamId = null, filterType = 'ALL', filterValue = 'ALL', mode = 'append' }) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return { success: false, error: 'Database uninitialized.' };
    const source = this.rootState.exams.find(e => e.id === sourceExamId);
    if (!source || !Array.isArray(source.students)) return { success: false, error: 'Source examination paper not found.' };

    const target = targetExamId ? this.rootState.exams.find(e => e.id === targetExamId) : this.getActiveExam();
    if (!target) return { success: false, error: 'Target examination paper not found.' };

    let candidatesToCopy = source.students;
    if (filterType === 'formClass' && filterValue && filterValue !== 'ALL') {
      candidatesToCopy = source.students.filter(s => s.formClass === filterValue);
    } else if (filterType === 'mtClass' && filterValue && filterValue !== 'ALL') {
      candidatesToCopy = source.students.filter(s => s.mtClass === filterValue);
    }

    if (candidatesToCopy.length === 0) {
      return { success: false, error: 'No pupils found matching the selected class filter.' };
    }

    if (mode === 'replace') {
      target.students = [];
    }

    const startIdx = target.students.length;
    let addedCount = 0;

    candidatesToCopy.forEach((item, i) => {
      const idx = startIdx + i + 1;
      const scriptNum = String(idx).padStart(3, '0');
      target.students.push({
        id: `STD-${Date.now()}-${scriptNum}-${Math.random().toString(36).substr(2, 4)}`,
        scriptId: `SC-${scriptNum}`,
        name: item.name || `Candidate ${scriptNum}`,
        chineseName: item.chineseName || '',
        formClass: item.formClass || '4-A',
        mtClass: item.mtClass || '4MT-1',
        regNo: Number(item.regNo) || (i + 1),
        status: 'unmarked',
        markerCode: null,
        score: { content: null, language: null, total: null, pct: null },
        initialScore: null,
        tags: [],
        remark: '',
        markedAt: null,
        moderation: { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatorCode: null, moderatedBy: null, moderatedAt: null, originalScore: null }
      });
      addedCount++;
    });

    target.updatedAt = new Date().toISOString();
    this.save();
    return { success: true, count: addedCount, targetExam: target };
  }

  deleteExam(examId) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return { success: false, error: 'Database uninitialized.' };
    if (this.rootState.exams.length <= 1) {
      return { success: false, error: 'Cannot delete the only remaining exam paper in the system.' };
    }
    const idx = this.rootState.exams.findIndex(e => e.id === examId);
    if (idx === -1) return { success: false, error: 'Exam paper not found.' };

    this.rootState.exams.splice(idx, 1);
    if (this.rootState.activeExamId === examId) {
      const nextActive = this.rootState.exams.find(e => !e.isArchived) || this.rootState.exams[0];
      this.rootState.activeExamId = nextActive ? nextActive.id : null;
    }
    this.save();
    return { success: true, activeExamId: this.rootState.activeExamId };
  }

  deleteExamSilently(examId) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return false;
    const idx = this.rootState.exams.findIndex(e => e.id === examId);
    if (idx === -1) return false;
    this.rootState.exams.splice(idx, 1);
    if (this.rootState.activeExamId === examId) {
      const nextActive = this.rootState.exams.find(e => !e.isArchived) || this.rootState.exams[0];
      this.rootState.activeExamId = nextActive ? nextActive.id : null;
    }
    this.save();
    return true;
  }

  duplicateExam(examId, newTitle) {
    const source = this.rootState.exams.find(e => e.id === examId);
    if (!source) return { success: false, error: 'Source exam not found.' };

    const newId = `exam_${Date.now()}`;
    const cloned = JSON.parse(JSON.stringify(source));
    cloned.id = newId;
    cloned.title = (newTitle || `${source.title} (Clone)`).trim();
    cloned.isArchived = false;
    cloned.archivedAt = null;
    cloned.config.examTitle = cloned.title;
    cloned.config.markingLocked = false;
    cloned.config.markingLockedAt = null;
    cloned.createdAt = new Date().toISOString();
    cloned.updatedAt = new Date().toISOString();

    // Reset marks and moderation for cloned roster
    cloned.students.forEach(s => {
      s.status = 'unmarked';
      s.score = { content: null, language: null, total: null, pct: null };
      s.initialScore = null;
      s.tags = [];
      s.remark = '';
      s.markedAt = null;
      s.moderation = { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatorCode: null, moderatedBy: null, moderatedAt: null, originalScore: null };
    });

    this.rootState.exams.push(cloned);
    this.rootState.activeExamId = newId;
    this.save();
    return { success: true, exam: cloned };
  }

  // Key Personnel (KP) Moderator Rights Management
  setMarkerKP(markerCode, isKP, examId) {
    const exam = examId ? this.rootState.exams.find(e => e.id === examId) : this.getActiveExam();
    if (!exam || !Array.isArray(exam.markers)) return false;
    const marker = exam.markers.find(m => m.code === markerCode);
    if (!marker) return false;
    marker.isKP = !!isKP;
    this.save();
    return true;
  }

  isMarkerKP(markerCode, examId) {
    const exam = examId ? this.rootState.exams.find(e => e.id === examId) : this.getActiveExam();
    if (!exam || !Array.isArray(exam.markers)) return false;
    const marker = exam.markers.find(m => m.code === markerCode);
    return marker ? !!marker.isKP : false;
  }

  // Auto-Save Beacon & Listener Engine
  onAutoSaved(callback) {
    if (typeof callback === 'function') {
      this.autoSaveListeners.push(callback);
    }
  }

  notifyAutoSaved(timestamp) {
    if (this.autoSaveListeners && Array.isArray(this.autoSaveListeners)) {
      this.autoSaveListeners.forEach(fn => {
        try { fn(timestamp); } catch (e) { console.error('AutoSave listener error:', e); }
      });
    }
  }

  getLastSavedTimestamp() {
    return this.rootState ? this.rootState.lastSavedAt : null;
  }

  // Persistence
  save() {
    try {
      const now = new Date().toISOString();
      if (!this.rootState) return false;
      this.rootState.lastSavedAt = now;
      const activeExam = this.getActiveExam();
      if (activeExam) {
        activeExam.updatedAt = now;
        activeExam.lastModified = now;
      }
      localStorage.setItem(this.storageKey, JSON.stringify(this.rootState));
      this.notifyAutoSaved(now);
      return true;
    } catch (e) {
      console.error('Local storage save error:', e);
      return false;
    }
  }

  repairMojibake(str) {
    if (!str || typeof str !== 'string') return '';
    if (/[\u00C0-\u00FF][\u0080-\u00BF]/.test(str) || str.includes('ï¿½') || str.includes('é™ˆ') || str.includes('æž—')) {
      try {
        const bytes = new Uint8Array(str.length);
        for (let i = 0; i < str.length; i++) {
          bytes[i] = str.charCodeAt(i) & 0xFF;
        }
        const decoded = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
        if (/[\u4e00-\u9fa5]/.test(decoded)) {
          return decoded;
        }
      } catch (e) {}
    }
    return str;
  }

  healBilingualData(state) {
    if (!state || !Array.isArray(state.students)) return false;

    const KNOWN_DEMO_CHINESE_NAMES = {
      "Tan Wei Ting": "陈韦廷",
      "Lim Jun Hao": "林俊豪",
      "Chua En Xi": "蔡恩熙",
      "Ethan Lee Rui": "李睿",
      "Marcus Ng Kai": "黄凯",
      "Teo Zhi Yang": "张智扬",
      "Lucas Ong Ze": "王泽",
      "Megan Low Si": "刘思敏",
      "Benjamin Tan": "陈伟杰",
      "Hannah Neo En": "梁恩彤",
      "Isaac Chen Hao": "陈浩",
      "Rachel Yeo Zhi": "杨芷萱",
      "Darren Lim Jun": "林俊杰",
      "Sherlyn Tan Hui": "陈惠敏",
      "Bryan Chia Seng": "谢盛安",
      "Gwen Soh Qian": "苏倩仪",
      "Aaron Wong Jia": "黄嘉乐",
      "Charmaine Seah": "谢敏儿",
      "Nicholas Teoh": "张子豪",
      "Natasha Quek": "郭欣宜",
      "Justin Ang Min": "洪敏杰",
      "Victoria Loke": "陆雅婷"
    };

    let modified = false;

    if (state.paper === 'Paper 1 (Continuous Writing)') {
      state.paper = 'Paper 1 (Writing)';
      modified = true;
    }
    if (state.config && state.config.component === 'Paper 1 (Continuous Writing)') {
      state.config.component = 'Paper 1 (Writing)';
      modified = true;
    }

    state.students.forEach(s => {
      if (s.chineseName) {
        const repaired = this.repairMojibake(s.chineseName);
        if (repaired !== s.chineseName) {
          s.chineseName = repaired;
          modified = true;
        }
      }
      if (s.name) {
        const repaired = this.repairMojibake(s.name);
        if (repaired !== s.name) {
          s.name = repaired;
          modified = true;
        }
      }

      if (s.name) {
        const cMatch = s.name.match(/[\u4e00-\u9fa5]+/g);
        if (cMatch && (!s.chineseName || s.chineseName.includes('ï¿½'))) {
          s.chineseName = cMatch.join('');
          s.name = s.name.replace(/[\(（]?[\u4e00-\u9fa5]+[\)）]?/g, '').replace(/[\(\)（）]/g, '').replace(/\s+/g, ' ').trim();
          modified = true;
        }
      }

      const cleanName = (s.name || '').trim();
      if (KNOWN_DEMO_CHINESE_NAMES[cleanName]) {
        if (!s.chineseName || s.chineseName.includes('ï¿½') || s.chineseName.includes('?') || !/[\u4e00-\u9fa5]/.test(s.chineseName)) {
          s.chineseName = KNOWN_DEMO_CHINESE_NAMES[cleanName];
          modified = true;
        }
      }

      if (s.initialScore === undefined) {
        if (s.moderation && s.moderation.moderated) {
          const delta = s.moderation.delta || 0;
          const origTotal = Math.max(0, (s.score.total || 0) - delta);
          const origContent = s.moderation.hodContent !== null ? Math.max(0, (s.score.content || 0) - delta) : (s.score.content || 0);
          s.initialScore = {
            content: origContent,
            language: s.score.language || 0,
            total: origTotal,
            pct: Math.round((origTotal / (state.config.totalMax || 15)) * 1000) / 10
          };
          s.moderation.originalScore = { ...s.initialScore };
        } else if (s.score && s.score.total !== null) {
          s.initialScore = { ...s.score };
        } else {
          s.initialScore = null;
        }
        modified = true;
      }
    });

    if (state.config && state.config.markingLocked === undefined) {
      state.config.markingLocked = false;
      modified = true;
    }

    if (state.markers && Array.isArray(state.markers)) {
      state.markers.forEach((m, idx) => {
        if (m.isKP === undefined) {
          m.isKP = (idx === 0); // M01 defaults to KP in demo
          modified = true;
        }
      });
    }

    if (!state.security) {
      state.security = {
        markerPasscode: (state.config && state.config.markerPasscode) || SECS_CONFIG.MARKER_PASSCODE || '1132',
        moderatorPin: (state.config && state.config.moderatorPin) || 'MOD88',
        requireModeratorPin: true
      };
      modified = true;
    }

    state.feedbackTags = SECS_CONFIG.DEFAULT_FEEDBACK_TAGS;
    modified = true;

    return modified;
  }

  // Paper-Specific Access Security Management
  getPaperSecurity(examId = null) {
    const root = this.getRootState();
    if (!root || !Array.isArray(root.exams)) return { markerPasscode: '1132', moderatorPin: 'MOD88', requireModeratorPin: true };
    const exam = examId ? root.exams.find(e => e.id === examId) : this.getActiveExam();
    if (!exam) return { markerPasscode: '1132', moderatorPin: 'MOD88', requireModeratorPin: true };
    if (!exam.security) {
      exam.security = {
        markerPasscode: (exam.config && exam.config.markerPasscode) || SECS_CONFIG.MARKER_PASSCODE || '1132',
        moderatorPin: (exam.config && exam.config.moderatorPin) || 'MOD88',
        requireModeratorPin: true
      };
    }
    return exam.security;
  }

  updatePaperSecurity(examId, { markerPasscode, moderatorPin }) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return { success: false, error: 'Database uninitialized' };
    const exam = examId ? this.rootState.exams.find(e => e.id === examId) : this.getActiveExam();
    if (!exam) return { success: false, error: 'Exam paper not found' };
    if (!exam.security) exam.security = {};
    if (markerPasscode !== undefined && markerPasscode.trim()) {
      exam.security.markerPasscode = markerPasscode.trim();
      if (exam.config) exam.config.markerPasscode = markerPasscode.trim();
    }
    if (moderatorPin !== undefined && moderatorPin.trim()) {
      exam.security.moderatorPin = moderatorPin.trim();
      if (exam.config) exam.config.moderatorPin = moderatorPin.trim();
    }
    exam.updatedAt = new Date().toISOString();
    this.save();
    return { success: true, security: exam.security };
  }

  verifyPaperMarkerPasscode(examId, inputPasscode) {
    const trimmed = (inputPasscode || '').trim();
    if (!trimmed) return false;
    const sec = this.getPaperSecurity(examId);
    if (!sec || !sec.markerPasscode) return false;
    return trimmed.toUpperCase() === sec.markerPasscode.trim().toUpperCase();
  }

  verifyPaperModeratorPin(examId, inputPin) {
    const trimmed = (inputPin || '').trim();
    if (!trimmed) return false;
    const sec = this.getPaperSecurity(examId);
    if (!sec || !sec.moderatorPin) return false;
    // Strictly require that input matches the exact PIN set by HOD for this exam paper
    return trimmed.toUpperCase() === sec.moderatorPin.trim().toUpperCase();
  }

  toggleMarkingLock(locked) {
    const exam = this.getActiveExam();
    return this.toggleMarkingLockForExam(exam ? exam.id : null, locked);
  }

  toggleMarkingLockForExam(examId, locked) {
    if (!this.rootState || !Array.isArray(this.rootState.exams)) return false;
    const exam = this.rootState.exams.find(e => e.id === examId) || this.getActiveExam();
    if (!exam || !exam.config) return false;
    if (locked !== undefined) {
      exam.config.markingLocked = !!locked;
    } else {
      exam.config.markingLocked = !exam.config.markingLocked;
    }
    exam.config.markingLockedAt = exam.config.markingLocked ? new Date().toISOString() : null;
    this.save();
    return exam.config.markingLocked;
  }

  resetToDemoState() {
    this.rootState = this.createInitialMultiExamState();
    this.save();
    return this.getActiveExam();
  }

  createInitialMultiExamState() {
    const demoExam = this.createExamFromDemoSeed({
      id: 'exam_2026_p4_mt_p1',
      title: '2026 Primary 4 Mid-Year Exam: Mother Tongue Paper 1',
      level: 'Primary 4',
      subject: 'Mother Tongue (Chinese)',
      paper: 'Paper 1 (Writing)',
      presetId: 'P3_P4_MT'
    });

    return {
      version: '2.3',
      activeExamId: demoExam.id,
      lastSavedAt: new Date().toISOString(),
      exams: [demoExam]
    };
  }

  createExamFromDemoSeed({ id, title, level, subject, paper, presetId }) {
    const preset = SECS_CONFIG.PRESETS[presetId || 'P3_P4_MT'];
    const markers = [
      { code: 'M01', name: 'Mdm Tan (TL)', isKP: true },
      { code: 'M02', name: 'Mr Lim Zhi Wei', isKP: false },
      { code: 'M03', name: 'Mrs Wong Lee Ping', isKP: false },
      { code: 'M04', name: 'Ms Siti Bte Rahman', isKP: false }
    ];

    const rawNames = [
      { name: "Tan Wei Ting", cn: "陈韦廷", form: "Humility 1 (Primary 4.1)", mt: "4MT-1", reg: 1, c: 6, l: 7, m: "M01", r: "Strong opening and meaningful resolution." },
      { name: "Lim Jun Hao", cn: "林俊豪", form: "Humility 1 (Primary 4.1)", mt: "4MT-1", reg: 2, c: 5, l: 6, m: "M01", r: "Well written, some minor grammar slips." },
      { name: "Muhammad Danial", cn: "", form: "Humility 1 (Primary 4.1)", mt: "4MT-3", reg: 3, c: 4, l: 4, m: "M02", r: "Passable storyline but plot lacks development." },
      { name: "Nurul Izzah", cn: "", form: "Humility 1 (Primary 4.1)", mt: "4MT-3", reg: 4, c: 3, l: 3, m: "M02", r: "PAR candidate. Requires remedial on sentence construction." },
      { name: "Chua En Xi", cn: "蔡恩熙", form: "Humility 1 (Primary 4.1)", mt: "4MT-1", reg: 5, c: 7, l: 8, m: "M01", r: "Outstanding composition. Candidate for model essay." },
      { name: "Kavitha d/o Rajan", cn: "", form: "Humility 1 (Primary 4.1)", mt: "4MT-2", reg: 6, c: 5, l: 5, m: "M03", r: "Good effort in vocabulary." },
      { name: "Ethan Lee Rui", cn: "李睿", form: "Humility 1 (Primary 4.1)", mt: "4MT-1", reg: 7, c: 6, l: 6, m: "M01", r: "Fluid writing." },
      { name: "Siti Sarah", cn: "", form: "Humility 1 (Primary 4.1)", mt: "4MT-3", reg: 8, c: 4, l: 3, m: "M02", r: "Need to pay attention to punctuation and tenses." },
      { name: "Marcus Ng Kai", cn: "黄凯", form: "Humility 1 (Primary 4.1)", mt: "4MT-2", reg: 9, c: 5, l: 6, m: "M03", r: "Clear paragraphs." },
      { name: "Teo Zhi Yang", cn: "张智扬", form: "Humility 1 (Primary 4.1)", mt: "4MT-1", reg: 10, c: 6, l: 7, m: "M01", r: "Very expressive." },
      { name: "Lucas Ong Ze", cn: "王泽", form: "Humility 2 (Primary 4.2)", mt: "4MT-1", reg: 1, c: 7, l: 7, m: "M01", r: "High quality writing." },
      { name: "Megan Low Si", cn: "刘思敏", form: "Humility 2 (Primary 4.2)", mt: "4MT-2", reg: 2, c: 5, l: 4, m: "M03", r: "Adequate content." },
      { name: "Ahmad Farhan", cn: "", form: "Humility 2 (Primary 4.2)", mt: "4MT-3", reg: 3, c: 3, l: 4, m: "M02", r: "Borderline score. Narrative was somewhat rushed." },
      { name: "Farah Nabilah", cn: "", form: "Humility 2 (Primary 4.2)", mt: "4MT-3", reg: 4, c: 4, l: 4, m: "M02", r: "Steady progress." },
      { name: "Benjamin Tan", cn: "陈伟杰", form: "Humility 2 (Primary 4.2)", mt: "4MT-1", reg: 5, c: 6, l: 7, m: "M04", r: "Commendable vocabulary." },
      { name: "Pooja Sharma", cn: "", form: "Humility 2 (Primary 4.2)", mt: "4MT-2", reg: 6, c: 5, l: 5, m: "M03", r: "Good attempt." },
      { name: "Hannah Neo En", cn: "梁恩彤", form: "Humility 2 (Primary 4.2)", mt: "4MT-1", reg: 7, c: 6, l: 8, m: "M04", r: "Quality pass. Elegant phrases." },
      { name: "Mohamed Irfan", cn: "", form: "Humility 2 (Primary 4.2)", mt: "4MT-3", reg: 8, c: 2, l: 3, m: "M02", r: "Pupil-at-Risk. Narrative abruptly stopped." },
      { name: "Isaac Chen Hao", cn: "陈浩", form: "Humility 2 (Primary 4.2)", mt: "4MT-2", reg: 9, c: 5, l: 5, m: "M03", r: "Balanced writing." },
      { name: "Rachel Yeo Zhi", cn: "杨芷萱", form: "Humility 2 (Primary 4.2)", mt: "4MT-1", reg: 10, c: 6, l: 7, m: "M04", r: "Solid development." },
      { name: "Darren Lim Jun", cn: "林俊杰", form: "Humility 3 (Primary 4.3)", mt: "4MT-2", reg: 1, c: 5, l: 5, m: "M03", r: "Satisfactory attempt." },
      { name: "Sherlyn Tan Hui", cn: "陈惠敏", form: "Humility 3 (Primary 4.3)", mt: "4MT-1", reg: 2, c: 7, l: 7, m: "M04", r: "Engaging plot climax." },
      { name: "Zulhilmi Bin Rosli", cn: "", form: "Humility 3 (Primary 4.3)", mt: "4MT-3", reg: 3, c: 4, l: 3, m: "M02", r: "Needs help on word choices." },
      { name: "Syasya Batrisya", cn: "", form: "Humility 3 (Primary 4.3)", mt: "4MT-3", reg: 4, c: 4, l: 5, m: "M02", r: "Good paragraph transitions." },
      { name: "Bryan Chia Seng", cn: "谢盛安", form: "Humility 3 (Primary 4.3)", mt: "4MT-2", reg: 5, c: 6, l: 6, m: "M03", r: "Well structured." },
      { name: "Divya Pillai", cn: "", form: "Humility 3 (Primary 4.3)", mt: "4MT-2", reg: 6, c: 5, l: 4, m: "M03", r: "Moderate narrative pace." },
      { name: "Gwen Soh Qian", cn: "苏倩仪", form: "Humility 3 (Primary 4.3)", mt: "4MT-1", reg: 7, c: 6, l: 7, m: "M04", r: "Creative ideas." },
      { name: "Aaron Wong Jia", cn: "黄嘉乐", form: "Humility 4 (Primary 4.4)", mt: "4MT-1", reg: 1, c: 7, l: 8, m: "M04", r: "Exemplary standard." },
      { name: "Charmaine Seah", cn: "谢敏儿", form: "Humility 4 (Primary 4.4)", mt: "4MT-2", reg: 2, c: 5, l: 6, m: "M03", r: "Fluent prose." },
      { name: "Muhammad Raziq", cn: "", form: "Humility 4 (Primary 4.4)", mt: "4MT-3", reg: 3, c: 3, l: 3, m: "M02", r: "Struggled with conclusion." },
      { name: "Putri Nur Sabrina", cn: "", form: "Humility 4 (Primary 4.4)", mt: "4MT-3", reg: 4, c: 5, l: 5, m: "M02", r: "Neat handwriting and decent plot." },
      { name: "Nicholas Teoh", cn: "张子豪", form: "Humility 4 (Primary 4.4)", mt: "4MT-1", reg: 5, c: 6, l: 6, m: "M04", r: "Clear sequence of events." },
      { name: "Arun Muthukumar", cn: "", form: "Humility 4 (Primary 4.4)", mt: "4MT-2", reg: 6, c: 4, l: 5, m: "M03", r: "Fair language standard." },
      { name: "Natasha Quek", cn: "郭欣宜", form: "Humility 4 (Primary 4.4)", mt: "4MT-1", reg: 7, c: 6, l: 7, m: "M04", r: "Rich descriptive vocabulary." },
      { name: "Justin Ang Min", cn: "洪敏杰", form: "Humility 4 (Primary 4.4)", mt: "4MT-2", reg: 8, c: null, l: null, m: null, r: "" },
      { name: "Victoria Loke", cn: "陆雅婷", form: "Humility 4 (Primary 4.4)", mt: "4MT-1", reg: 9, c: null, l: null, m: null, r: "" }
    ];

    const students = rawNames.map((item, idx) => {
      const scriptNum = String(idx + 1).padStart(3, '0');
      const isMarked = item.c !== null && item.l !== null;
      const total = isMarked ? item.c + item.l : null;
      const pct = isMarked ? Math.round((total / preset.totalMax) * 1000) / 10 : null;

      let moderation = {
        moderated: false,
        hodContent: null,
        hodLanguage: null,
        hodTotal: null,
        delta: 0,
        hodRemark: '',
        moderatorCode: null,
        moderatedBy: null,
        moderatedAt: null,
        originalScore: null
      };

      if (idx === 0) { // Tan Wei Ting
        moderation = {
          moderated: true,
          hodContent: 7,
          hodLanguage: 7,
          hodTotal: 14,
          delta: 1,
          hodRemark: 'Content was exceptionally rich with clear character voice. Raised content +1.',
          moderatorCode: 'HOD',
          moderatedBy: 'Mrs Sarah Tan (HOD)',
          moderatedAt: '2026-09-19T10:15:00Z',
          originalScore: { content: 6, language: 7, total: 13, pct: 86.7 }
        };
      } else if (idx === 2) { // Muhammad Danial
        moderation = {
          moderated: true,
          hodContent: 4,
          hodLanguage: 3,
          hodTotal: 7,
          delta: -1,
          hodRemark: 'Grammar errors were frequent in paragraphs 2 and 4. Lowered language mark by 1.',
          moderatorCode: 'M01',
          moderatedBy: 'Mr Lim (M01)',
          moderatedAt: '2026-09-19T11:00:00Z',
          originalScore: { content: 4, language: 4, total: 8, pct: 53.3 }
        };
      }

      const finalScore = moderation.moderated
        ? { content: moderation.hodContent, language: moderation.hodLanguage, total: moderation.hodTotal, pct: Math.round((moderation.hodTotal / preset.totalMax) * 1000) / 10 }
        : (isMarked ? { content: item.c, language: item.l, total, pct } : { content: null, language: null, total: null, pct: null });

      const initialScore = isMarked ? { content: item.c, language: item.l, total, pct } : null;

      return {
        id: `STD-${scriptNum}`,
        scriptId: `SC-${scriptNum}`,
        name: item.name,
        chineseName: item.cn || '',
        formClass: item.form,
        mtClass: item.mt,
        regNo: item.reg,
        status: moderation.moderated ? 'moderated' : (isMarked ? 'marked' : 'unmarked'),
        markerCode: item.m,
        score: finalScore,
        initialScore: initialScore,
        tags: isMarked ? (item.c >= 6 ? ['紧扣图意或题目 / Well-anchored to Prompt', '词汇丰富 / Rich Vocabulary'] : ['句式语病多 / Frequent Grammar Slips']) : [],
        remark: item.r,
        markedAt: isMarked ? '2026-09-19T08:30:00Z' : null,
        moderation: moderation
      };
    });

    return {
      id: id || `exam_${Date.now()}`,
      title: title || '2026 Primary 4 Mid-Year Exam: Mother Tongue Paper 1',
      level: level || 'Primary 4',
      subject: subject || 'Mother Tongue (Chinese)',
      paper: paper || 'Paper 1 (Writing)',
      academicYear: '2026',
      semester: 'Mid-Year',
      config: {
        examTitle: title || '2026 Primary 4 Mid-Year Exam: Mother Tongue Paper 1',
        level: level || 'Primary 4',
        subject: subject || 'Mother Tongue',
        presetId: presetId || 'P3_P4_MT',
        contentMax: preset.contentMax,
        contentMin: preset.contentMin || 0,
        languageMax: preset.languageMax,
        languageMin: preset.languageMin || 0,
        totalMax: preset.totalMax,
        passCutoffPct: preset.passCutoffPct,
        qualityCutoffPct: preset.qualityCutoffPct,
        blindMode: false,
        markingLocked: false,
        markingLockedAt: null
      },
      markers: markers,
      students: students,
      feedbackTags: SECS_CONFIG.DEFAULT_FEEDBACK_TAGS,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  updateConfig(newConfig) {
    const exam = this.getActiveExam();
    exam.config = { ...exam.config, ...newConfig };
    exam.config.totalMax = Number(exam.config.contentMax) + Number(exam.config.languageMax);
    if (newConfig.examTitle) exam.title = newConfig.examTitle;
    if (newConfig.level) exam.level = newConfig.level;
    if (newConfig.subject) exam.subject = newConfig.subject;

    exam.students.forEach(std => {
      if (std.score && std.score.total !== null) {
        std.score.pct = Math.round((std.score.total / exam.config.totalMax) * 1000) / 10;
      }
      if (std.initialScore && std.initialScore.total !== null) {
        std.initialScore.pct = Math.round((std.initialScore.total / exam.config.totalMax) * 1000) / 10;
      }
    });

    this.save();
    return exam.config;
  }

  getStudentEditStatus(student) {
    if (!student) return { isMarked: false, isModerated: false, isEditable: false, isFinalized: false, remainingSec: 0, reason: 'No student specified' };
    const exam = this.getActiveExam();
    const isLocked = !!(exam && exam.config && exam.config.markingLocked);
    const isModerated = !!(student.moderation && student.moderation.moderated);
    const isMarked = !!(student.score && student.score.total !== null && student.markedAt);

    if (isLocked) {
      return { isMarked, isModerated, isEditable: false, isFinalized: true, remainingSec: 0, reason: 'Marking is locked by HOD in Read-Only mode' };
    }
    if (isModerated) {
      return { isMarked, isModerated: true, isEditable: false, isFinalized: true, remainingSec: 0, reason: 'Script has already been moderated by Key Personnel' };
    }
    if (!isMarked) {
      return { isMarked: false, isModerated: false, isEditable: true, isFinalized: false, remainingSec: 0, reason: 'Unmarked (10-minute amendment window starts upon submission)' };
    }

    const markedTime = new Date(student.markedAt).getTime();
    const elapsedMs = isNaN(markedTime) ? Infinity : (Date.now() - markedTime);
    const GRACE_PERIOD_MS = 10 * 60 * 1000; // 10 minutes (600,000 ms)

    if (elapsedMs > GRACE_PERIOD_MS) {
      return {
        isMarked: true,
        isModerated: false,
        isEditable: false,
        isFinalized: true,
        elapsedMs,
        remainingSec: 0,
        markedAt: student.markedAt,
        reason: '10-minute amendment window has expired'
      };
    }

    const remainingSec = Math.max(0, Math.ceil((GRACE_PERIOD_MS - elapsedMs) / 1000));
    return {
      isMarked: true,
      isModerated: false,
      isEditable: true,
      isFinalized: false,
      elapsedMs,
      remainingSec,
      markedAt: student.markedAt,
      reason: 'Within 10-minute amendment window'
    };
  }

  saveStudentMark(studentId, markerCode, content, language, tags, remark) {
    const exam = this.getActiveExam();
    if (exam.config.markingLocked) {
      return { success: false, error: 'Marking is locked by HOD in Read-Only mode. Amendments are disabled.' };
    }
    const student = exam.students.find(s => s.id === studentId);
    if (!student) return { success: false, error: 'Student not found' };

    // Guard against regular marker overwriting a script marked by another marker
    if (student.markerCode && student.markerCode !== markerCode && student.status !== 'unmarked') {
      return {
        success: false,
        error: `Cannot overwrite script: This script was marked by ${student.markerCode}. Only an authorized Key Personnel (KP) Moderator or HOD can edit peer marks. If you require changes to this script, please approach your HOD or KP Moderator.`
      };
    }

    // Enforce 10-Minute Amendment Window for Markers
    const editStatus = this.getStudentEditStatus(student);
    if (!editStatus.isEditable && editStatus.isFinalized) {
      return {
        success: false,
        error: `Cannot amend score: ${editStatus.reason}. This script is finalized and locked for Key Personnel moderation.`
      };
    }

    const c = Number(content);
    const l = Number(language);
    const total = c + l;
    const totalMax = exam.config.totalMax;
    const pct = Math.round((total / totalMax) * 1000) / 10;

    const newScore = {
      content: c,
      language: l,
      total: total,
      pct: pct
    };

    if (!student.initialScore || !student.moderation || !student.moderation.moderated) {
      student.initialScore = { ...newScore };
    }

    const nowIso = new Date().toISOString();
    student.score = newScore;
    student.markerCode = markerCode;
    student.tags = Array.isArray(tags) ? tags : [];
    student.remark = remark ? remark.trim() : '';
    
    // Retain initial markedAt so the 10-minute countdown is not reset on edits
    if (!student.markedAt) {
      student.markedAt = nowIso;
      student.firstMarkedAt = nowIso;
    } else {
      student.lastEditedAt = nowIso;
    }

    student.status = (student.moderation && student.moderation.moderated) ? 'moderated' : 'marked';

    this.save();

    if (typeof syncService !== 'undefined' && syncService.isConnected()) {
      syncService.pushMarkerMark(student, markerCode);
    }

    return { success: true, student };
  }

  moderateStudent(studentId, hodContent, hodLanguage, hodRemark, moderatorName) {
    const exam = this.getActiveExam();
    const student = exam.students.find(s => s.id === studentId);
    if (!student) return { success: false, error: 'Student not found' };

    const c = Number(hodContent);
    const l = Number(hodLanguage);
    const hodTotal = c + l;
    const hodPct = Math.round((hodTotal / exam.config.totalMax) * 1000) / 10;

    if (!student.initialScore && student.score && student.score.total !== null) {
      student.initialScore = { ...student.score };
    } else if (!student.initialScore) {
      student.initialScore = { content: c, language: l, total: hodTotal, pct: hodPct };
    }

    const initialTotal = student.initialScore ? student.initialScore.total : (student.score && student.score.total !== null ? student.score.total : hodTotal);
    const delta = hodTotal - initialTotal;

    // Determine moderator code & name
    let modCode = 'HOD';
    let modName = moderatorName;
    if (typeof auth !== 'undefined' && auth.session) {
      if (auth.session.role === 'hod') {
        modCode = 'HOD';
        if (!modName) modName = 'HOD';
      } else if (auth.session.markerCode) {
        modCode = auth.session.markerCode;
        if (!modName) modName = auth.session.markerName ? `${auth.session.markerName} (${auth.session.markerCode})` : auth.session.markerCode;
      }
    }
    if (!modName) modName = moderatorName || modCode;

    student.moderation = {
      moderated: true,
      hodContent: c,
      hodLanguage: l,
      hodTotal: hodTotal,
      delta: delta,
      hodRemark: hodRemark || '',
      moderatorCode: modCode,
      moderatedBy: modName,
      moderatedAt: new Date().toISOString(),
      originalScore: student.initialScore ? { ...student.initialScore } : null
    };

    student.score = {
      content: c,
      language: l,
      total: hodTotal,
      pct: hodPct
    };
    student.status = 'moderated';
    if (!student.markerCode) {
      student.markerCode = modCode;
    }

    this.save();

    if (typeof syncService !== 'undefined' && syncService.isConnected()) {
      syncService.pushModeration(student);
    }

    return { success: true, student };
  }

  saveModeration(studentId, hodContent, hodLanguage, hodRemark, moderatorName) {
    return this.moderateStudent(studentId, hodContent, hodLanguage, hodRemark, moderatorName);
  }

  addMarker(code, name, isKP = false) {
    const exam = this.getActiveExam();
    const trimmedCode = code.trim().toUpperCase();
    if (exam.markers.some(m => m.code === trimmedCode)) {
      return { success: false, error: 'Marker Code already exists' };
    }
    const newMarker = { code: trimmedCode, name: name.trim() || `Marker ${trimmedCode}`, isKP: !!isKP };
    exam.markers.push(newMarker);
    this.save();
    return { success: true, marker: newMarker };
  }

  updateMarker(code, newName, isKP) {
    const exam = this.getActiveExam();
    const marker = exam.markers.find(m => m.code === code);
    if (!marker) return { success: false, error: 'Marker not found' };
    if (newName !== undefined) marker.name = newName.trim() || marker.name;
    if (isKP !== undefined) marker.isKP = !!isKP;
    this.save();
    return { success: true, marker };
  }

  deleteMarker(code) {
    const exam = this.getActiveExam();
    const idx = exam.markers.findIndex(m => m.code === code);
    if (idx === -1) return { success: false, error: 'Marker not found' };

    exam.students.forEach(s => {
      if (s.markerCode === code) {
        s.markerCode = null;
      }
    });

    exam.markers.splice(idx, 1);
    this.save();
    return { success: true };
  }

  addStudent(studentData) {
    const exam = this.getActiveExam();
    const nextNum = exam.students.length + 1;
    const scriptNum = String(nextNum).padStart(3, '0');
    const newStudent = {
      id: `STD-${Date.now()}-${scriptNum}`,
      scriptId: `SC-${scriptNum}`,
      name: studentData.name.trim(),
      chineseName: (studentData.chineseName || '').trim(),
      formClass: studentData.formClass.trim(),
      mtClass: studentData.mtClass.trim(),
      regNo: Number(studentData.regNo) || nextNum,
      status: 'unmarked',
      markerCode: null,
      score: { content: null, language: null, total: null, pct: null },
      tags: [],
      remark: '',
      markedAt: null,
      moderation: { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatedAt: null }
    };
    exam.students.push(newStudent);
    this.save();
    return { success: true, student: newStudent };
  }

  updateStudent(studentId, updatedData) {
    const exam = this.getActiveExam();
    const student = exam.students.find(s => s.id === studentId);
    if (!student) return { success: false, error: 'Student not found' };

    if (updatedData.name !== undefined) student.name = updatedData.name.trim();
    if (updatedData.chineseName !== undefined) student.chineseName = updatedData.chineseName.trim();
    if (updatedData.formClass !== undefined) student.formClass = updatedData.formClass.trim();
    if (updatedData.mtClass !== undefined) student.mtClass = updatedData.mtClass.trim();
    if (updatedData.regNo !== undefined) student.regNo = Number(updatedData.regNo) || student.regNo;

    this.save();
    return { success: true, student };
  }

  deleteStudent(studentId) {
    const exam = this.getActiveExam();
    const idx = exam.students.findIndex(s => s.id === studentId);
    if (idx === -1) return { success: false, error: 'Student not found' };
    exam.students.splice(idx, 1);
    this.save();
    return { success: true };
  }

  clearAllStudents() {
    const exam = this.getActiveExam();
    exam.students = [];
    this.save();
    return { success: true };
  }

  importRoster(studentsArray, mode = 'append') {
    const exam = this.getActiveExam();
    if (mode === 'replace') {
      exam.students = [];
    }

    const startIdx = exam.students.length;
    let addedCount = 0;

    studentsArray.forEach((item, i) => {
      const idx = startIdx + i + 1;
      const scriptNum = String(idx).padStart(3, '0');
      exam.students.push({
        id: `STD-${Date.now()}-${scriptNum}`,
        scriptId: `SC-${scriptNum}`,
        name: item.name || `Candidate ${scriptNum}`,
        chineseName: item.chineseName || item.cn || '',
        formClass: item.formClass || '4-A',
        mtClass: item.mtClass || '4MT-1',
        regNo: Number(item.regNo) || (i + 1),
        status: 'unmarked',
        markerCode: null,
        score: { content: null, language: null, total: null, pct: null },
        initialScore: null,
        tags: [],
        remark: '',
        markedAt: null,
        moderation: { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatedAt: null, originalScore: null }
      });
      addedCount++;
    });

    this.save();
    return addedCount;
  }

  generateLargeCohort(count = 120) {
    const exam = this.getActiveExam();
    const classNames = [
      'Humility 1 (Primary 4.1)',
      'Humility 2 (Primary 4.2)',
      'Humility 3 (Primary 4.3)',
      'Humility 4 (Primary 4.4)',
      'Humility 5 (Primary 4.5)'
    ];
    const mtClasses = ['4MT-1', '4MT-2', '4MT-3', '4MT-4'];
    const sampleGivenNames = ['Wei Ting', 'Jun Hao', 'En Xi', 'Danial', 'Izzah', 'Rui En', 'Kai Wen', 'Zhi Yang', 'Ze En', 'Si Hui', 'Farhan', 'Nabilah', 'Zhi Jie', 'En Tong', 'Hao Yu', 'Jun Jie', 'Hui Ling', 'Jia Hao', 'Min Yi', 'Zi Hao'];
    const sampleChineseNames = ['韦廷', '俊豪', '恩希', '', '', '瑞恩', '凯文', '志扬', '泽恩', '思慧', '', '', '志杰', '恩彤', '浩宇', '俊杰', '慧玲', '家豪', '敏仪', '子豪'];
    const sampleSurnames = ['Tan', 'Lim', 'Chua', 'Muhammad', 'Nurul', 'Lee', 'Ng', 'Teo', 'Ong', 'Low', 'Ahmad', 'Farah', 'Chen', 'Neo', 'Yeo', 'Chia', 'Wong', 'Seah', 'Teoh', 'Quek'];
    const sampleChineseSurnames = ['陈', '林', '蔡', '', '', '李', '黄', '张', '王', '刘', '', '', '陈', '梁', '杨', '谢', '黄', '谢', '张', '郭'];

    const markers = [];
    for (let m = 1; m <= 20; m++) {
      const code = `M${String(m).padStart(2, '0')}`;
      markers.push({ code, name: `Marker ${m}`, isKP: (m <= 2) });
    }

    const students = [];
    for (let i = 0; i < count; i++) {
      const scriptNum = String(i + 1).padStart(3, '0');
      const clsIdx = i % classNames.length;
      const mtIdx = i % mtClasses.length;
      const nameIdx = i % sampleGivenNames.length;
      const engName = `${sampleSurnames[nameIdx]} ${sampleGivenNames[nameIdx]}`;
      const chiName = sampleChineseSurnames[nameIdx] ? `${sampleChineseSurnames[nameIdx]}${sampleChineseNames[nameIdx]}` : '';
      const regNo = (Math.floor(i / classNames.length) + 1);
      const isMarked = i < Math.floor(count * 0.85);
      const markerCode = markers[i % markers.length].code;
      
      const c = isMarked ? ((i % 4) + 4) : null;
      const l = isMarked ? ((i % 4) + 5) : null;
      const total = isMarked ? c + l : null;
      const pct = isMarked ? Math.round((total / 15) * 1000) / 10 : null;

      const initialScore = isMarked ? { content: c, language: l, total, pct } : null;

      students.push({
        id: `STD-${scriptNum}`,
        scriptId: `SC-${scriptNum}`,
        name: engName,
        chineseName: chiName,
        formClass: classNames[clsIdx],
        mtClass: mtClasses[mtIdx],
        regNo: regNo,
        status: isMarked ? 'marked' : 'unmarked',
        markerCode: isMarked ? markerCode : null,
        score: isMarked ? { content: c, language: l, total, pct } : { content: null, language: null, total: null, pct: null },
        initialScore: initialScore,
        tags: isMarked ? ['紧扣图意或题目 / Well-anchored to Prompt'] : [],
        remark: isMarked ? 'Consistent performance.' : '',
        markedAt: isMarked ? new Date().toISOString() : null,
        moderation: { moderated: false, hodContent: null, hodLanguage: null, hodTotal: null, delta: 0, hodRemark: '', moderatedAt: null, originalScore: null }
      });
    }

    exam.markers = markers;
    exam.students = students;
    this.save();
    return exam;
  }

  exportMasterJSON() {
    return JSON.stringify(this.rootState, null, 2);
  }

  exportExamJSON(examId) {
    const exam = examId ? this.rootState.exams.find(e => e.id === examId) : this.getActiveExam();
    return JSON.stringify(exam, null, 2);
  }

  exportJSON() {
    return this.exportMasterJSON();
  }

  importJSON(jsonString) {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed) return { success: false, error: 'Empty JSON file.' };

      // Case 1: Master Multi-Exam Backup
      if (parsed.exams && Array.isArray(parsed.exams) && parsed.exams.length > 0) {
        this.rootState = parsed;
        if (!this.rootState.activeExamId || !this.rootState.exams.find(e => e.id === this.rootState.activeExamId)) {
          this.rootState.activeExamId = this.rootState.exams[0].id;
        }
        this.rootState.exams.forEach(exam => this.healBilingualData(exam));
        this.save();
        return { success: true, count: this.rootState.exams.length, type: 'master' };
      }

      // Case 2: Single Exam Backup
      if (parsed.students && parsed.config) {
        this.healBilingualData(parsed);
        const newId = parsed.id || `exam_${Date.now()}`;
        const newExam = {
          id: newId,
          title: parsed.title || parsed.config.examTitle || 'Imported Exam Paper',
          level: parsed.level || parsed.config.level || 'Primary 4',
          subject: parsed.subject || parsed.config.subject || 'Mother Tongue',
          paper: parsed.paper || 'Paper 1 (Writing)',
          academicYear: parsed.academicYear || '2026',
          semester: parsed.semester || 'Mid-Year',
          config: parsed.config,
          students: parsed.students,
          markers: (parsed.markers || []).map(m => ({ ...m, isKP: !!m.isKP })),
          feedbackTags: parsed.feedbackTags || SECS_CONFIG.DEFAULT_FEEDBACK_TAGS,
          createdAt: parsed.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };

        const existingIdx = this.rootState.exams.findIndex(e => e.id === newId);
        if (existingIdx !== -1) {
          this.rootState.exams[existingIdx] = newExam;
        } else {
          this.rootState.exams.push(newExam);
        }
        this.rootState.activeExamId = newId;
        this.save();
        return { success: true, exam: newExam, type: 'single' };
      }

      return { success: false, error: 'Invalid SECS database structure.' };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }
}

const db = new StorageService();
window.db = db;
