/**
 * SECS - Exam Configuration & Rubric Presets
 * Standards aligned with Singapore Primary School Examination Protocols
 */

const CONTENT_STRENGTHS = [
  { id: 'cs1', label: '紧扣图意或题目 / Well-anchored to Prompt', criterion: 'content', category: '审题与立意', sentiment: 'positive' },
  { id: 'cs2', label: '结构清楚 / Clear Narrative Structure', criterion: 'content', category: '结构与组织', sentiment: 'positive' },
  { id: 'cs3', label: '内容生动 / Vivid & Engaging Content', criterion: 'content', category: '内容与情节', sentiment: 'positive' },
  { id: 'cs4', label: '故事精彩 / Compelling Storyline', criterion: 'content', category: '内容与情节', sentiment: 'positive' },
  { id: 'cs5', label: '详略写分明 / Well-balanced Elaboration', criterion: 'content', category: '结构与组织', sentiment: 'positive' },
  { id: 'cs6', label: '事件结果合理 / Convincing Resolution', criterion: 'content', category: '内容与情节', sentiment: 'positive' },
  { id: 'cs7', label: '结尾扣题 / Strong Thematic Conclusion', criterion: 'content', category: '审题与立意', sentiment: 'positive' },
  { id: 'cs8', label: '立意积极深刻 / Meaningful Theme', criterion: 'content', category: '审题与立意', sentiment: 'positive' },
  { id: 'cs9', label: '描写细腻生动 / Vivid Sensory Details', criterion: 'content', category: '内容与情节', sentiment: 'positive' },
  { id: 'cs10', label: '过渡自然 / Smooth Transitions', criterion: 'content', category: '结构与组织', sentiment: 'positive' },
  { id: 'cs11', label: '内容完整 / Complete & Thorough Content', criterion: 'content', category: '审题与内容', sentiment: 'positive' }
];

const CONTENT_WEAKNESSES = [
  { id: 'cw1', label: '离题 / Off-topic', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw2', label: '偏题 / Partially Off-topic', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw3', label: '内容不完整 / Incomplete Content', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw4', label: '内容平淡 / Monotonous Plot', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw5', label: '事件交代不清楚 / Unclear Event Narration', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw6', label: '事件结果不合理 / Illogical Resolution', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw7', label: '事件结果不完整 / Incomplete Ending', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw8', label: '结尾没点题 / Conclusion Lacks Focus', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw9', label: '详略不当 / Imbalanced Elaboration', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw10', label: '缺乏心理与细节描写 / Lacking Descriptive Details', criterion: 'content', category: '审题与内容', sentiment: 'negative' },
  { id: 'cw11', label: '结构凌乱 / Disorganised Structure', criterion: 'content', category: '结构与组织', sentiment: 'negative' },
  { id: 'cw12', label: '分段不清 / Poor Paragraphing', criterion: 'content', category: '结构与组织', sentiment: 'negative' },
  { id: 'cw13', label: '篇幅不足 / Insufficient Length', criterion: 'content', category: '结构与组织', sentiment: 'negative' }
];

const LANGUAGE_STRENGTHS = [
  { id: 'ls1', label: '词汇丰富 / Rich Vocabulary', criterion: 'language', category: '语言与表达', sentiment: 'positive' },
  { id: 'ls2', label: '句式有变化 / Varied Sentence Structures', criterion: 'language', category: '语言与表达', sentiment: 'positive' },
  { id: 'ls3', label: '好词好句丰富 / Proficient Idioms & Quotes', criterion: 'language', category: '语言与表达', sentiment: 'positive' },
  { id: 'ls4', label: '标点准确·字迹工整 / Accurate Punctuation & Neat Handwriting', criterion: 'language', category: '标点与书写', sentiment: 'positive' },
  { id: 'ls5', label: '句式通顺 / Fluent & Coherent Sentences', criterion: 'language', category: '语言与表达', sentiment: 'positive' }
];

const LANGUAGE_WEAKNESSES = [
  { id: 'lw1', label: '人称错误 / Pronoun Inconsistency', criterion: 'language', category: '语言与表达', sentiment: 'negative' },
  { id: 'lw2', label: '句式重复 / Repetitive Syntax', criterion: 'language', category: '语言与表达', sentiment: 'negative' },
  { id: 'lw3', label: '句式语病多 / Frequent Grammar Slips', criterion: 'language', category: '语言与表达', sentiment: 'negative' },
  { id: 'lw4', label: '用词不精准 / Imprecise Vocabulary', criterion: 'language', category: '语言与表达', sentiment: 'negative' },
  { id: 'lw5', label: '搭配不当 / Faulty Collocations', criterion: 'language', category: '语言与表达', sentiment: 'negative' },
  { id: 'lw6', label: '受方言或英文思维影响 / Direct English Translation', criterion: 'language', category: '语言与表达', sentiment: 'negative' },
  { id: 'lw7', label: '标点符号错误 / Punctuation Errors', criterion: 'language', category: '标点与错别字', sentiment: 'negative' },
  { id: 'lw8', label: '错别字较多 / Frequent Spelling Errors', criterion: 'language', category: '标点与错别字', sentiment: 'negative' },
  { id: 'lw9', label: '句式不通顺 / Clumsy & Awkward Sentences', criterion: 'language', category: '语言与表达', sentiment: 'negative' }
];

const SECS_CONFIG = {
  MARKER_PASSCODE: '1132',
  HOD_PASSCODE: 'Control@SECS',
  DEFAULT_PASSCODE: '1132', // fallback legacy reference
  STORAGE_KEY: 'SECS_EXAM_SYSTEM_DB_V1',
  
  PRESETS: {
    P3_P4_MT: {
      id: 'P3_P4_MT',
      label: 'Primary 3 & 4 Mother Tongue (7 + 8 = 15 marks)',
      level: 'Primary 4',
      subject: 'Mother Tongue',
      contentMax: 7,
      contentMin: 0,
      languageMax: 8,
      languageMin: 0,
      totalMax: 15,
      passCutoffPct: 50,    // 7.5 / 15
      qualityCutoffPct: 80  // 12.0 / 15
    },
    P5_P6_MT: {
      id: 'P5_P6_MT',
      label: 'Primary 5 & 6 Mother Tongue (20 + 20 = 40 marks)',
      level: 'Primary 5',
      subject: 'Mother Tongue',
      contentMax: 20,
      contentMin: 0,
      languageMax: 20,
      languageMin: 0,
      totalMax: 40,
      passCutoffPct: 50,    // 20 / 40
      qualityCutoffPct: 80  // 32 / 40
    },
    ENG_P5_P6: {
      id: 'ENG_P5_P6',
      label: 'Primary 5 & 6 English Paper 1 (20 + 20 = 40 marks)',
      level: 'Primary 5',
      subject: 'English Language',
      contentMax: 20,
      contentMin: 0,
      languageMax: 20,
      languageMin: 0,
      totalMax: 40,
      passCutoffPct: 50,
      qualityCutoffPct: 80
    }
  },

  DEFAULT_FEEDBACK_TAGS: {
    // Structured by rubric criterion (Content vs Language)
    content: {
      strengths: CONTENT_STRENGTHS,
      weaknesses: CONTENT_WEAKNESSES
    },
    language: {
      strengths: LANGUAGE_STRENGTHS,
      weaknesses: LANGUAGE_WEAKNESSES
    },
    // Backward-compatible flat arrays
    strengths: [...CONTENT_STRENGTHS, ...LANGUAGE_STRENGTHS],
    mistakes: [...CONTENT_WEAKNESSES, ...LANGUAGE_WEAKNESSES],
    all: [...CONTENT_STRENGTHS, ...CONTENT_WEAKNESSES, ...LANGUAGE_STRENGTHS, ...LANGUAGE_WEAKNESSES]
  }
};
